package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.WeightLogEntity
import com.example.data.local.WeightliftingSetLogEntity
import com.example.ui.components.HapticCadencePacerCard
import com.example.ui.components.VoiceCoachModalDialog
import com.example.ui.components.rememberVoiceSpeechState
import com.example.ui.theme.BackgroundBlack
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonOrange
import com.example.ui.theme.NeonCyberGreen
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.SurfaceCardDark

@Composable
fun WeightliftingTrackerScreen(
    weightLogs: List<WeightLogEntity>,
    sets: List<WeightliftingSetLogEntity>,
    onBack: () -> Unit,
    onLogWeight: (Float, String) -> Unit,
    onLogSet: (workoutTitle: String, exerciseName: String, setNumber: Int, weightKg: Float, reps: Int) -> Unit,
    onToggleSetCompleted: (Long, Boolean) -> Unit,
    onAskVoiceAi: (String) -> Unit = {}
) {
    var showAddWeightDialog by remember { mutableStateOf(false) }
    var showAddSetDialog by remember { mutableStateOf(false) }
    var showVoiceModal by remember { mutableStateOf(false) }
    val workoutTitle = "Bent-over Row • Barbell"

    val voiceSpeechState = rememberVoiceSpeechState { transcribed ->
        onAskVoiceAi(transcribed)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundBlack)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .background(Color(0xFF12161A))
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x1AFFFFFF))
                        .testTag("weight_tracker_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "WEIGHTLIFTING & BODY COMP",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "Real-Time Sets, RPE, 1RM & Cadence Pacer",
                        fontSize = 11.sp,
                        color = NeonCyberGreen
                    )
                }
                IconButton(
                    onClick = { showVoiceModal = true },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(FitNeonCyan.copy(alpha = 0.2f))
                        .border(1.dp, FitNeonCyan, RoundedCornerShape(12.dp))
                ) {
                    Icon(Icons.Default.GraphicEq, contentDescription = "Voice Coach", tint = FitNeonCyan, modifier = Modifier.size(18.dp))
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Cadence Haptic Pacer Card
                item {
                    HapticCadencePacerCard()
                }

                // Body Weight Tracker Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceCardDark)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Scale, contentDescription = null, tint = NeonCyberGreen, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("BODY WEIGHT TRACKER", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.White)
                                }
                                Button(
                                    onClick = { showAddWeightDialog = true },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyberGreen, contentColor = Color.Black),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("log_weight_button")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Log Weight", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            val latestWeight = weightLogs.firstOrNull()?.weightKg ?: 72.4f
                            val latestLbs = latestWeight * 2.20462f

                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Column {
                                    Text(
                                        text = "${String.format("%.1f", latestWeight)} kg",
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "${String.format("%.1f", latestLbs)} lbs • Target: 75.0 kg",
                                        fontSize = 12.sp,
                                        color = Color.White.copy(alpha = 0.7f)
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = NeonCyberGreen.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "📉 -0.4 kg this week",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NeonCyberGreen,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Active Compound Lift Sets (Bent-over Row Barbell)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CURRENT LIFT: BENT-OVER ROW",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = FitNeonCyan,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Heavy Barbell Protocol • 4 Sets Target",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                        }
                        Button(
                            onClick = { showAddSetDialog = true },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = FitNeonCyan, contentColor = Color.Black),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("add_set_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Set", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Set Table Headers
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("SET", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.5f), modifier = Modifier.weight(1f))
                        Text("PREVIOUS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.5f), modifier = Modifier.weight(1.5f))
                        Text("KG", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.5f), modifier = Modifier.weight(1.2f))
                        Text("REPS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.5f), modifier = Modifier.weight(1.2f))
                        Text("DONE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.5f), modifier = Modifier.weight(0.8f))
                    }
                }

                val sampleSets = if (sets.isNotEmpty()) sets else listOf(
                    WeightliftingSetLogEntity(id = 1, workoutTitle = workoutTitle, exerciseName = "Bent-over Row", setNumber = 1, weightKg = 60f, reps = 12, isCompleted = true),
                    WeightliftingSetLogEntity(id = 2, workoutTitle = workoutTitle, exerciseName = "Bent-over Row", setNumber = 2, weightKg = 70f, reps = 10, isCompleted = true),
                    WeightliftingSetLogEntity(id = 3, workoutTitle = workoutTitle, exerciseName = "Bent-over Row", setNumber = 3, weightKg = 75f, reps = 8, isCompleted = false),
                    WeightliftingSetLogEntity(id = 4, workoutTitle = workoutTitle, exerciseName = "Bent-over Row", setNumber = 4, weightKg = 80f, reps = 6, isCompleted = false)
                )

                items(sampleSets) { itemSet ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (itemSet.isCompleted) Color(0xFF12231A) else SurfaceCardDark,
                        border = if (itemSet.isCompleted) androidx.compose.foundation.BorderStroke(1.dp, NeonCyberGreen.copy(alpha = 0.5f)) else null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${itemSet.setNumber}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.White, modifier = Modifier.weight(1f))
                            Text("70kg × 8", fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f), modifier = Modifier.weight(1.5f))
                            Text("${itemSet.weightKg.toInt()} kg", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = NeonCyberGreen, modifier = Modifier.weight(1.2f))
                            Text("${itemSet.reps}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.weight(1.2f))
                            Checkbox(
                                checked = itemSet.isCompleted,
                                onCheckedChange = { onToggleSetCompleted(itemSet.id, it) },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = NeonCyberGreen,
                                    checkmarkColor = Color.Black,
                                    uncheckedColor = Color.White.copy(alpha = 0.4f)
                                ),
                                modifier = Modifier.weight(0.8f)
                            )
                        }
                    }
                }
            }
        }

        // Add Weight Log Dialog
        if (showAddWeightDialog) {
            var weightInput by remember { mutableStateOf("72.5") }
            var noteInput by remember { mutableStateOf("Morning empty stomach") }
            Dialog(onDismissRequest = { showAddWeightDialog = false }) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF141920),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("LOG BODY WEIGHT", fontSize = 16.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = weightInput,
                            onValueChange = { weightInput = it },
                            label = { Text("Weight (kg)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyberGreen,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = noteInput,
                            onValueChange = { noteInput = it },
                            label = { Text("Note (Optional)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyberGreen,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                val w = weightInput.toFloatOrNull() ?: 70f
                                onLogWeight(w, noteInput)
                                showAddWeightDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyberGreen, contentColor = Color.Black),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("SAVE WEIGHT ENTRY", fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }

        // Add Set Dialog
        if (showAddSetDialog) {
            var weightKg by remember { mutableStateOf("75") }
            var repsCount by remember { mutableStateOf("8") }
            Dialog(onDismissRequest = { showAddSetDialog = false }) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF141920),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("LOG WEIGHTLIFTING SET", fontSize = 16.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = weightKg,
                            onValueChange = { weightKg = it },
                            label = { Text("Weight (kg)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = FitNeonCyan,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = repsCount,
                            onValueChange = { repsCount = it },
                            label = { Text("Reps Completed") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = FitNeonCyan,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                val w = weightKg.toFloatOrNull() ?: 60f
                                val r = repsCount.toIntOrNull() ?: 10
                                onLogSet(workoutTitle, "Bent-over Row", (sets.size + 1), w, r)
                                showAddSetDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FitNeonCyan, contentColor = Color.Black),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("SAVE SET RECORD", fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }

        // Voice Coach Modal
        if (showVoiceModal) {
            VoiceCoachModalDialog(
                voiceState = voiceSpeechState,
                exerciseName = "Bent-over Barbell Row",
                currentSet = 3,
                onDismiss = { showVoiceModal = false },
                onSubmitToAi = { query ->
                    onAskVoiceAi(query)
                }
            )
        }
    }
}
