package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.components.GlassPanel
import com.example.ui.components.RainbowButton
import com.example.ui.components.rememberSoundEffects
import com.example.ui.theme.FitBgDark
import com.example.ui.theme.FitDanger
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitTextMuted
import com.example.ui.theme.FitTextPrimary
import com.example.ui.theme.FitTextSecondary
import com.example.ui.theme.rememberRainbowBrush

@Composable
fun VerificationScreen(
    onVerifySuccess: (name: String, email: String, phone: String, avatar: String, photoUri: String) -> Unit
) {
    val soundEffects = rememberSoundEffects()
    val avatars = listOf("🥷", "🦾", "🏋️", "⚡", "💯", "🔥")
    var avatarIndex by remember { mutableIntStateOf(0) }
    var selectedPhotoUri by remember { mutableStateOf<String?>(null) }
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            soundEffects.playBiometricSuccessSound()
            selectedPhotoUri = uri.toString()
        }
    }

    val rainbowBrush = rememberRainbowBrush(1000)
    val scrollState = rememberScrollState()

    val step1Done = true
    val step2Done = fullName.trim().length >= 2
    val step3Done = email.trim().contains("@")
    val step4Done = phone.trim().length >= 7

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF140F22),
                        FitBgDark,
                        Color(0xFF0D1612)
                    )
                )
            )
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0x26FFFFFF))
                    .border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🦾", fontSize = 38.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "FIT",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
                Text(
                    text = "3D",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = FitNeonGreen
                )
            }

            Text(
                text = "FITNESS INTELLIGENCE • PERFORMANCE • AESTHETICS",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                color = FitTextSecondary
            )

            Spacer(modifier = Modifier.height(20.dp))

            GlassPanel(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, rainbowBrush, RoundedCornerShape(26.dp))
                    .testTag("verification_card")
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .background(FitNeonGreen, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SECURE VERIFICATION TERMINAL",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp,
                            color = Color(0xFFC0C0C0)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Identify yourself.",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )

                    Text(
                        text = "Complete the 4-step sequence to initialize your FIT3D environment ⚡",
                        fontSize = 12.sp,
                        color = FitTextSecondary,
                        modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                    )

                    // 4-Step Progress Indicator
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(step1Done, step2Done, step3Done, step4Done).forEach { completed ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (completed) FitNeonGreen else Color(0x33FFFFFF))
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Step 1: Avatar / Photo Picker
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .clip(CircleShape)
                                .background(Color(0x1AFFFFFF))
                                .border(
                                    width = 2.dp,
                                    brush = if (step1Done) rainbowBrush else Brush.linearGradient(listOf(Color.Gray, Color.DarkGray)),
                                    shape = CircleShape
                                )
                                .clickable {
                                    soundEffects.playClickSound()
                                    if (selectedPhotoUri != null) {
                                        selectedPhotoUri = null
                                    } else {
                                        avatarIndex = (avatarIndex + 1) % avatars.size
                                    }
                                }
                                .testTag("avatar_selector"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (selectedPhotoUri != null) {
                                AsyncImage(
                                    model = selectedPhotoUri,
                                    contentDescription = "Profile Photo",
                                    modifier = Modifier.fillMaxSize().clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(text = avatars[avatarIndex], fontSize = 44.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0x22FFFFFF),
                                modifier = Modifier.clickable {
                                    photoPicker.launch("image/*")
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = FitNeonGreen, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("UPLOAD PHOTO", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = FitNeonGreen)
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0x22FFFFFF),
                                modifier = Modifier.clickable {
                                    soundEffects.playClickSound()
                                    selectedPhotoUri = null
                                    avatarIndex = (avatarIndex + 1) % avatars.size
                                }
                            ) {
                                Text("SWITCH AVATAR", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = FitNeonCyan, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Step 2: Full Name
                    Text(
                        text = "FULL NAME • STEP 02",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FitTextPrimary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = {
                            fullName = it
                            errorMessage = ""
                        },
                        placeholder = { Text("Enter your full name", color = FitTextMuted, fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = FitNeonGreen) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = FitNeonGreen,
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF0F0F0F),
                            unfocusedContainerColor = Color(0xFF0F0F0F)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("full_name_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Step 3: Email
                    Text(
                        text = "SECURE EMAIL • STEP 03",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FitTextPrimary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = {
                            email = it
                            errorMessage = ""
                        },
                        placeholder = { Text("you@example.com", color = FitTextMuted, fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = FitNeonCyan) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = FitNeonGreen,
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF0F0F0F),
                            unfocusedContainerColor = Color(0xFF0F0F0F)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("email_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Step 4: Contact Number
                    Text(
                        text = "CONTACT STRING • STEP 04",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FitTextPrimary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = {
                            phone = it
                            errorMessage = ""
                        },
                        placeholder = { Text("+91XXXXXXXXXX", color = FitTextMuted, fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = FitNeonGreen) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = FitNeonGreen,
                            unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color(0xFF0F0F0F),
                            unfocusedContainerColor = Color(0xFF0F0F0F)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("phone_input")
                    )

                    if (errorMessage.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage,
                            color = FitDanger,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    RainbowButton(
                        text = "PROCEED TAP 🦾💯",
                        onClick = {
                            val cleanName = fullName.trim()
                            val cleanEmail = email.trim()
                            val cleanPhone = phone.trim()

                            if (cleanName.length < 2) {
                                errorMessage = "⚠️ Please enter your full name (min 2 characters)."
                                return@RainbowButton
                            }
                            if (!cleanEmail.contains("@")) {
                                errorMessage = "⚠️ Please enter a valid secure email address."
                                return@RainbowButton
                            }
                            if (cleanPhone.length < 7) {
                                errorMessage = "⚠️ Please enter a valid contact string (+91...)."
                                return@RainbowButton
                            }

                            soundEffects.playBiometricSuccessSound()
                            onVerifySuccess(cleanName, cleanEmail, cleanPhone, avatars[avatarIndex], selectedPhotoUri ?: "")
                        },
                        testTag = "proceed_tap_button"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "🔒 Bank-grade encrypted verification pipeline",
                        fontSize = 10.sp,
                        color = FitTextMuted,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                }
            }
        }
    }
}
