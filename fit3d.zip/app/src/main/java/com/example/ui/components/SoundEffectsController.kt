package com.example.ui.components

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * High-Performance System Sound Effects Controller for FIT3D
 * Provides crisp audio cues for workouts, rest timers, theme transitions,
 * biometric auth, set completions, and real-time alerts.
 */
class SoundEffectsController(private val context: Context) {
    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
        } catch (e: Exception) {
            // Audio hardware fallback
        }
    }

    /**
     * Subtle UI Click Sound
     */
    fun playClickSound() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 35)
        } catch (e: Exception) {
            // ignore
        }
    }

    /**
     * Countdown Timer Beep (3, 2, 1 interval)
     */
    fun playCountdownBeep() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_PIP, 80)
        } catch (e: Exception) {
            // ignore
        }
    }

    /**
     * Start / "GO" Explosive Tone
     */
    fun playGoSound() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_NETWORK_LITE, 220)
        } catch (e: Exception) {
            // ignore
        }
    }

    /**
     * Set / Rep Completed Tone
     */
    fun playSetCompleteSound() {
        try {
            CoroutineScope(Dispatchers.Default).launch {
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_KEYPAD_VOLUME_KEY_LITE, 100)
                delay(120)
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_CONFIRM, 160)
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    /**
     * Workout Finished Victory Sequence
     */
    fun playWorkoutVictoryFanfare() {
        try {
            CoroutineScope(Dispatchers.Default).launch {
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_KEYPAD_VOLUME_KEY_LITE, 100)
                delay(120)
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_CONFIRM, 150)
                delay(160)
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_NETWORK_LITE, 300)
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    /**
     * Biometric Gate Success Chime
     */
    fun playBiometricSuccessSound() {
        try {
            CoroutineScope(Dispatchers.Default).launch {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 120)
                delay(140)
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_CONFIRM, 180)
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    /**
     * Theme Switched Sound FX
     */
    fun playThemeSwitchSound() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_NETWORK_USA_RINGBACK, 150)
        } catch (e: Exception) {
            // ignore
        }
    }

    /**
     * Real-time WebSocket Alert chime
     */
    fun playWebSocketAlertSound() {
        try {
            CoroutineScope(Dispatchers.Default).launch {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 100)
                delay(100)
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 180)
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    fun release() {
        try {
            toneGenerator?.release()
            toneGenerator = null
        } catch (e: Exception) {
            // ignore
        }
    }
}

@Composable
fun rememberSoundEffects(): SoundEffectsController {
    val context = LocalContext.current
    return remember(context) { SoundEffectsController(context) }
}
