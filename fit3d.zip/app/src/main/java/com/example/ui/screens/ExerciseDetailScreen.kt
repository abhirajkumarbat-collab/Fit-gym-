package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ExerciseEntity
import com.example.ui.components.BodyMuscle
import com.example.ui.components.GlassPanel
import com.example.ui.components.MuscleViewer3D
import com.example.ui.components.RainbowButton
import com.example.ui.theme.FitBgDark
import com.example.ui.theme.FitBgPanel
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonOrange
import com.example.ui.theme.FitTextMuted
import com.example.ui.theme.FitTextSecondary

@Composable
fun ExerciseDetailScreen(
    exercise: ExerciseEntity?,
    activeMuscle: BodyMuscle,
    isGreenTargetEnabled: Boolean,
    onBack: () -> Unit,
    onStartWorkout: (ExerciseEntity) -> Unit,
    onToggleFavorite: (String, Boolean) -> Unit,
    onOpenCameraMirror: () -> Unit,
    onToggleMuscle: (BodyMuscle) -> Unit,
    onToggleGreenTarget: (Boolean) -> Unit
) {
    val scrollState = rememberScrollState()

    if (exercise == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(FitBgDark),
            contentAlignment = Alignment.Center
        ) {
            Text("Exercise protocol not found.", color = Color.White)
        }
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FitBgDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .background(FitBgPanel)
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x1AFFFFFF))
                        .testTag("detail_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Text(
                    text = "PROTOCOL DETAILS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = Color.White
                )
                IconButton(
                    onClick = { onToggleFavorite(exercise.id, !exercise.isFavorite) },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x1AFFFFFF))
                ) {
                    Icon(
                        imageVector = if (exercise.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Fav",
                        tint = if (exercise.isFavorite) Color(0xFFFF2A6D) else FitTextMuted
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Main Hero Section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color(0x22FFFFFF))
                            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = exercise.iconEmoji, fontSize = 32.sp)
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = exercise.title,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = exercise.subtitle,
                            fontSize = 12.sp,
                            color = FitTextSecondary
                        )
                    }
                }

                // Interactive 3D Muscle Anatomy Viewer
                MuscleViewer3D(
                    activeMuscle = activeMuscle,
                    isGreenTargetEnabled = isGreenTargetEnabled,
                    onMuscleSelected = onToggleMuscle,
                    onToggleGreenTarget = onToggleGreenTarget,
                    showControls = true
                )

                // Tactical Specs Matrix
                GlassPanel(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "TACTICAL SPECIFICATIONS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = FitNeonCyan
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("DOMESTIC PROP", fontSize = 9.sp, color = FitTextMuted)
                                Text("📦 ${exercise.domesticProp}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column {
                                Text("TARGET MATRIX", fontSize = 9.sp, color = FitTextMuted)
                                Text("🎯 ${exercise.targetMuscles}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FitNeonGreen)
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("STANDARD SETS", fontSize = 9.sp, color = FitTextMuted)
                                Text("${exercise.defaultSets} Sets × ${exercise.defaultReps} Reps", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column {
                                Text("REST DURATION", fontSize = 9.sp, color = FitTextMuted)
                                Text("${exercise.restDurationSec}s Rest Interval", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FitNeonOrange)
                            }
                        }
                    }
                }

                // Execution Instructions
                GlassPanel(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "EXECUTION & POSTURE GUIDE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = FitNeonGreen,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = exercise.instructions,
                            fontSize = 13.sp,
                            color = Color.White,
                            lineHeight = 18.sp
                        )
                    }
                }

                // Form Tips & Common Biomechanical Errors
                GlassPanel(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "BIOMECHANICAL TIPS & PITFALLS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = FitNeonOrange,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "💡 Form Cue: ${exercise.formTips}",
                            fontSize = 12.sp,
                            color = FitTextSecondary,
                            lineHeight = 17.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "⚠️ Avoid: ${exercise.commonMistakes}",
                            fontSize = 12.sp,
                            color = Color(0xFFFF8080),
                            lineHeight = 17.sp
                        )
                    }
                }

                // Camera Mirror Action Button
                OutlinedButton(
                    onClick = onOpenCameraMirror,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = FitNeonCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .border(1.dp, FitNeonCyan, RoundedCornerShape(16.dp))
                        .testTag("open_camera_mirror_button")
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null, tint = FitNeonCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("OPEN LIVE CAMERA FORM MIRROR", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                // Primary Start Workout CTA
                RainbowButton(
                    text = "ENGAGE PROTOCOL (${exercise.durationSec}s) ⚡",
                    onClick = { onStartWorkout(exercise) },
                    testTag = "engage_protocol_button"
                )

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
