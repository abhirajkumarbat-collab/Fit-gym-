package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CustomWorkoutPlanEntity
import com.example.data.local.ExerciseEntity
import com.example.ui.components.GlassPanel
import com.example.ui.components.RainbowButton
import com.example.ui.theme.FitBgDark
import com.example.ui.theme.FitBgPanel
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonOrange
import com.example.ui.theme.FitTextMuted
import com.example.ui.theme.FitTextSecondary

@Composable
fun PersonalPlanBuilderScreen(
    exercises: List<ExerciseEntity>,
    customPlans: List<CustomWorkoutPlanEntity>,
    onBack: () -> Unit,
    onSavePlan: (title: String, duration: Int, selectedExercises: List<ExerciseEntity>, focus: String, level: String) -> Unit
) {
    var planTitle by remember { mutableStateOf("") }
    var selectedDurationMin by remember { mutableFloatStateOf(20f) }
    var selectedLevel by remember { mutableStateOf("Intermediate") }
    var selectedFocus by remember { mutableStateOf("Full Body Domestic") }
    val selectedExercises = remember { mutableStateListOf<ExerciseEntity>() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FitBgDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .background(FitBgPanel)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x1AFFFFFF))
                        .testTag("plan_builder_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "CUSTOM ROUTINE ARCHITECT",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "Assemble Tailored Domestic & Gym Protocols",
                        fontSize = 10.sp,
                        color = FitNeonGreen
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Builder Form Card
                item {
                    GlassPanel(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "DESIGN NEW WORKOUT ROUTINE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = FitNeonCyan,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = planTitle,
                                onValueChange = { planTitle = it },
                                placeholder = { Text("e.g. Chest & Tricep Domestic Demolition", color = FitTextMuted, fontSize = 12.sp) },
                                label = { Text("Routine Title", color = FitTextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = FitNeonGreen,
                                    unfocusedBorderColor = Color(0x33FFFFFF),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text("Session Target Duration: ${selectedDurationMin.toInt()} Min", fontSize = 12.sp, color = Color.White)
                            Slider(
                                value = selectedDurationMin,
                                onValueChange = { selectedDurationMin = it },
                                valueRange = 10f..60f,
                                steps = 9,
                                colors = SliderDefaults.colors(thumbColor = FitNeonGreen, activeTrackColor = FitNeonGreen)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Level Selector
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("Beginner", "Intermediate", "Advanced").forEach { lvl ->
                                    val isSel = selectedLevel == lvl
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSel) FitNeonGreen.copy(alpha = 0.2f) else Color(0x1FFFFFFF),
                                        modifier = Modifier
                                            .weight(1f)
                                            .border(1.dp, if (isSel) FitNeonGreen else Color.Transparent, RoundedCornerShape(10.dp))
                                            .clickable { selectedLevel = lvl }
                                    ) {
                                        Text(
                                            text = lvl,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSel) FitNeonGreen else Color.White,
                                            modifier = Modifier.padding(vertical = 8.dp),
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Exercise Selection Header
                item {
                    Text(
                        text = "SELECT MOVEMENTS (${selectedExercises.size} SELECTED)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = FitNeonGreen,
                        letterSpacing = 1.sp
                    )
                }

                items(exercises.take(8)) { ex ->
                    val isSelected = selectedExercises.contains(ex)
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (isSelected) Color(0xFF14241B) else Color(0xFF131313),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (isSelected) FitNeonGreen else Color(0x22FFFFFF), RoundedCornerShape(14.dp))
                            .clickable {
                                if (isSelected) selectedExercises.remove(ex)
                                else selectedExercises.add(ex)
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = ex.iconEmoji, fontSize = 24.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = ex.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(text = "Prop: ${ex.domesticProp} • ${ex.targetMuscles}", fontSize = 10.sp, color = FitTextSecondary)
                            }
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) FitNeonGreen else Color(0x22FFFFFF)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isSelected) Icons.Default.Check else Icons.Default.Add,
                                    contentDescription = null,
                                    tint = if (isSelected) Color.Black else Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Save Routine Button
                item {
                    RainbowButton(
                        text = "SAVE CUSTOM ROUTINE ⚡",
                        onClick = {
                            val title = planTitle.ifBlank { "Custom ${selectedLevel} Power Routine" }
                            val exList = if (selectedExercises.isEmpty()) exercises.take(3) else selectedExercises.toList()
                            onSavePlan(title, selectedDurationMin.toInt(), exList, selectedFocus, selectedLevel)
                        },
                        testTag = "save_custom_routine_button"
                    )
                }

                // Existing Custom Plans
                if (customPlans.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "SAVED CUSTOM ROUTINES (${customPlans.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = FitNeonOrange,
                            letterSpacing = 1.sp
                        )
                    }

                    items(customPlans) { plan ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color(0xFF141414),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(16.dp))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(text = plan.title, fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.White)
                                Text(text = "${plan.durationMinutes} Min • ${plan.exerciseCount} Exercises • Level: ${plan.level}", fontSize = 11.sp, color = FitNeonCyan)
                                Text(text = "Moves: ${plan.exerciseNamesSummary}", fontSize = 10.sp, color = FitTextSecondary, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
