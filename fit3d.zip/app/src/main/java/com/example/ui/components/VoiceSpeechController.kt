package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonPurple
import com.example.ui.theme.FitTextSecondary
import java.util.Locale

@Composable
fun rememberVoiceSpeechState(
    context: Context = LocalContext.current,
    onSpeechResult: (String) -> Unit
): VoiceSpeechState {
    val state = remember { VoiceSpeechState(context, onSpeechResult) }
    DisposableEffect(Unit) {
        onDispose {
            state.cleanup()
        }
    }
    return state
}

class VoiceSpeechState(
    private val context: Context,
    private val onSpeechResult: (String) -> Unit
) {
    var isListening by mutableStateOf(false)
    var transcribedText by mutableStateOf("")
    var rmsRmsDb by mutableFloatStateOf(0f)
    var isThinking by mutableStateOf(false)
    var latestAiResponse by mutableStateOf<String?>(null)
    var errorMessage by mutableStateOf<String?>(null)

    private var speechRecognizer: SpeechRecognizer? = null

    init {
        initSpeechRecognizer()
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListening = true
                        errorMessage = null
                    }
                    override fun onBeginningOfSpeech() {
                        isListening = true
                    }
                    override fun onRmsChanged(rmsdB: Float) {
                        rmsRmsDb = rmsdB.coerceIn(0f, 10f)
                    }
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        isListening = false
                    }
                    override fun onError(error: Int) {
                        isListening = false
                        val desc = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Try speaking closer to mic."
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech timeout. Tap mic to speak again."
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
                            SpeechRecognizer.ERROR_CLIENT -> "Speech recognizer client ready."
                            SpeechRecognizer.ERROR_NETWORK -> "Network issue for speech transcription."
                            else -> "Tap microphone to dictate your prompt."
                        }
                        if (transcribedText.isBlank()) {
                            errorMessage = desc
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        isListening = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull() ?: ""
                        if (text.isNotBlank()) {
                            transcribedText = text
                            errorMessage = null
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull() ?: ""
                        if (text.isNotBlank()) {
                            transcribedText = text
                        }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    fun startListening() {
        errorMessage = null
        latestAiResponse = null
        val permissionCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            errorMessage = "Audio permission required. Please grant Microphone permission."
            return
        }
        if (speechRecognizer == null) {
            initSpeechRecognizer()
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        try {
            speechRecognizer?.startListening(intent)
            isListening = true
        } catch (e: Exception) {
            isListening = false
            errorMessage = "Speech service error: ${e.localizedMessage}"
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            // ignore
        }
        isListening = false
    }

    fun submitQuery(text: String = transcribedText) {
        if (text.isNotBlank()) {
            stopListening()
            isThinking = true
            onSpeechResult(text)
        }
    }

    fun cleanup() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            // ignore
        }
    }
}

@Composable
fun VoiceCoachModalDialog(
    voiceState: VoiceSpeechState,
    exerciseName: String? = null,
    currentSet: Int = 1,
    onDismiss: () -> Unit,
    onSubmitToAi: (String) -> Unit
) {
    val context = LocalContext.current
    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasAudioPermission = isGranted
        if (isGranted) {
            voiceState.startListening()
        } else {
            Toast.makeText(context, "Microphone permission is needed for Voice Coach", Toast.LENGTH_SHORT).show()
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "audioWave")
    val waveScale by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "waveScale"
    )

    LaunchedEffect(Unit) {
        if (hasAudioPermission) {
            voiceState.startListening()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Dialog(onDismissRequest = {
        voiceState.stopListening()
        onDismiss()
    }) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .border(2.dp, Brush.linearGradient(listOf(FitNeonCyan, FitNeonGreen, FitNeonPurple)), RoundedCornerShape(24.dp)),
            color = Color(0xFF0C1014),
            shadowElevation = 16.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = FitNeonCyan.copy(alpha = 0.2f),
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.SmartToy, contentDescription = null, tint = FitNeonCyan, modifier = Modifier.size(18.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "LIVE AI VOICE COACH",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = if (exerciseName != null) "$exerciseName • Set $currentSet" else "Real-Time Biofeedback & Load Adjuster",
                                fontSize = 11.sp,
                                color = FitNeonGreen
                            )
                        }
                    }
                    IconButton(
                        onClick = {
                            voiceState.stopListening()
                            onDismiss()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White.copy(alpha = 0.7f))
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Microphone & Dynamic Audio Waveform Visualizer
                Box(
                    modifier = Modifier.size(130.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (voiceState.isListening) {
                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .scale(waveScale * (1f + (voiceState.rmsRmsDb / 12f)))
                                .clip(CircleShape)
                                .background(FitNeonGreen.copy(alpha = 0.15f))
                        )
                        Box(
                            modifier = Modifier
                                .size(95.dp)
                                .scale(waveScale)
                                .clip(CircleShape)
                                .background(FitNeonCyan.copy(alpha = 0.25f))
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(
                                if (voiceState.isListening) Brush.radialGradient(listOf(FitNeonGreen, Color(0xFF00AA50)))
                                else Brush.radialGradient(listOf(Color(0xFF2C3440), Color(0xFF161B22)))
                            )
                            .clickable {
                                if (voiceState.isListening) {
                                    voiceState.stopListening()
                                } else {
                                    if (hasAudioPermission) {
                                        voiceState.startListening()
                                    } else {
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (voiceState.isListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                            contentDescription = "Mic",
                            tint = if (voiceState.isListening) Color.Black else Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = if (voiceState.isListening) "⚡ Listening... (Say: 'Adjust my dumbbells' or 'Check my form')"
                    else if (voiceState.isThinking) "⚡ Coach formulating kinetic feedback..."
                    else "Tap microphone to speak to AI coach",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (voiceState.isListening) FitNeonCyan else FitTextSecondary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp)),
                    color = Color(0xFF131820)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "YOU SAID:",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.5f),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = voiceState.transcribedText.ifBlank {
                                voiceState.errorMessage ?: "Speak your question or form query..."
                            },
                            fontSize = 14.sp,
                            color = if (voiceState.transcribedText.isNotBlank()) Color.White else FitTextSecondary,
                            fontWeight = if (voiceState.transcribedText.isNotBlank()) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "Should I increase weight?",
                        "Form feedback",
                        "Elbow flare angle"
                    ).forEach { chip ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0x22FFFFFF),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    voiceState.transcribedText = chip
                                    voiceState.submitQuery(chip)
                                    onSubmitToAi(chip)
                                    onDismiss()
                                }
                        ) {
                            Text(
                                text = chip,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = FitNeonCyan,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (voiceState.transcribedText.isNotBlank()) FitNeonGreen else Color(0x33FFFFFF),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clickable(enabled = voiceState.transcribedText.isNotBlank()) {
                            val text = voiceState.transcribedText
                            voiceState.submitQuery(text)
                            onSubmitToAi(text)
                            onDismiss()
                        }
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Send,
                            contentDescription = null,
                            tint = if (voiceState.transcribedText.isNotBlank()) Color.Black else Color.White.copy(alpha = 0.5f),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ASK AI COACH NOW",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = if (voiceState.transcribedText.isNotBlank()) Color.Black else Color.White.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        }
    }
}
