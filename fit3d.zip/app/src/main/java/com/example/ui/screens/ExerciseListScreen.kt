package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ExerciseEntity
import com.example.ui.theme.FitBgDark
import com.example.ui.theme.FitBgPanel
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonOrange
import com.example.ui.theme.FitNeonPurple
import com.example.ui.theme.FitTextMuted
import com.example.ui.theme.FitTextSecondary

@Composable
fun ExerciseListScreen(
    sector: String,
    exercises: List<ExerciseEntity>,
    onBack: () -> Unit,
    onExerciseClick: (String) -> Unit,
    onToggleFavorite: (String, Boolean) -> Unit
) {
    val sectorExercises = exercises.filter { it.sector.equals(sector, ignoreCase = true) }
    var selectedDifficulty by remember { mutableStateOf("All") }

    val filteredList = if (selectedDifficulty == "All") {
        sectorExercises
    } else {
        sectorExercises.filter { it.difficulty.equals(selectedDifficulty, ignoreCase = true) }
    }

    val sectorTitle = when (sector.uppercase()) {
        "GYM" -> "HOME GYM STRENGTH 🏋️"
        "YOGA" -> "HOME YOGA & ZEN 🧘"
        "FACE" -> "FACE SMART AESTHETIC 🥷"
        else -> "$sector Sector"
    }

    val sectorSubtitle = when (sector.uppercase()) {
        "GYM" -> "Domestic prop workouts: Water bottles, chairs, backpacks"
        "YOGA" -> "Flexibility & kinetic breath control routines"
        "FACE" -> "Jawline definition, Mewing posture & facial aesthetics"
        else -> "Tactical Training Modules"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FitBgDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .background(FitBgPanel)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x1AFFFFFF))
                        .testTag("exercise_list_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = sectorTitle,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = sectorSubtitle,
                        fontSize = 10.sp,
                        color = FitTextSecondary,
                        maxLines = 1
                    )
                }
            }

            // Filter Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All", "Beginner", "Intermediate", "Advanced").forEach { diff ->
                    item {
                        FilterChip(
                            selected = selectedDifficulty == diff,
                            onClick = { selectedDifficulty = diff },
                            label = { Text(diff, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FitNeonGreen,
                                selectedLabelColor = Color.Black,
                                containerColor = Color(0x1FFFFFFF),
                                labelColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }

            // Exercise List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("exercise_lazy_list"),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "AVAILABLE PROTOCOLS (${filteredList.size})",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = FitNeonCyan,
                        letterSpacing = 1.5.sp
                    )
                }

                items(filteredList, key = { it.id }) { exercise ->
                    ExerciseCardItem(
                        exercise = exercise,
                        onClick = { onExerciseClick(exercise.id) },
                        onToggleFav = { onToggleFavorite(exercise.id, !exercise.isFavorite) }
                    )
                }
            }
        }
    }
}

@Composable
fun ExerciseCardItem(
    exercise: ExerciseEntity,
    onClick: () -> Unit,
    onToggleFav: () -> Unit
) {
    val diffColor = when (exercise.difficulty.uppercase()) {
        "BEGINNER" -> FitNeonGreen
        "INTERMEDIATE" -> FitNeonCyan
        "ADVANCED" -> FitNeonOrange
        else -> FitNeonPurple
    }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF131313),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0x2BFFFFFF), RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag("exercise_card_${exercise.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x1FFFFFFF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = exercise.iconEmoji, fontSize = 24.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = exercise.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = exercise.subtitle,
                            fontSize = 11.sp,
                            color = FitTextSecondary
                        )
                    }
                }

                IconButton(
                    onClick = onToggleFav,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (exercise.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (exercise.isFavorite) Color(0xFFFF2A6D) else FitTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Metadata Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = diffColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = exercise.difficulty.uppercase(),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = diffColor,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = FitNeonCyan.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "📦 ${exercise.domesticProp}",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = FitNeonCyan,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                        maxLines = 1
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0x22FFFFFF)
                ) {
                    Text(
                        text = "⏱️ ${exercise.durationSec}s",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Target Muscles Tag
            Text(
                text = "🎯 ${exercise.targetMuscles}",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = FitNeonGreen
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Play Button
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0x22FFFFFF),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onClick)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = FitNeonGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "START PROTOCOL →",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }
        }
    }
}
