package com.example.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalFitTheme = staticCompositionLocalOf { "Cyber Green" }

private val CyberGreenScheme = darkColorScheme(
    primary = FitNeonGreen,
    onPrimary = Color(0xFF0A0A0A),
    primaryContainer = Color(0xFF1E3A2B),
    onPrimaryContainer = FitNeonGreen,
    secondary = FitNeonCyan,
    onSecondary = Color(0xFF001F29),
    secondaryContainer = Color(0xFF003847),
    onSecondaryContainer = FitNeonCyan,
    tertiary = FitNeonPurple,
    onTertiary = Color.White,
    background = BackgroundBlack,
    onBackground = FitTextPrimary,
    surface = SurfaceDark,
    onSurface = FitTextPrimary,
    surfaceVariant = SurfaceCardDark,
    onSurfaceVariant = FitTextSecondary,
    error = FitDanger,
    onError = Color.White
)

private val SolarGoldScheme = darkColorScheme(
    primary = SolarGoldPrimary,
    onPrimary = Color(0xFF1A1200),
    primaryContainer = Color(0xFF382900),
    onPrimaryContainer = SolarGoldPrimary,
    secondary = SolarGoldSecondary,
    onSecondary = Color(0xFF261000),
    secondaryContainer = Color(0xFF4A2500),
    onSecondaryContainer = SolarGoldSecondary,
    tertiary = FitNeonGreen,
    onTertiary = Color.Black,
    background = SolarGoldBgDark,
    onBackground = Color.White,
    surface = SolarGoldBgPanel,
    onSurface = Color.White,
    surfaceVariant = SolarGoldBgCard,
    onSurfaceVariant = Color(0xFFE0D0B5),
    error = FitDanger,
    onError = Color.White
)

private val UltraVioletScheme = darkColorScheme(
    primary = UltraVioletPrimary,
    onPrimary = Color(0xFF140033),
    primaryContainer = Color(0xFF330066),
    onPrimaryContainer = UltraVioletPrimary,
    secondary = UltraVioletSecondary,
    onSecondary = Color(0xFF300015),
    secondaryContainer = Color(0xFF5E002C),
    onSecondaryContainer = UltraVioletSecondary,
    tertiary = FitNeonCyan,
    onTertiary = Color.Black,
    background = UltraVioletBgDark,
    onBackground = Color.White,
    surface = UltraVioletBgPanel,
    onSurface = Color.White,
    surfaceVariant = UltraVioletBgCard,
    onSurfaceVariant = Color(0xFFD8C7F0),
    error = FitDanger,
    onError = Color.White
)

private val ProfessionalPolishScheme = darkColorScheme(
    primary = PolishAccentPrimary,
    onPrimary = PolishAccentOnPrimary,
    primaryContainer = Color(0xFF00497E),
    onPrimaryContainer = PolishAccentPrimary,
    secondary = Color(0xFF8E9199),
    onSecondary = Color(0xFF00315E),
    secondaryContainer = PolishSurfaceVariant,
    onSecondaryContainer = PolishTextPrimary,
    tertiary = Color(0xFF4ADE80),
    onTertiary = Color.Black,
    background = PolishBgDark,
    onBackground = PolishTextPrimary,
    surface = PolishSurface,
    onSurface = PolishTextPrimary,
    surfaceVariant = PolishSurfaceVariant,
    onSurfaceVariant = PolishTextSecondary,
    error = FitDanger,
    onError = Color.White
)

private val StealthObsidianScheme = darkColorScheme(
    primary = StealthObsidianPrimary,
    onPrimary = Color(0xFF0F172A),
    primaryContainer = Color(0xFF1E293B),
    onPrimaryContainer = StealthObsidianPrimary,
    secondary = StealthObsidianSecondary,
    onSecondary = Color(0xFF001F29),
    secondaryContainer = Color(0xFF0F3242),
    onSecondaryContainer = StealthObsidianSecondary,
    tertiary = Color(0xFF94A3B8),
    onTertiary = Color.Black,
    background = StealthObsidianBgDark,
    onBackground = Color.White,
    surface = StealthObsidianBgPanel,
    onSurface = Color.White,
    surfaceVariant = StealthObsidianBgCard,
    onSurfaceVariant = Color(0xFF94A3B8),
    error = FitDanger,
    onError = Color.White
)

fun getThemeColorScheme(themeName: String): ColorScheme {
    val normalized = themeName.trim().uppercase().replace(" ", "_")
    return when {
        normalized.contains("POLISH") || normalized.contains("PROFESSIONAL") -> ProfessionalPolishScheme
        normalized.contains("GOLD") -> SolarGoldScheme
        normalized.contains("VIOLET") || normalized.contains("PURPLE") -> UltraVioletScheme
        normalized.contains("OBSIDIAN") || normalized.contains("STEALTH") -> StealthObsidianScheme
        else -> CyberGreenScheme
    }
}

fun getThemePrimaryAccent(themeName: String): Color {
    val normalized = themeName.trim().uppercase().replace(" ", "_")
    return when {
        normalized.contains("POLISH") || normalized.contains("PROFESSIONAL") -> PolishAccentPrimary
        normalized.contains("GOLD") -> SolarGoldPrimary
        normalized.contains("VIOLET") || normalized.contains("PURPLE") -> UltraVioletPrimary
        normalized.contains("OBSIDIAN") || normalized.contains("STEALTH") -> StealthObsidianSecondary
        else -> FitNeonGreen
    }
}

@Composable
fun FIT3DTheme(
    themeName: String = "Cyber Green",
    content: @Composable () -> Unit
) {
    val scheme = getThemeColorScheme(themeName)
    CompositionLocalProvider(LocalFitTheme provides themeName) {
        MaterialTheme(
            colorScheme = scheme,
            typography = Typography,
            content = content
        )
    }
}

@Composable
fun Fit3dTheme(
    themeName: String = "Cyber Green",
    content: @Composable () -> Unit
) {
    FIT3DTheme(themeName = themeName, content = content)
}
