package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import com.example.ui.components.rememberSoundEffects
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserEntity
import com.example.ui.components.GlassPanel
import com.example.ui.components.RainbowButton
import com.example.ui.theme.FitBgDark
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonOrange
import com.example.ui.theme.FitNeonPurple
import com.example.ui.theme.FitTextMuted
import com.example.ui.theme.FitTextSecondary
import com.example.ui.theme.rememberRainbowBrush
import com.example.viewmodel.WorkoutSessionState

@Composable
fun WorkoutCompleteScreen(
    user: UserEntity?,
    session: WorkoutSessionState,
    onReturnHome: () -> Unit,
    onViewAnalytics: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "celebrationPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val rainbowBrush = rememberRainbowBrush(800)
    val scrollState = rememberScrollState()
    val soundEffects = rememberSoundEffects()

    LaunchedEffect(Unit) {
        soundEffects.playWorkoutVictoryFanfare()
    }

    val totalDurationMin = (session.elapsedSeconds.coerceAtLeast(90) / 60)
    val calories = session.caloriesBurned.coerceAtLeast(65)
    val xpEarned = 180 + (totalDurationMin * 5)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0F2B1D),
                        FitBgDark,
                        Color(0xFF140D20)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            // Trophy Badge
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(Color(0xFF151515))
                    .border(2.5.dp, rainbowBrush, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("🏆", fontSize = 44.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "WORKOUT CRUSHED!",
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = (-0.5).sp
            )

            Text(
                text = "KINETIC VOLUME LOGGED TO FIT3D CLOUD ⚡",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = FitNeonGreen,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Stats Matrix Card
            GlassPanel(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("TOTAL DURATION", fontSize = 9.sp, color = FitTextMuted)
                            Text("$totalDurationMin MIN", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("CALORIES BURNED", fontSize = 9.sp, color = FitTextMuted)
                            Text("$calories KCAL", fontSize = 20.sp, fontWeight = FontWeight.Black, color = FitNeonOrange)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("XP EARNED", fontSize = 9.sp, color = FitTextMuted)
                            Text("+$xpEarned XP", fontSize = 20.sp, fontWeight = FontWeight.Black, color = FitNeonCyan)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0x1FFFFFFF),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("SETS COMPLETED", fontSize = 9.sp, color = FitTextSecondary)
                                Text("${session.currentSet} SETS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0x1FFFFFFF),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("STREAK STATUS", fontSize = 9.sp, color = FitTextSecondary)
                                Text("🔥 ${(user?.streak ?: 6) + 1} DAYS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = FitNeonGreen)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // AI Coach Encouragement
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF141920),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, FitNeonCyan.copy(alpha = 0.3f), RoundedCornerShape(18.dp))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🦾", fontSize = 32.sp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "AI COACH BIOMETRICS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = FitNeonCyan,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Remarkable kinetic focus! Your neuromuscular activation index hit 94%. Ensure 500ml water hydration & 25g protein within 45 minutes.",
                            fontSize = 12.sp,
                            color = Color.White,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons
            RainbowButton(
                text = "RETURN TO DASHBOARD ⚡",
                onClick = onReturnHome,
                testTag = "workout_complete_return_home_button"
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = onViewAnalytics,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = FitNeonCyan),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp))
            ) {
                Text("VIEW RECOVERY & ANALYTICS", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
