package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AdminPostEntity
import com.example.data.local.ExerciseEntity
import com.example.data.local.UserEntity
import com.example.ui.components.GlassPanel
import com.example.ui.components.RainbowButton
import com.example.ui.components.UserRoleBadge
import com.example.ui.theme.FitAdminPurple
import com.example.ui.theme.FitBgDark
import com.example.ui.theme.FitBgPanel
import com.example.ui.theme.FitDanger
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonOrange
import com.example.ui.theme.FitTextMuted
import com.example.ui.theme.FitTextSecondary
import com.example.ui.theme.rememberRainbowBrush

@Composable
fun AdminDashboardScreen(
    user: UserEntity?,
    exercises: List<ExerciseEntity>,
    adminPosts: List<AdminPostEntity>,
    serverDiagnosticLogs: List<String>,
    onExitAdmin: () -> Unit,
    onCreatePost: (title: String, category: String, desc: String, muscle: String) -> Unit,
    onDeletePost: (String) -> Unit,
    onCreateExercise: (
        title: String,
        sector: String,
        subtitle: String,
        prop: String,
        muscles: String,
        difficulty: String,
        sets: Int,
        reps: Int,
        instructions: String
    ) -> Unit,
    onDeleteExercise: (String) -> Unit,
    onPingServers: () -> Unit,
    onExecuteHttpTest: (String) -> Unit,
    onMapVideoToExercise: (exerciseId: String, videoUrl: String, videoFileName: String, videoCategory: String) -> Unit
) {
    var postTitle by remember { mutableStateOf("") }
    var postCategory by remember { mutableStateOf("ANNOUNCEMENT") }
    var postDesc by remember { mutableStateOf("") }
    var postMuscle by remember { mutableStateOf("Full Body") }

    var newExTitle by remember { mutableStateOf("") }
    var newExSector by remember { mutableStateOf("GYM") }
    var newExProp by remember { mutableStateOf("5L Water Jugs") }
    var newExMuscles by remember { mutableStateOf("Chest & Triceps") }
    var newExDiff by remember { mutableStateOf("Intermediate") }
    var newExInstructions by remember { mutableStateOf("Perform 4 sets of 12 reps with controlled 3-sec eccentric descent.") }

    var mapVideoExId by remember { mutableStateOf(exercises.firstOrNull()?.id ?: "") }
    var mapVideoUrl by remember { mutableStateOf("https://cdn.fit3d-videos.internal/pushup_chest.mp4") }
    var mapVideoFileName by remember { mutableStateOf("pushup_chest_4k.mp4") }
    var mapVideoCategory by remember { mutableStateOf("CHEST") }

    val rainbowBrush = rememberRainbowBrush(600)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF220D30),
                        FitBgDark,
                        Color(0xFF0F1A14)
                    )
                )
            )
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Admin Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
                    .background(FitBgPanel)
                    .padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onExitAdmin,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x22FFFFFF))
                            .testTag("admin_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "⚡ SUPER ADMIN COMMAND CORE ⚡",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = FitNeonGreen,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "Identity: ABHIRAJ KUMAR • ROOT PRIVILEGES",
                            fontSize = 10.sp,
                            color = FitTextSecondary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = FitAdminPurple.copy(alpha = 0.2f),
                    modifier = Modifier.border(1.dp, FitAdminPurple, RoundedCornerShape(8.dp))
                ) {
                    Text(
                        text = "ROOT ACTIVE 🔒",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("admin_dashboard_scroll_list"),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Admin Status & Security Badge
                item {
                    UserRoleBadge(isAdmin = true, modifier = Modifier.fillMaxWidth())
                }

                // Server Health & Endpoints Diagnostics
                item {
                    GlassPanel(
                        modifier = Modifier.fillMaxWidth(),
                        borderColor = FitNeonCyan.copy(alpha = 0.4f)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = FitNeonCyan, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "HOST ENDPOINT & CDN LIVE STATUS",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        color = FitNeonCyan
                                    )
                                }
                                Button(
                                    onClick = onPingServers,
                                    colors = ButtonDefaults.buttonColors(containerColor = FitNeonCyan, contentColor = Color.Black),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Text("PING ALL (HTTP 200)", fontSize = 9.sp, fontWeight = FontWeight.Black)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Diagnostic terminal output
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF090909))
                                    .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(10.dp))
                                    .padding(10.dp)
                            ) {
                                serverDiagnosticLogs.take(5).forEach { log ->
                                    Text(
                                        text = log,
                                        fontSize = 9.sp,
                                        color = if (log.contains("200")) FitNeonGreen else FitNeonCyan,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // 4K CDN Video Management Module
                item {
                    GlassPanel(
                        modifier = Modifier.fillMaxWidth(),
                        borderColor = FitNeonGreen.copy(alpha = 0.4f)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = FitNeonGreen, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "4K CDN VIDEO & CATEGORY MAPPER",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = FitNeonGreen
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = mapVideoCategory,
                                onValueChange = { mapVideoCategory = it },
                                label = { Text("Video Category (CHEST, ARMS, LEGS, YOGA, FACE)", fontSize = 11.sp) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = FitNeonGreen,
                                    unfocusedBorderColor = Color(0x33FFFFFF),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = mapVideoUrl,
                                onValueChange = { mapVideoUrl = it },
                                label = { Text("4K Video Stream URL (HTTP 200 CDN)", fontSize = 11.sp) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = FitNeonGreen,
                                    unfocusedBorderColor = Color(0x33FFFFFF),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Button(
                                onClick = {
                                    val targetId = mapVideoExId.ifBlank { exercises.firstOrNull()?.id ?: "gym_ex_1" }
                                    onMapVideoToExercise(targetId, mapVideoUrl, mapVideoFileName, mapVideoCategory)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = FitNeonGreen, contentColor = Color.Black),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("MAP VIDEO TO SELECTED CATEGORY ⚡", fontSize = 11.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }

                // Broadcast Announcement Publisher
                item {
                    GlassPanel(
                        modifier = Modifier.fillMaxWidth(),
                        borderColor = FitAdminPurple.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Campaign, contentDescription = null, tint = Color(0xFFCE93D8), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "GLOBAL DISPATCH & WEBSOCKET BROADCASTER",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFCE93D8)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = postTitle,
                                onValueChange = { postTitle = it },
                                placeholder = { Text("e.g. 50% XP Boost Weekend for Mewing & Domestic Shred", color = FitTextMuted, fontSize = 12.sp) },
                                label = { Text("Broadcast Headline", color = FitTextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = FitAdminPurple,
                                    unfocusedBorderColor = Color(0x33FFFFFF),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = postDesc,
                                onValueChange = { postDesc = it },
                                placeholder = { Text("Message body to transmit to all active peer nodes...", color = FitTextMuted, fontSize = 12.sp) },
                                label = { Text("Message Body", color = FitTextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = FitAdminPurple,
                                    unfocusedBorderColor = Color(0x33FFFFFF),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            RainbowButton(
                                text = "TRANSMIT BROADCAST ACROSS NETWORK ⚡",
                                onClick = {
                                    if (postTitle.isNotBlank()) {
                                        onCreatePost(postTitle, postCategory, postDesc, postMuscle)
                                        postTitle = ""
                                        postDesc = ""
                                    }
                                },
                                testTag = "transmit_broadcast_button"
                            )
                        }
                    }
                }

                // Add Custom Exercise Protocol to Room Database
                item {
                    GlassPanel(
                        modifier = Modifier.fillMaxWidth(),
                        borderColor = FitNeonOrange.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = FitNeonOrange, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "INJECT NEW EXERCISE PROTOCOL (ROOM DB)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = FitNeonOrange
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = newExTitle,
                                onValueChange = { newExTitle = it },
                                label = { Text("Exercise Title (e.g. Chair Incline Push-Up)", fontSize = 11.sp) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = FitNeonOrange,
                                    unfocusedBorderColor = Color(0x33FFFFFF),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = newExProp,
                                onValueChange = { newExProp = it },
                                label = { Text("Domestic Prop (e.g. Dining Chair / Backpack)", fontSize = 11.sp) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = FitNeonOrange,
                                    unfocusedBorderColor = Color(0x33FFFFFF),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = newExMuscles,
                                onValueChange = { newExMuscles = it },
                                label = { Text("Target Muscles (e.g. Upper Chest, Triceps)", fontSize = 11.sp) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = FitNeonOrange,
                                    unfocusedBorderColor = Color(0x33FFFFFF),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    if (newExTitle.isNotBlank()) {
                                        onCreateExercise(
                                            newExTitle,
                                            newExSector,
                                            "Admin injected tactical movement",
                                            newExProp,
                                            newExMuscles,
                                            newExDiff,
                                            3,
                                            12,
                                            newExInstructions
                                        )
                                        newExTitle = ""
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = FitNeonOrange, contentColor = Color.Black),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("COMMIT TO ROOM REPOSITORY 💾", fontSize = 11.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }

                // Delete Post or Exercise Manager
                item {
                    Text(
                        text = "MANAGE ADMIN POSTS (${adminPosts.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 1.sp
                    )
                }

                items(adminPosts) { post ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF16111D),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = post.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(text = "${post.category} • ${post.authorName}", fontSize = 10.sp, color = FitTextSecondary)
                            }
                            IconButton(onClick = { onDeletePost(post.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = FitDanger)
                            }
                        }
                    }
                }
            }
        }
    }
}
