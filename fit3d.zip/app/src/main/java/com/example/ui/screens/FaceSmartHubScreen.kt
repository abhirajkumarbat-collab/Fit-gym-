package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ArticleEntity
import com.example.data.local.ExerciseEntity
import com.example.ui.components.GlassPanel
import com.example.ui.theme.FitBgDark
import com.example.ui.theme.FitBgPanel
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonOrange
import com.example.ui.theme.FitTextSecondary

@Composable
fun FaceSmartHubScreen(
    articles: List<ArticleEntity>,
    faceExercises: List<ExerciseEntity>,
    onBack: () -> Unit,
    onArticleClick: (ArticleEntity) -> Unit,
    onStartExercise: (String) -> Unit,
    onOpenCameraMirror: () -> Unit
) {
    val faceList = faceExercises.filter { it.sector.equals("FACE", ignoreCase = true) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FitBgDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .background(FitBgPanel)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x1AFFFFFF))
                        .testTag("face_hub_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "FACE SMART AESTHETIC 🥷",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "Mewing, Masseter Hypertrophy & Cervical Alignment",
                        fontSize = 10.sp,
                        color = FitNeonCyan
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Feature Banner
                item {
                    GlassPanel(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "JAWLINE & CRANIOFACIAL POSTURE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = FitNeonCyan,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Science-backed tongue posture & submental muscle tone to sharpen jawline definition and correct modern forward-head syndrome.",
                                fontSize = 12.sp,
                                color = Color.White,
                                lineHeight = 17.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = onOpenCameraMirror,
                                colors = ButtonDefaults.buttonColors(containerColor = FitNeonCyan, contentColor = Color.Black),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("CALIBRATE FACIAL SYMMETRY (CAMERA)", fontSize = 11.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }

                // Face Exercises List
                item {
                    Text(
                        text = "ACTIVE FACIAL PROTOCOLS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = FitNeonGreen,
                        letterSpacing = 1.sp
                    )
                }

                items(faceList) { ex ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFF141414),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(16.dp))
                            .clickable { onStartExercise(ex.id) }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = ex.iconEmoji, fontSize = 28.sp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = ex.title, fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.White)
                                Text(text = ex.subtitle, fontSize = 11.sp, color = FitTextSecondary)
                                Text(text = "⏱️ ${ex.durationSec}s • 🎯 ${ex.targetMuscles}", fontSize = 10.sp, color = FitNeonCyan)
                            }
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = FitNeonGreen)
                        }
                    }
                }

                // Health Articles Section
                item {
                    Text(
                        text = "RESEARCH & KNOWLEDGE ARTICLES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = FitNeonOrange,
                        letterSpacing = 1.sp
                    )
                }

                items(articles) { article ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFF141414),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(16.dp))
                            .clickable { onArticleClick(article) }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = FitNeonCyan.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = article.category.uppercase(),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = FitNeonCyan,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text(text = "⏱️ ${article.readTimeMinutes} min read", fontSize = 10.sp, color = FitTextSecondary)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = article.title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = article.summary,
                                fontSize = 11.sp,
                                color = FitTextSecondary,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
