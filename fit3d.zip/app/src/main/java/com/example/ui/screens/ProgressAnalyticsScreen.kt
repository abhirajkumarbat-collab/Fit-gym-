package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserEntity
import com.example.data.local.WorkoutHistoryEntity
import com.example.ui.components.GlassPanel
import com.example.ui.theme.FitBgDark
import com.example.ui.theme.FitBgPanel
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonOrange
import com.example.ui.theme.FitNeonPurple
import com.example.ui.theme.FitTextMuted
import com.example.ui.theme.FitTextSecondary

@Composable
fun ProgressAnalyticsScreen(
    user: UserEntity?,
    history: List<WorkoutHistoryEntity>,
    totalWorkouts: Int,
    totalSeconds: Int,
    totalCalories: Int,
    onBack: () -> Unit
) {
    val totalMinutes = totalSeconds / 60

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FitBgDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .background(FitBgPanel)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x1AFFFFFF))
                        .testTag("analytics_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "ATHLETE PERFORMANCE MATRIX",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "Historical Logs & Neuromuscular Volume",
                        fontSize = 11.sp,
                        color = FitNeonGreen
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // High Level Metric Matrix
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricBlock(
                            label = "WORKOUTS",
                            value = "$totalWorkouts",
                            icon = Icons.Default.FitnessCenter,
                            tint = FitNeonGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricBlock(
                            label = "TIME LOGGED",
                            value = "${totalMinutes}m",
                            icon = Icons.Default.Timer,
                            tint = FitNeonCyan,
                            modifier = Modifier.weight(1f)
                        )
                        MetricBlock(
                            label = "CALORIES",
                            value = "$totalCalories",
                            icon = Icons.Default.LocalFireDepartment,
                            tint = FitNeonOrange,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Athlete Profile Card
                item {
                    GlassPanel(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x22FFFFFF))
                                    .border(1.dp, FitNeonGreen, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(user?.avatar ?: "🥷", fontSize = 28.sp)
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = user?.name ?: "Athlete User",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "Goal: ${user?.goal ?: "Strength & Aesthetics"}",
                                    fontSize = 11.sp,
                                    color = FitTextSecondary
                                )
                                Text(
                                    text = "Equipment: ${user?.equipment ?: "Domestic Props"}",
                                    fontSize = 11.sp,
                                    color = FitNeonCyan
                                )
                            }
                        }
                    }
                }

                // Workout Logs History Title
                item {
                    Text(
                        text = "HISTORICAL SESSIONS LOG (${history.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = FitNeonCyan
                    )
                }

                if (history.isEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color(0xFF141414),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("No workouts logged yet.", color = FitTextMuted, fontSize = 13.sp)
                                Text("Engage an exercise protocol to see your stats here!", color = FitTextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                } else {
                    items(history) { session ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color(0xFF141414),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(16.dp))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = session.workoutName,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = FitNeonGreen.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = "+${session.xpEarned} XP",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = FitNeonGreen,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    Text("⏱️ ${session.durationSeconds / 60}m ${session.durationSeconds % 60}s", fontSize = 11.sp, color = FitTextSecondary)
                                    Text("🔥 ${session.caloriesBurned} kcal", fontSize = 11.sp, color = FitNeonOrange)
                                    Text("💪 ${session.setsCompleted} Sets", fontSize = 11.sp, color = FitNeonCyan)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricBlock(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF141414),
        modifier = modifier.border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = FitTextMuted)
        }
    }
}
