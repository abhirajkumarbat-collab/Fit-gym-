package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AdminPostEntity
import com.example.data.local.CommunityChallengeEntity
import com.example.ui.components.GlassPanel
import com.example.ui.theme.FitBgDark
import com.example.ui.theme.FitBgPanel
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonOrange
import com.example.ui.theme.FitTextMuted
import com.example.ui.theme.FitTextSecondary

@Composable
fun CommunityTribesScreen(
    challenges: List<CommunityChallengeEntity>,
    adminPosts: List<AdminPostEntity>,
    onBack: () -> Unit,
    onToggleChallenge: (String, Boolean) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FitBgDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .background(FitBgPanel)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x1AFFFFFF))
                        .testTag("community_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "COMMUNITY TRIBES & CHALLENGES",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "Global Leaderboards & Admin Dispatches",
                        fontSize = 10.sp,
                        color = FitNeonCyan
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Admin Broadcasts Section
                if (adminPosts.isNotEmpty()) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Campaign, contentDescription = null, tint = FitNeonCyan, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ADMIN DISPATCH FEED",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = FitNeonCyan,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    items(adminPosts) { post ->
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = Color(0xFF141A22),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, FitNeonCyan.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = FitNeonCyan.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = "⚡ ${post.category.uppercase()}",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = FitNeonCyan,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                    Text(text = "By ${post.authorName}", fontSize = 10.sp, color = FitTextSecondary)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = post.title,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = post.description,
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.85f),
                                    lineHeight = 17.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Community Challenges Title
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Groups, contentDescription = null, tint = FitNeonGreen, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "LIVE SQUAD CHALLENGES (${challenges.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = FitNeonGreen,
                            letterSpacing = 1.sp
                        )
                    }
                }

                items(challenges) { challenge ->
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = Color(0xFF141414),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (challenge.isJoined) FitNeonGreen else Color(0x22FFFFFF), RoundedCornerShape(18.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = challenge.iconEmoji, fontSize = 28.sp)
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = FitNeonOrange.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "+${challenge.xpReward} XP REWARD",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = FitNeonOrange,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = challenge.title,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            Text(
                                text = challenge.description,
                                fontSize = 11.sp,
                                color = FitTextSecondary,
                                modifier = Modifier.padding(top = 2.dp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "👥 ${challenge.participantsCount} Active Athletes Joined",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = FitNeonCyan
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { onToggleChallenge(challenge.id, challenge.isJoined) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (challenge.isJoined) Color(0x33FFFFFF) else FitNeonGreen,
                                    contentColor = if (challenge.isJoined) Color.White else Color.Black
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(42.dp)
                            ) {
                                Text(
                                    text = if (challenge.isJoined) "✓ ENROLLED IN CHALLENGE" else "JOIN CHALLENGE NOW →",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
