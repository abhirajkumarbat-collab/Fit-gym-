package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.HapticCadencePacerCard
import com.example.ui.components.IntervalTimerComponent
import com.example.ui.components.VoiceCoachModalDialog
import com.example.ui.components.rememberVoiceSpeechState
import com.example.ui.components.rememberSoundEffects
import com.example.ui.theme.FitBgDark
import com.example.ui.theme.FitBgPanel
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonOrange
import com.example.ui.theme.FitNeonPurple
import com.example.ui.theme.FitTextMuted
import com.example.ui.theme.FitTextSecondary
import com.example.viewmodel.WorkoutSessionState

@Composable
fun WorkoutPlayerScreen(
    session: WorkoutSessionState,
    onCompleteSet: () -> Unit,
    onAddRestSeconds: (Int) -> Unit,
    onSkipRest: () -> Unit,
    onTogglePause: () -> Unit,
    onFinishEarly: () -> Unit,
    onOpenCameraMirror: () -> Unit,
    onAskVoiceAi: (String) -> Unit = {}
) {
    val exercise = session.exercise
    val isPreparing = session.isPreparing
    val isResting = session.isResting
    val soundEffects = rememberSoundEffects()
    var showVoiceCoachModal by remember { mutableStateOf(false) }

    // Audio cue for countdown
    LaunchedEffect(session.prepSecondsLeft, session.isPreparing) {
        if (session.isPreparing) {
            if (session.prepSecondsLeft in 1..3) {
                soundEffects.playCountdownBeep()
            } else if (session.prepSecondsLeft == 0) {
                soundEffects.playGoSound()
            }
        }
    }

    LaunchedEffect(session.restSecondsLeft, session.isResting) {
        if (session.isResting && session.restSecondsLeft in 1..3) {
            soundEffects.playCountdownBeep()
        }
    }

    val voiceSpeechState = rememberVoiceSpeechState { transcribed ->
        onAskVoiceAi(transcribed)
    }

    val infiniteTransition = rememberInfiniteTransition(label = "pulseRing")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FitBgDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .background(FitBgPanel)
                    .padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (session.isPaused) Color(0xFFFFC107) else FitNeonGreen)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isPreparing) "PREPARATION" else if (isResting) "REST PERIOD" else "ACTIVE SET ${session.currentSet}/${session.totalSets}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 1.sp
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { showVoiceCoachModal = true },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(FitNeonCyan.copy(alpha = 0.2f))
                            .border(1.dp, FitNeonCyan, RoundedCornerShape(12.dp))
                            .testTag("voice_coach_icon_button")
                    ) {
                        Icon(Icons.Default.GraphicEq, contentDescription = "Voice Coach", tint = FitNeonCyan, modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = onFinishEarly,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x22FFFFFF))
                            .testTag("close_workout_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Exit", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Exercise Name & Prop Badge
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = exercise?.title ?: "Full Body Blast",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = FitNeonGreen.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "📦 Prop: ${exercise?.domesticProp ?: "Domestic Weight"}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = FitNeonGreen,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                // Main Central Graphic Timer / Set Counter
                if (isPreparing) {
                    // Prep 10-second countdown
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = Color(0xFF141414),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(2.dp, FitNeonCyan, RoundedCornerShape(24.dp))
                            .padding(24.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "GET READY",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = FitNeonCyan,
                                letterSpacing = 2.sp
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "${session.prepSecondsLeft}",
                                fontSize = 72.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                modifier = Modifier.scale(pulseScale)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Grab your ${exercise?.domesticProp ?: "prop"} and assume position!",
                                fontSize = 12.sp,
                                color = FitTextSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    IntervalTimerComponent(
                        secondsRemaining = if (isResting) session.restSecondsLeft else session.elapsedSeconds,
                        totalDurationSeconds = if (isResting) (exercise?.restDurationSec ?: 30) else (exercise?.durationSec ?: 60),
                        label = if (isResting) "Rest Interval" else "Set ${session.currentSet} of ${session.totalSets}",
                        subLabel = if (isResting) "Breathe deeply and hydrate" else "${session.currentReps} Target Repetitions",
                        isPaused = session.isPaused,
                        isRestPeriod = isResting,
                        onTogglePause = onTogglePause,
                        onAddSeconds = onAddRestSeconds,
                        onSkip = onSkipRest
                    )
                }

                // Haptic Cadence Pacemaker
                HapticCadencePacerCard()

                // Voice Coach Form Tip
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF111714),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, FitNeonGreen.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = FitNeonGreen,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "CYBER COACH CUE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = FitNeonGreen,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = exercise?.coachVoiceTip ?: "Control the negative eccentric descent. Focus on muscle contraction!",
                                fontSize = 12.sp,
                                color = Color.White,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                // Primary Bottom Action Bar
                if (!isPreparing) {
                    if (isResting) {
                        Button(
                            onClick = {
                                soundEffects.playGoSound()
                                onSkipRest()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FitNeonGreen, contentColor = Color.Black),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("skip_rest_and_start_set_button")
                        ) {
                            Text("READY FOR SET ${session.currentSet + 1} ⚡", fontSize = 14.sp, fontWeight = FontWeight.Black)
                        }
                    } else {
                        Button(
                            onClick = {
                                if (session.currentSet >= session.totalSets) {
                                    soundEffects.playWorkoutVictoryFanfare()
                                } else {
                                    soundEffects.playSetCompleteSound()
                                }
                                onCompleteSet()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FitNeonGreen, contentColor = Color.Black),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("complete_set_button")
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (session.currentSet >= session.totalSets) "COMPLETE WORKOUT 💯" else "COMPLETE SET ${session.currentSet} ✓",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                // Open Live Camera Mirror Button
                OutlinedButton(
                    onClick = onOpenCameraMirror,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = FitNeonCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                        .testTag("workout_camera_mirror_button")
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null, tint = FitNeonCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("OPEN LIVE CAMERA FORM MIRROR", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Voice Coach Modal
        if (showVoiceCoachModal) {
            VoiceCoachModalDialog(
                voiceState = voiceSpeechState,
                exerciseName = exercise?.title,
                currentSet = session.currentSet,
                onDismiss = { showVoiceCoachModal = false },
                onSubmitToAi = { query ->
                    onAskVoiceAi(query)
                }
            )
        }
    }
}
