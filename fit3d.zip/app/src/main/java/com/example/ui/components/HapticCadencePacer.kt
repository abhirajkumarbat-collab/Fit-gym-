package com.example.ui.components

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonOrange
import com.example.ui.theme.FitNeonPurple
import com.example.ui.theme.FitTextMuted
import com.example.ui.theme.FitTextSecondary
import kotlinx.coroutines.delay

enum class CadencePhase(val label: String, val cue: String, val color: Color) {
    ECCENTRIC("LOWER (Negative)", "Control Down ⬇️", FitNeonCyan),
    PAUSE_BOTTOM("PAUSE (Hold)", "Squeeze & Stretch ⏸️", FitNeonOrange),
    CONCENTRIC("LIFT (Explode)", "Power Up ⬆️", FitNeonGreen),
    RESET("RESET", "Lockout 🔒", FitNeonPurple)
}

data class TempoPreset(
    val name: String,
    val eccentricSec: Int,
    val pauseSec: Int,
    val concentricSec: Int,
    val resetSec: Int,
    val description: String
)

val DEFAULT_TEMPO_PRESETS = listOf(
    TempoPreset("3-1-1-0 Mass", 3, 1, 1, 0, "Heavy compound strength & muscle hypertrophy"),
    TempoPreset("2-0-2-0 Hypertrophy", 2, 0, 2, 0, "Constant tension rhythmic pumping"),
    TempoPreset("4-2-1-0 Deep TUT", 4, 2, 1, 0, "Maximum Time-Under-Tension & eccentric overload")
)

class HapticCadenceController(private val context: Context) {
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    fun playTick() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                vibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(20, 60))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(20)
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    fun playPauseWarning() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val timings = longArrayOf(0, 35, 40, 35)
                val amplitudes = intArrayOf(0, 150, 0, 150)
                vibrator?.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(longArrayOf(0, 35, 40, 35), -1)
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    fun playExplosiveDrive() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                vibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK))
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(70, 255))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(70)
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    fun playLockout() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(45, 180))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(45)
            }
        } catch (e: Exception) {
            // ignore
        }
    }
}

@Composable
fun HapticCadencePacerCard(
    modifier: Modifier = Modifier,
    initialActive: Boolean = false,
    onRepCounted: (Int) -> Unit = {}
) {
    val context = LocalContext.current
    val hapticController = remember { HapticCadenceController(context) }
    var isPacerRunning by remember { mutableStateOf(initialActive) }
    var isHapticEnabled by remember { mutableStateOf(true) }
    var selectedPresetIndex by remember { mutableIntStateOf(0) }
    val currentPreset = DEFAULT_TEMPO_PRESETS[selectedPresetIndex]

    var currentPhase by remember { mutableStateOf(CadencePhase.ECCENTRIC) }
    var secondsInPhase by remember { mutableIntStateOf(0) }
    var completedReps by remember { mutableIntStateOf(0) }

    val infiniteTransition = rememberInfiniteTransition(label = "pacerPulse")
    val pacerScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pacerScale"
    )

    LaunchedEffect(isPacerRunning, currentPreset, isHapticEnabled) {
        if (!isPacerRunning) return@LaunchedEffect
        while (isPacerRunning) {
            // 1. Eccentric Phase (Down)
            currentPhase = CadencePhase.ECCENTRIC
            for (sec in 1..currentPreset.eccentricSec) {
                secondsInPhase = sec
                if (isHapticEnabled) hapticController.playTick()
                delay(1000)
            }
            // 2. Pause Phase (Hold at bottom)
            if (currentPreset.pauseSec > 0) {
                currentPhase = CadencePhase.PAUSE_BOTTOM
                for (sec in 1..currentPreset.pauseSec) {
                    secondsInPhase = sec
                    if (isHapticEnabled) hapticController.playPauseWarning()
                    delay(1000)
                }
            }
            // 3. Concentric Phase (Explode Up)
            currentPhase = CadencePhase.CONCENTRIC
            for (sec in 1..currentPreset.concentricSec) {
                secondsInPhase = sec
                if (isHapticEnabled) hapticController.playExplosiveDrive()
                delay(1000)
            }
            // 4. Reset Phase (Lockout)
            if (currentPreset.resetSec > 0) {
                currentPhase = CadencePhase.RESET
                for (sec in 1..currentPreset.resetSec) {
                    secondsInPhase = sec
                    if (isHapticEnabled) hapticController.playLockout()
                    delay(1000)
                }
            }
            // Rep Completed
            completedReps += 1
            onRepCounted(completedReps)
            if (isHapticEnabled) hapticController.playLockout()
        }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, currentPhase.color.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
        color = Color(0xFF10151C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(currentPhase.color.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Vibration,
                            contentDescription = null,
                            tint = currentPhase.color,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "CADENCE HAPTIC PACER",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "Tactile beat for reps with screen dimmed",
                            fontSize = 10.sp,
                            color = FitTextSecondary
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isHapticEnabled) "HAPTIC ON" else "OFF",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isHapticEnabled) FitNeonCyan else FitTextMuted
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Switch(
                        checked = isHapticEnabled,
                        onCheckedChange = { isHapticEnabled = it },
                        modifier = Modifier.scale(0.7f),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = FitNeonGreen,
                            checkedTrackColor = FitNeonGreen.copy(alpha = 0.3f),
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = Color.DarkGray
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                DEFAULT_TEMPO_PRESETS.forEachIndexed { index, preset ->
                    val isSelected = selectedPresetIndex == index
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) currentPhase.color.copy(alpha = 0.25f) else Color(0x15FFFFFF),
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, currentPhase.color) else null,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                selectedPresetIndex = index
                                completedReps = 0
                            }
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = preset.name,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) currentPhase.color else Color.White
                            )
                            Text(
                                text = "${preset.eccentricSec}-${preset.pauseSec}-${preset.concentricSec}",
                                fontSize = 8.sp,
                                color = FitTextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isPacerRunning) currentPhase.label else "PACER IDLE",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isPacerRunning) currentPhase.color else FitTextMuted
                    )
                    Text(
                        text = if (isPacerRunning) currentPhase.cue else "Press Start to engage rhythm",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "$completedReps REPS",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = FitNeonGreen
                        )
                        Text(
                            text = "Pacemaker Beat",
                            fontSize = 9.sp,
                            color = FitTextSecondary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    IconButton(
                        onClick = { isPacerRunning = !isPacerRunning },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (isPacerRunning) Brush.radialGradient(listOf(Color(0xFFFF3B5F), Color(0xFF990022)))
                                else Brush.radialGradient(listOf(FitNeonGreen, Color(0xFF009944)))
                            )
                    ) {
                        Icon(
                            imageVector = if (isPacerRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = if (isPacerRunning) "Stop" else "Start",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
