package com.example.ui.theme

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

val RainbowColors = listOf(
    FitNeonRed,
    FitNeonOrange,
    FitNeonYellow,
    FitNeonGreen,
    FitNeonCyan,
    FitNeonBlue,
    FitNeonPurple,
    FitNeonRed
)

@Composable
fun rememberRainbowBrush(durationMs: Int = 1000): Brush {
    val transition = rememberInfiniteTransition(label = "rapidRainbow")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = durationMs, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rainbowProgress"
    )

    val angle = progress * 2 * Math.PI
    val xOffset = cos(angle).toFloat() * 500f
    val yOffset = sin(angle).toFloat() * 500f

    return Brush.linearGradient(
        colors = RainbowColors,
        start = Offset(500f - xOffset, 500f - yOffset),
        end = Offset(500f + xOffset, 500f + yOffset)
    )
}

fun Modifier.rainbowBorder(
    strokeWidth: Dp = 2.dp,
    shape: Shape = RoundedCornerShape(20.dp),
    durationMs: Int = 1000
): Modifier = composed {
    val brush = rememberRainbowBrush(durationMs = durationMs)
    this.border(width = strokeWidth, brush = brush, shape = shape)
}
