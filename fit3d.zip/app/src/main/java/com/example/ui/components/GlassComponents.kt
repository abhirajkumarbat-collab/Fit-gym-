package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.ui.theme.FitAdminPurple
import com.example.ui.theme.FitBgCard
import com.example.ui.theme.FitBgPanel
import com.example.ui.theme.FitBorder
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonPurple
import com.example.ui.theme.FitTextPrimary
import com.example.ui.theme.FitTextSecondary
import com.example.ui.theme.rememberRainbowBrush

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    borderColor: Color = FitBorder,
    backgroundColor: Color = FitBgCard,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(backgroundColor)
            .border(1.dp, borderColor, shape)
            .padding(18.dp)
    ) {
        content()
    }
}

@Composable
fun RainbowButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    testTag: String = "primary_action_button"
) {
    val rainbowBrush = rememberRainbowBrush()
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF111111))
            .border(2.dp, rainbowBrush, RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            fontSize = 15.sp,
            fontWeight = FontWeight.Black,
            color = Color.White,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun UserRoleBadge(
    isAdmin: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(99.dp),
        color = if (isAdmin) FitAdminPurple.copy(alpha = 0.15f) else FitNeonGreen.copy(alpha = 0.12f),
        modifier = modifier.border(
            width = 1.dp,
            color = if (isAdmin) FitAdminPurple.copy(alpha = 0.4f) else FitNeonGreen.copy(alpha = 0.3f),
            shape = RoundedCornerShape(99.dp)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(if (isAdmin) FitAdminPurple else FitNeonGreen, CircleShape)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isAdmin) "🟣 ADMINISTRATOR • COMMAND ACCESS" else "🟢 STANDARD USER • TRAINING ACCESS",
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isAdmin) Color(0xFFE1BEE7) else Color(0xFFCAFFDD),
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun TopBarHeader(
    title: String = "FIT3D SYSTEM 🇮🇳",
    avatar: String = "🥷",
    profileImageUri: String = "",
    onSearchClick: () -> Unit = {},
    onProfileClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(FitBgPanel.copy(alpha = 0.85f))
            .border(width = 0.5.dp, color = Color(0x1AFFFFFF))
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.Black)
                    .border(1.5.dp, FitNeonGreen.copy(alpha = 0.6f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.fit3d_app_logo_1787922140679),
                    contentDescription = "FIT3D Logo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "AI CYBER FITNESS",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = FitNeonCyan,
                    letterSpacing = 1.sp
                )
            }
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = onSearchClick,
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x1AFFFFFF))
                    .border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(12.dp))
                    .testTag("search_icon_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF333333), Color(0xFF111111))
                        )
                    )
                    .border(1.5.dp, FitNeonGreen.copy(alpha = 0.8f), CircleShape)
                    .clickable(onClick = onProfileClick)
                    .testTag("profile_avatar_thumbnail"),
                contentAlignment = Alignment.Center
            ) {
                if (profileImageUri.isNotBlank()) {
                    AsyncImage(
                        model = profileImageUri,
                        contentDescription = "User Profile Picture",
                        modifier = Modifier.fillMaxSize().clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Text(text = avatar, fontSize = 20.sp)
                }
            }
        }
    }
}

@Composable
fun AdminCommandFab(
    isCommandModeActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val rainbowBrush = rememberRainbowBrush(800)
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(999.dp),
        color = Color(0xFF0F0F0F),
        shadowElevation = 12.dp,
        modifier = modifier
            .height(52.dp)
            .border(2.dp, rainbowBrush, RoundedCornerShape(999.dp))
            .testTag("admin_command_mode_fab")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.FlashOn,
                contentDescription = null,
                tint = FitNeonGreen,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isCommandModeActive) "⚡ EXIT COMMAND ⚡" else "⚡ COMMAND MODE ⚡",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun SectorCard(
    title: String,
    tagline: String,
    iconEmoji: String,
    badgeText: String,
    onEnterClick: () -> Unit,
    modifier: Modifier = Modifier,
    extraContent: (@Composable () -> Unit)? = null
) {
    GlassPanel(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onEnterClick)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x1FFFFFFF))
                        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = iconEmoji, fontSize = 28.sp)
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = FitNeonGreen.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = badgeText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = FitNeonGreen,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = Color.White
            )
            Text(
                text = tagline,
                fontSize = 13.sp,
                color = FitTextSecondary,
                modifier = Modifier.padding(top = 4.dp)
            )
            if (extraContent != null) {
                Spacer(modifier = Modifier.height(14.dp))
                extraContent()
            }
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = onEnterClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0x22FFFFFF),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp))
            ) {
                Text(
                    text = "ENTER ${title.split(" ")[0]} →",
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun ReadinessCheckDialog(
    currentScore: Int,
    onDismiss: () -> Unit,
    onConfirm: (energy: Int, sleep: Int, soreness: Int, stress: Int) -> Unit
) {
    var energy by remember { mutableFloatStateOf(4f) }
    var sleep by remember { mutableFloatStateOf(4f) }
    var soreness by remember { mutableFloatStateOf(2f) }
    var stress by remember { mutableFloatStateOf(2f) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(26.dp),
            color = FitBgPanel,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, FitNeonGreen.copy(alpha = 0.4f), RoundedCornerShape(26.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "DAILY READINESS 🧬",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = FitNeonGreen
                        )
                        Text(
                            text = "Smart Fitness DNA Calibration",
                            fontSize = 11.sp,
                            color = FitTextSecondary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                // Energy Slider
                Text(text = "⚡ Energy Level: ${energy.toInt()}/5", fontSize = 12.sp, color = Color.White)
                Slider(
                    value = energy,
                    onValueChange = { energy = it },
                    valueRange = 1f..5f,
                    steps = 3,
                    colors = SliderDefaults.colors(thumbColor = FitNeonGreen, activeTrackColor = FitNeonGreen)
                )
                // Sleep Quality
                Text(text = "🌙 Sleep Quality: ${sleep.toInt()}/5", fontSize = 12.sp, color = Color.White)
                Slider(
                    value = sleep,
                    onValueChange = { sleep = it },
                    valueRange = 1f..5f,
                    steps = 3,
                    colors = SliderDefaults.colors(thumbColor = FitNeonCyan, activeTrackColor = FitNeonCyan)
                )
                // Muscle Soreness (Lower is better)
                Text(text = "💪 Muscle Soreness: ${soreness.toInt()}/5 (1=Fresh, 5=Severe)", fontSize = 12.sp, color = Color.White)
                Slider(
                    value = soreness,
                    onValueChange = { soreness = it },
                    valueRange = 1f..5f,
                    steps = 3,
                    colors = SliderDefaults.colors(thumbColor = FitNeonPurple, activeTrackColor = FitNeonPurple)
                )
                // Stress Level
                Text(text = "🧘 Mental Stress: ${stress.toInt()}/5", fontSize = 12.sp, color = Color.White)
                Slider(
                    value = stress,
                    onValueChange = { stress = it },
                    valueRange = 1f..5f,
                    steps = 3,
                    colors = SliderDefaults.colors(thumbColor = FitNeonGreen, activeTrackColor = FitNeonGreen)
                )
                Spacer(modifier = Modifier.height(16.dp))
                RainbowButton(
                    text = "CALCULATE READINESS ⚡",
                    onClick = {
                        onConfirm(energy.toInt(), sleep.toInt(), soreness.toInt(), stress.toInt())
                        onDismiss()
                    }
                )
            }
        }
    }
}
