package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FIT3D Luxury Dark Theme Palette
val FitBgDark = Color(0xFF121212)
val FitBgPanel = Color(0xFF181818)
val FitBgCard = Color(0xCC1E1E1E)
val FitBgSurface = Color(0xFF242424)
val FitBorder = Color(0x26FFFFFF)
val FitBorderLight = Color(0x40FFFFFF)

// Professional Polish Theme Palette
val PolishBgDark = Color(0xFF1A1C1E)
val PolishSurface = Color(0xFF252729)
val PolishSurfaceVariant = Color(0xFF2F3033)
val PolishAccentPrimary = Color(0xFFD0E4FF)
val PolishAccentOnPrimary = Color(0xFF00315E)
val PolishTextPrimary = Color(0xFFE2E2E6)
val PolishTextSecondary = Color(0xFFC4C6CF)
val PolishTextMuted = Color(0xFF8E9199)

// Core Material & Cyber Theme Colors
val BackgroundBlack = Color(0xFF0F1216)
val SurfaceDark = Color(0xFF161B22)
val SurfaceCardDark = Color(0xFF1C222C)
val NeonCyberGreen = Color(0xFF00E676)
val NeonOrange = Color(0xFFFF6D00)

// Neon Accents
val FitNeonGreen = Color(0xFF39FF88)
val FitNeonGreenSoft = Color(0x2639FF88)
val FitNeonCyan = Color(0xFF00E5FF)
val FitNeonPurple = Color(0xFF9D00FF)
val FitNeonRed = Color(0xFFFF003C)
val FitNeonOrange = Color(0xFFFF7800)
val FitNeonYellow = Color(0xFFFFE600)
val FitNeonBlue = Color(0xFF008CFF)

// Functional colors
val FitTextPrimary = Color(0xFFFFFFFF)
val FitTextSecondary = Color(0xFFA7A7A7)
val FitTextMuted = Color(0xFF707070)
val FitDanger = Color(0xFFFF3B5F)
val FitGold = Color(0xFFFFD700)
val FitAdminPurple = Color(0xFFB388FF)

// 4 Dynamic Theme Color Constants
val SolarGoldPrimary = Color(0xFFFFD700)
val SolarGoldSecondary = Color(0xFFFF8F00)
val SolarGoldBgDark = Color(0xFF161208)
val SolarGoldBgPanel = Color(0xFF221C0E)
val SolarGoldBgCard = Color(0xCC2C2414)

val UltraVioletPrimary = Color(0xFFB388FF)
val UltraVioletSecondary = Color(0xFFFF4081)
val UltraVioletBgDark = Color(0xFF100A1C)
val UltraVioletBgPanel = Color(0xFF1A122B)
val UltraVioletBgCard = Color(0xCC23193B)

val StealthObsidianPrimary = Color(0xFFE2E8F0)
val StealthObsidianSecondary = Color(0xFF00E5FF)
val StealthObsidianBgDark = Color(0xFF0A0C10)
val StealthObsidianBgPanel = Color(0xFF12161E)
val StealthObsidianBgCard = Color(0xCC181E29)
