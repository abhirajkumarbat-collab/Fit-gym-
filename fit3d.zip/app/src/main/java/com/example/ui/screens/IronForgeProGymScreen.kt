package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassPanel
import com.example.ui.theme.FitBgDark
import com.example.ui.theme.FitBgPanel
import com.example.ui.theme.FitDanger
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitNeonOrange
import com.example.ui.theme.FitNeonPurple
import com.example.ui.theme.FitTextMuted
import com.example.ui.theme.FitTextSecondary
import com.example.viewmodel.IronForgeChatMessage
import com.example.viewmodel.IronForgeGymStation

@Composable
fun IronForgeProGymScreen(
    liveEnvironment: String,
    liveIpAddress: String,
    liveConcurrentLifters: Int,
    chatMessages: List<IronForgeChatMessage>,
    stations: List<IronForgeGymStation>,
    telemetryLogs: List<String>,
    onBack: () -> Unit,
    onSetEnvironment: (String) -> Unit,
    onSendChat: (String) -> Unit,
    onToggleStation: (String) -> Unit,
    onTriggerMigrationSync: () -> Unit,
    onTestApi: (String) -> Unit
) {
    var userChatInput by remember { mutableStateOf("") }
    var calcWeight by remember { mutableFloatStateOf(100f) }
    var calcReps by remember { mutableFloatStateOf(5f) }

    // Epley Formula 1RM Calculation: Weight * (1 + Reps/30)
    val calculated1RM = calcWeight * (1f + (calcReps / 30f))

    val infiniteTransition = rememberInfiniteTransition(label = "liveGlow")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseGlow"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(FitBgDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .background(FitBgPanel)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x1AFFFFFF))
                        .testTag("ironforge_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "IRONFORGE PRO GYM 🏋️",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "Heavy Barbell Vault • Live Racks • 1RM Calculator",
                        fontSize = 10.sp,
                        color = FitNeonCyan
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = FitNeonGreen.copy(alpha = 0.15f),
                    modifier = Modifier.border(1.dp, FitNeonGreen.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(FitNeonGreen.copy(alpha = pulseGlow))
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$liveConcurrentLifters LIVE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            color = FitNeonGreen
                        )
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Live Node & Environment Selector Card
                item {
                    GlassPanel(
                        modifier = Modifier.fillMaxWidth(),
                        borderColor = FitNeonCyan.copy(alpha = 0.4f)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "LIVE CLOUD DEPLOYMENT CORE",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    color = FitNeonCyan,
                                    letterSpacing = 1.sp
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (liveEnvironment == "PRODUCTION") FitNeonGreen.copy(alpha = 0.2f) else FitNeonOrange.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "⚡ ENV: $liveEnvironment",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (liveEnvironment == "PRODUCTION") FitNeonGreen else FitNeonOrange,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "IP Cluster: $liveIpAddress",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.8f),
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("PRODUCTION", "STAGING", "CANARY").forEach { env ->
                                    val isSelected = liveEnvironment == env
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) FitNeonCyan else Color(0x1AFFFFFF),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { onSetEnvironment(env) }
                                    ) {
                                        Text(
                                            text = env,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.Black else Color.White,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Epley 1RM Max & Training Load Calculator
                item {
                    GlassPanel(
                        modifier = Modifier.fillMaxWidth(),
                        borderColor = FitNeonGreen.copy(alpha = 0.4f)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Speed, contentDescription = null, tint = FitNeonGreen, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "ONE-REP MAX (1RM) EPLEY ENGINE",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        color = FitNeonGreen
                                    )
                                }
                                Text(
                                    text = "ISO ACCREDITED",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FitTextMuted
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${String.format("%.1f", calculated1RM)} KG",
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Estimated 1RM (${String.format("%.1f", calculated1RM * 2.20462f)} lbs)",
                                        fontSize = 11.sp,
                                        color = FitNeonCyan
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "75% Rep Hypertrophy: ${String.format("%.1f", calculated1RM * 0.75f)} kg",
                                        fontSize = 10.sp,
                                        color = Color.White.copy(alpha = 0.8f)
                                    )
                                    Text(
                                        text = "85% Strength Focus: ${String.format("%.1f", calculated1RM * 0.85f)} kg",
                                        fontSize = 10.sp,
                                        color = FitNeonGreen
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(60f, 80f, 100f, 120f, 140f).forEach { w ->
                                    val isSel = calcWeight == w
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isSel) FitNeonGreen.copy(alpha = 0.3f) else Color(0x1AFFFFFF),
                                        modifier = Modifier
                                            .weight(1f)
                                            .border(1.dp, if (isSel) FitNeonGreen else Color.Transparent, RoundedCornerShape(6.dp))
                                            .clickable { calcWeight = w }
                                    ) {
                                        Text(
                                            text = "${w.toInt()}kg",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSel) FitNeonGreen else Color.White,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Live Gym Rack & Station Occupancy Tracker
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LIVE GYM RACKS & BENCHES (${stations.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "TAP TO OCCUPY / FREE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = FitNeonCyan
                        )
                    }
                }

                items(stations) { station ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (station.isOccupied) Color(0xFF1F1418) else Color(0xFF121B16),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (station.isOccupied) FitDanger.copy(alpha = 0.5f) else FitNeonGreen.copy(alpha = 0.5f),
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { onToggleStation(station.id) }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = station.name,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "${station.zone} • ${if (station.isOccupied) "Occupied by ${station.currentUser} (${station.setsRemaining} sets left)" else "Ready for use"}",
                                    fontSize = 10.sp,
                                    color = if (station.isOccupied) FitNeonOrange else FitNeonGreen
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (station.isOccupied) FitDanger else FitNeonGreen
                            ) {
                                Text(
                                    text = station.status,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.Black,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Live Lifter Global Chat Feed
                item {
                    Text(
                        text = "LIVE LIFTER COMMUNITY SHOUTBOX",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = FitNeonPurple,
                        letterSpacing = 1.sp
                    )
                }

                items(chatMessages.take(4)) { chat ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF141720),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = chat.sender,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        color = FitNeonCyan
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0x22FFFFFF)
                                    ) {
                                        Text(
                                            text = chat.badge,
                                            fontSize = 7.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                                Text(text = chat.timeAgo, fontSize = 9.sp, color = FitTextMuted)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = chat.text,
                                fontSize = 12.sp,
                                color = Color.White
                            )
                        }
                    }
                }

                // Chat Input Row
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = userChatInput,
                            onValueChange = { userChatInput = it },
                            placeholder = { Text("Shout PR or spot request to live gym...", color = FitTextMuted, fontSize = 11.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = FitNeonCyan,
                                unfocusedBorderColor = Color(0x33FFFFFF),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                if (userChatInput.isNotBlank()) {
                                    onSendChat(userChatInput.trim())
                                    userChatInput = ""
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(FitNeonCyan)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send",
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Zero Downtime Cloud Actions
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F141C))
                            .padding(14.dp)
                    ) {
                        Text(
                            text = "DIAGNOSTIC & TELEMETRY SUITE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            color = FitNeonGreen,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onTriggerMigrationSync,
                                colors = ButtonDefaults.buttonColors(containerColor = FitNeonGreen, contentColor = Color.Black),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("MIGRATION SYNC ⚡", fontSize = 10.sp, fontWeight = FontWeight.Black)
                            }
                            Button(
                                onClick = { onTestApi("/v3/telemetry") },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0x22FFFFFF), contentColor = Color.White),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("TEST API (SSL)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
