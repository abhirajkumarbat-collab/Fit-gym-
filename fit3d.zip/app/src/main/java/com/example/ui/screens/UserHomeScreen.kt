package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.ExerciseEntity
import com.example.data.local.FourWeekPlanEntity
import com.example.data.local.UserEntity
import com.example.ui.components.AdminCommandFab
import com.example.ui.components.BodyMuscle
import com.example.ui.components.MuscleViewer3D
import com.example.ui.components.ReadinessCheckDialog
import com.example.ui.components.SectorCard
import com.example.ui.components.TopBarHeader
import com.example.ui.components.rememberSoundEffects
import com.example.ui.theme.BackgroundBlack
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.NeonCyberGreen
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.SurfaceCardDark
import com.example.viewmodel.AppScreen

@Composable
fun UserHomeScreen(
    user: UserEntity?,
    exercises: List<ExerciseEntity>,
    fourWeekPlans: List<FourWeekPlanEntity> = emptyList(),
    activeMuscle: BodyMuscle,
    isGreenTargetEnabled: Boolean,
    activeTheme: String = "Cyber Green",
    onThemeChange: (String) -> Unit = {},
    onSectorClick: (String) -> Unit,
    onExerciseClick: (String) -> Unit,
    onMuscleSelected: (BodyMuscle) -> Unit,
    onToggleGreenTarget: (Boolean) -> Unit,
    onToggleCommandMode: () -> Unit,
    onSearchClick: () -> Unit,
    onNavigate: (AppScreen) -> Unit,
    onUpdateReadiness: (energy: Int, sleep: Int, soreness: Int, stress: Int) -> Unit,
    onUpdateProfileImage: (String) -> Unit = {}
) {
    val soundEffects = rememberSoundEffects()
    var showReadinessDialog by remember { mutableStateOf(false) }
    var showProfilePhotoDialog by remember { mutableStateOf(false) }
    var selectedFocusFilter by remember { mutableStateOf("Full Body") }
    var selectedLevelIndex by remember { mutableIntStateOf(0) } // 0: Beginner, 1: Intermediate, 2: Advanced

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            soundEffects.playBiometricSuccessSound()
            onUpdateProfileImage(uri.toString())
            showProfilePhotoDialog = false
        }
    }

    val isAdmin = user?.role == "admin"
    val focusAreas = listOf("Full Body", "Chest", "ABS", "Arm", "Leg", "Shoulder & Back")
    val levels = listOf("Beginner", "Intermediate", "Advanced")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundBlack)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Sticky Header with Profile Image linking
            TopBarHeader(
                title = "FIT3D SYSTEM 🇮🇳",
                avatar = user?.avatar ?: "🥷",
                profileImageUri = user?.profileImageUri ?: "",
                onSearchClick = {
                    soundEffects.playClickSound()
                    onSearchClick()
                },
                onProfileClick = {
                    soundEffects.playClickSound()
                    showProfilePhotoDialog = true
                }
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("user_home_scrollable_list"),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Dynamic Theme Switcher Card
                item {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = SurfaceCardDark,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Palette,
                                        contentDescription = null,
                                        tint = NeonCyberGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "LIVE THEME ENGINE",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                }
                                Text(
                                    text = "ROOM PERSISTED ⚡",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NeonCyberGreen
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            val themeList = listOf("Cyber Green", "Professional Polish", "Solar Gold", "Ultra Violet", "Stealth Obsidian")
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(themeList) { themeName ->
                                    val isSelected = activeTheme.equals(themeName, ignoreCase = true) ||
                                            (themeName == "Cyber Green" && (activeTheme == "CYBER_GREEN" || activeTheme.isEmpty())) ||
                                            (themeName == "Professional Polish" && activeTheme == "PROFESSIONAL_POLISH") ||
                                            (themeName == "Solar Gold" && activeTheme == "SOLAR_GOLD") ||
                                            (themeName == "Ultra Violet" && activeTheme == "ULTRA_VIOLET") ||
                                            (themeName == "Stealth Obsidian" && activeTheme == "STEALTH_OBSIDIAN")
                                    val themeColor = when (themeName) {
                                        "Professional Polish" -> Color(0xFFD0E4FF)
                                        "Solar Gold" -> Color(0xFFFFB800)
                                        "Ultra Violet" -> Color(0xFFB026FF)
                                        "Stealth Obsidian" -> Color(0xFF9E9E9E)
                                        else -> Color(0xFF00FF66)
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (isSelected) themeColor.copy(alpha = 0.22f) else Color(0x15FFFFFF),
                                        modifier = Modifier
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) themeColor else Color(0x22FFFFFF),
                                                shape = RoundedCornerShape(12.dp)
                                            )
                                            .clickable {
                                                soundEffects.playThemeSwitchSound()
                                                onThemeChange(themeName)
                                            }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .clip(CircleShape)
                                                    .background(themeColor)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = themeName,
                                                fontSize = 11.sp,
                                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
                                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.7f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Athlete Status HUD (Level, Streak, Readiness)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = SurfaceCardDark,
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(text = "LEVEL ${user?.level ?: 1}", fontSize = 12.sp, fontWeight = FontWeight.Black, color = NeonCyberGreen)
                                Text(text = "${user?.xp ?: 240} / 500 XP", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                                Spacer(modifier = Modifier.height(6.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(Color.White.copy(alpha = 0.15f))
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth((user?.xp ?: 240) % 500 / 500f)
                                            .height(4.dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(NeonCyberGreen)
                                    )
                                }
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = SurfaceCardDark,
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(text = "🔥 ${user?.streak ?: 6} DAYS", fontSize = 12.sp, fontWeight = FontWeight.Black, color = NeonOrange)
                                Text(text = "Consistent Streak", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = "DOMINATING ⚡", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = NeonOrange)
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = SurfaceCardDark,
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, Color(0xFF00B0FF).copy(alpha = 0.3f), RoundedCornerShape(18.dp))
                                .clickable { showReadinessDialog = true }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(text = "🧬 ${user?.readinessScore ?: 85}%", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color(0xFF00B0FF))
                                Text(text = "Readiness", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = "CALIBRATE ⚡", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00B0FF))
                            }
                        }
                    }
                }

                // 4-Week Plan Banner
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceCardDark)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color(0xFF0D253A),
                                            SurfaceCardDark
                                        )
                                    )
                                )
                                .padding(18.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = NeonOrange
                                    ) {
                                        Text(
                                            "4-WEEK PLAN",
                                            color = Color.Black,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color.Black.copy(alpha = 0.4f)
                                    ) {
                                        Text(
                                            "🔥 4,680 KCAL EST.",
                                            color = NeonOrange,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    "Full Body Domestic Shred",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 20.sp,
                                    color = Color.White
                                )
                                Text(
                                    "28 Days transformation with zero gym equipment. 24 min / day.",
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    (1..7).forEach { d ->
                                        val isDone = d < 4
                                        val isCurrent = d == 4
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (isDone) NeonCyberGreen
                                                    else if (isCurrent) NeonOrange
                                                    else Color.White.copy(alpha = 0.08f)
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (isDone) {
                                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                            } else {
                                                Text(
                                                    "$d",
                                                    color = if (isCurrent) Color.Black else Color.White.copy(alpha = 0.7f),
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(14.dp))
                                Button(
                                    onClick = {
                                        val firstEx = exercises.firstOrNull()
                                        if (firstEx != null) {
                                            onExerciseClick(firstEx.id)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyberGreen, contentColor = Color.Black),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("CONTINUE DAY 4 WORKOUT", fontWeight = FontWeight.Black, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }

                // Level Switcher Tabs (Beginner / Intermediate / Advanced)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        levels.forEachIndexed { index, levelName ->
                            val isSelected = selectedLevelIndex == index
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) NeonCyberGreen else Color.White.copy(alpha = 0.08f),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedLevelIndex = index }
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        levelName,
                                        color = if (isSelected) Color.Black else Color.White.copy(alpha = 0.7f),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Focus Area Chips Selector
                item {
                    Text(
                        "FOCUS AREA",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = Color.White,
                        letterSpacing = 1.sp
                    )
                }

                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        items(focusAreas) { area ->
                            val isSelected = selectedFocusFilter == area
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedFocusFilter = area },
                                label = { Text(area, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NeonCyberGreen,
                                    selectedLabelColor = Color.Black,
                                    containerColor = SurfaceCardDark,
                                    labelColor = Color.White.copy(alpha = 0.8f)
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                }

                // Quick Navigation Hub
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        HomeShortcutCard(
                            title = "IronForge Pro",
                            icon = Icons.Default.FitnessCenter,
                            tint = FitNeonCyan,
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate(AppScreen.IRONFORGE_PRO_GYM) }
                        )
                        HomeShortcutCard(
                            title = "Weight Log",
                            icon = Icons.Default.FitnessCenter,
                            tint = NeonCyberGreen,
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate(AppScreen.WEIGHTLIFTING_TRACKER) }
                        )
                        HomeShortcutCard(
                            title = "Plan Builder",
                            icon = Icons.Default.AutoAwesome,
                            tint = Color(0xFF00B0FF),
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate(AppScreen.PERSONAL_PLAN_BUILDER) }
                        )
                        HomeShortcutCard(
                            title = "Analytics",
                            icon = Icons.Default.ShowChart,
                            tint = NeonOrange,
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate(AppScreen.PROGRESS_ANALYTICS) }
                        )
                    }
                }

                // IRONFORGE PRO GYM FEATURED HERO CARD
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigate(AppScreen.IRONFORGE_PRO_GYM) },
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceCardDark),
                        border = androidx.compose.foundation.BorderStroke(1.dp, FitNeonCyan.copy(alpha = 0.4f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            Color(0xFF0D1B2A),
                                            Color(0xFF1B263B),
                                            Color(0xFF003566)
                                        )
                                    )
                                )
                                .padding(18.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = FitNeonCyan.copy(alpha = 0.2f),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, FitNeonCyan)
                                    ) {
                                        Text(
                                            "⚡ LIVE SYSTEM & 4K MOTION",
                                            color = FitNeonCyan,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 10.sp,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                    Text(
                                        "🟢 LIVE PROD NODE",
                                        color = NeonCyberGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(Color.Black)
                                            .border(1.5.dp, FitNeonCyan, RoundedCornerShape(14.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Image(
                                            painter = painterResource(id = R.drawable.fit3d_app_logo_1787922140679),
                                            contentDescription = "FIT3D Logo",
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                    Column {
                                        Text(
                                            "IRONFORGE PRO GYM 🏋️",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 19.sp,
                                            color = Color.White
                                        )
                                        Text(
                                            "Heavy Barbell Vault • 1RM Engine",
                                            color = Color.White.copy(alpha = 0.8f),
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { onNavigate(AppScreen.IRONFORGE_PRO_GYM) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = FitNeonCyan,
                                        contentColor = Color.Black
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(42.dp)
                                ) {
                                    Text("ENTER IRONFORGE PRO GYM →", fontWeight = FontWeight.Black, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                // Sector Section Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Training Sectors",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = "03 ACTIVE MODULES",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonCyberGreen,
                            letterSpacing = 1.sp
                        )
                    }
                }

                // Sector 1: HOME GYM
                item {
                    SectorCard(
                        title = "HOME GYM 🏋️",
                        tagline = "Build Strength with Domestic Props (Water Bottles, Chairs, Backpacks)",
                        iconEmoji = "🏋️",
                        badgeText = "STRENGTH CORE",
                        onEnterClick = { onSectorClick("GYM") },
                        extraContent = {
                            MuscleViewer3D(
                                activeMuscle = activeMuscle,
                                isGreenTargetEnabled = isGreenTargetEnabled,
                                onMuscleSelected = onMuscleSelected,
                                onToggleGreenTarget = onToggleGreenTarget,
                                showControls = true
                            )
                        }
                    )
                }

                // Sector 2: HOME YOGA
                item {
                    SectorCard(
                        title = "HOME YOGA 🧘",
                        tagline = "Zen & Flexibility Flow • Kinetic Breath Frequency Module",
                        iconEmoji = "🧘",
                        badgeText = "FLEXIBILITY & ZEN",
                        onEnterClick = { onSectorClick("YOGA") }
                    )
                }

                // Sector 3: FACE SMART AESTHETIC
                item {
                    SectorCard(
                        title = "FACE SMART AESTHETIC 🥷",
                        tagline = "Jawline & Posture Mastery • Mewing, Masseter & Tech-Neck Alignment",
                        iconEmoji = "🥷",
                        badgeText = "AESTHETIC & POSTURE",
                        onEnterClick = { onNavigate(AppScreen.FACE_SMART_HUB) }
                    )
                }
            }
        }

        // Admin Secret Toggle FAB (Protected by Biometric Authentication Gate)
        if (isAdmin) {
            AdminCommandFab(
                isCommandModeActive = false,
                onClick = onToggleCommandMode,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 18.dp, bottom = 20.dp)
            )
        }

        // Readiness Check Dialog
        if (showReadinessDialog) {
            ReadinessCheckDialog(
                currentScore = user?.readinessScore ?: 85,
                onDismiss = { showReadinessDialog = false },
                onConfirm = onUpdateReadiness
            )
        }

        // Profile Photo & Avatar Dialog
        if (showProfilePhotoDialog) {
            Dialog(onDismissRequest = { showProfilePhotoDialog = false }) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color(0xFF141922),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, FitNeonGreen.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Profile Picture & Identity",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            IconButton(onClick = { showProfilePhotoDialog = false }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        // Current Profile Photo Preview
                        Box(
                            modifier = Modifier
                                .size(100.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF222B38))
                                .border(2.5.dp, FitNeonGreen, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            val imgUri = user?.profileImageUri ?: ""
                            if (imgUri.isNotBlank()) {
                                AsyncImage(
                                    model = imgUri,
                                    contentDescription = "Profile Preview",
                                    modifier = Modifier.fillMaxSize().clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(text = user?.avatar ?: "🥷", fontSize = 46.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = user?.name ?: "Athlete",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Level ${user?.level ?: 1} • ${user?.role?.uppercase() ?: "USER"}",
                            color = FitNeonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        // Upload Photo Action
                        Button(
                            onClick = {
                                photoPickerLauncher.launch("image/*")
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FitNeonGreen,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("CHOOSE FROM GALLERY / PHOTOS", fontWeight = FontWeight.Black, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        // View Detailed Report Action
                        Button(
                            onClick = {
                                showProfilePhotoDialog = false
                                onNavigate(AppScreen.PROGRESS_ANALYTICS)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0x22FFFFFF),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(44.dp)
                        ) {
                            Icon(Icons.Default.ShowChart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("VIEW PROGRESS & BIO REPORT", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeShortcutCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = SurfaceCardDark,
        modifier = modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}
