package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FitNeonCyan
import com.example.ui.theme.FitNeonGreen
import com.example.ui.theme.FitTextMuted
import com.example.ui.theme.FitTextPrimary
import com.example.ui.theme.FitTextSecondary
import kotlin.math.cos
import kotlin.math.sin

enum class BodyMuscle(val displayName: String, val code: String) {
    CHEST("Chest (Pectorals)", "CHEST"),
    BICEPS("Biceps Brachii", "BICEPS"),
    TRICEPS("Triceps", "TRICEPS"),
    ABS("Core / Abs", "ABS"),
    SHOULDERS("Deltoids", "SHOULDERS"),
    QUADS("Quadriceps", "QUADS"),
    GLUTES("Gluteus Max", "GLUTES"),
    BACK("Latissimus Dorsi", "BACK"),
    JAWLINE("Masseter / Jawline", "JAWLINE"),
    NECK("Cervical Posture", "NECK"),
    SPINE("Kinetic Spine", "SPINE")
}

@Composable
fun MuscleViewer3D(
    modifier: Modifier = Modifier,
    activeMuscle: BodyMuscle = BodyMuscle.CHEST,
    isGreenTargetEnabled: Boolean = true,
    onMuscleSelected: (BodyMuscle) -> Unit = {},
    onToggleGreenTarget: (Boolean) -> Unit = {},
    showControls: Boolean = true
) {
    var rotationY by remember { mutableFloatStateOf(0f) }
    var isBackView by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "muscleGlow")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowPulse"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF1E2822),
                        Color(0xFF141414),
                        Color(0xFF0D0D0D)
                    )
                )
            )
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(22.dp))
            .padding(14.dp)
    ) {
        // Top 3D Status Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(if (isGreenTargetEnabled) FitNeonGreen else FitTextMuted, CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "3D ANATOMY CORE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = if (isGreenTargetEnabled) FitNeonGreen else FitTextMuted
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = {
                        isBackView = !isBackView
                        rotationY += 180f
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Cached,
                        contentDescription = "Rotate 180",
                        tint = FitNeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0x33FFFFFF)
                ) {
                    Text(
                        text = if (isBackView) "POSTERIOR" else "ANTERIOR",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 3D Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF090909))
                .pointerInput(Unit) {
                    detectDragGestures { _, dragAmount ->
                        rotationY = (rotationY + dragAmount.x * 0.5f) % 360f
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val centerX = canvasWidth / 2f
                val centerY = canvasHeight / 2f

                // Draw futuristic perspective 3D grid floor
                val gridColor = Color(0x1A00E5FF)
                for (i in -5..5) {
                    val x = centerX + i * 28f
                    drawLine(
                        color = gridColor,
                        start = Offset(x, canvasHeight * 0.65f),
                        end = Offset(centerX + i * 70f, canvasHeight),
                        strokeWidth = 1f
                    )
                }
                for (j in 1..4) {
                    val y = canvasHeight * 0.65f + j * (canvasHeight * 0.35f / 4f)
                    drawLine(
                        color = gridColor,
                        start = Offset(0f, y),
                        end = Offset(canvasWidth, y),
                        strokeWidth = 1f
                    )
                }

                val rad = Math.toRadians(rotationY.toDouble())
                val cosRot = cos(rad).toFloat()

                // Head
                drawCircle(
                    color = Color(0xFF6B7280),
                    radius = 24f,
                    center = Offset(centerX, centerY - 65f)
                )

                // Head highlight / Jawline
                if (isGreenTargetEnabled && (activeMuscle == BodyMuscle.JAWLINE || activeMuscle == BodyMuscle.NECK)) {
                    drawCircle(
                        color = FitNeonGreen.copy(alpha = pulseGlow * 0.9f),
                        radius = 28f,
                        center = Offset(centerX, centerY - 65f),
                        style = Stroke(width = 4f)
                    )
                }

                // Neck
                drawRect(
                    color = if (isGreenTargetEnabled && activeMuscle == BodyMuscle.NECK) FitNeonGreen.copy(alpha = pulseGlow) else Color(0xFF4B5563),
                    topLeft = Offset(centerX - 8f, centerY - 42f),
                    size = Size(16f, 16f)
                )

                val isChestActive = isGreenTargetEnabled && (activeMuscle == BodyMuscle.CHEST && !isBackView)
                val isBackActive = isGreenTargetEnabled && (activeMuscle == BodyMuscle.BACK && isBackView)
                val isAbsActive = isGreenTargetEnabled && (activeMuscle == BodyMuscle.ABS && !isBackView)

                // Upper Torso
                drawRoundRect(
                    color = Color(0xFF374151),
                    topLeft = Offset(centerX - 38f * cosRot.coerceAtLeast(0.7f), centerY - 28f),
                    size = Size(76f * cosRot.coerceAtLeast(0.7f), 52f),
                    cornerRadius = CornerRadius(16f, 16f)
                )

                // Chest pectorals
                if (!isBackView) {
                    val chestColor = if (isChestActive) FitNeonGreen.copy(alpha = pulseGlow) else Color(0xFF4B5563)
                    drawRoundRect(
                        color = chestColor,
                        topLeft = Offset(centerX - 32f, centerY - 24f),
                        size = Size(28f, 22f),
                        cornerRadius = CornerRadius(8f, 8f)
                    )
                    drawRoundRect(
                        color = chestColor,
                        topLeft = Offset(centerX + 4f, centerY - 24f),
                        size = Size(28f, 22f),
                        cornerRadius = CornerRadius(8f, 8f)
                    )
                    // Abs (6-pack matrix)
                    val absColor = if (isAbsActive) FitNeonGreen.copy(alpha = pulseGlow) else Color(0xFF2E3846)
                    for (row in 0..2) {
                        drawRoundRect(
                            color = absColor,
                            topLeft = Offset(centerX - 18f, centerY + 4f + row * 13f),
                            size = Size(16f, 10f),
                            cornerRadius = CornerRadius(4f, 4f)
                        )
                        drawRoundRect(
                            color = absColor,
                            topLeft = Offset(centerX + 2f, centerY + 4f + row * 13f),
                            size = Size(16f, 10f),
                            cornerRadius = CornerRadius(4f, 4f)
                        )
                    }
                } else {
                    // Posterior Lats
                    val backColor = if (isBackActive) FitNeonGreen.copy(alpha = pulseGlow) else Color(0xFF2E3846)
                    drawRoundRect(
                        color = backColor,
                        topLeft = Offset(centerX - 30f, centerY - 24f),
                        size = Size(60f, 44f),
                        cornerRadius = CornerRadius(12f, 12f)
                    )
                }

                // Shoulders
                val isShouldersActive = isGreenTargetEnabled && activeMuscle == BodyMuscle.SHOULDERS
                val shoulderColor = if (isShouldersActive) FitNeonGreen.copy(alpha = pulseGlow) else Color(0xFF4B5563)
                drawCircle(color = shoulderColor, radius = 14f, center = Offset(centerX - 46f, centerY - 20f))
                drawCircle(color = shoulderColor, radius = 14f, center = Offset(centerX + 46f, centerY - 20f))

                // Arms
                val isBicepsActive = isGreenTargetEnabled && (activeMuscle == BodyMuscle.BICEPS && !isBackView)
                val isTricepsActive = isGreenTargetEnabled && (activeMuscle == BodyMuscle.TRICEPS && isBackView)
                val armColor = if (isBicepsActive || isTricepsActive) FitNeonGreen.copy(alpha = pulseGlow) else Color(0xFF4B5563)

                drawRoundRect(
                    color = armColor,
                    topLeft = Offset(centerX - 56f, centerY - 8f),
                    size = Size(14f, 42f),
                    cornerRadius = CornerRadius(7f, 7f)
                )
                drawRoundRect(
                    color = armColor,
                    topLeft = Offset(centerX + 42f, centerY - 8f),
                    size = Size(14f, 42f),
                    cornerRadius = CornerRadius(7f, 7f)
                )

                // Pelvis / Glutes
                val isGlutesActive = isGreenTargetEnabled && activeMuscle == BodyMuscle.GLUTES
                val pelvisColor = if (isGlutesActive) FitNeonGreen.copy(alpha = pulseGlow) else Color(0xFF374151)
                drawRoundRect(
                    color = pelvisColor,
                    topLeft = Offset(centerX - 30f, centerY + 44f),
                    size = Size(60f, 22f),
                    cornerRadius = CornerRadius(10f, 10f)
                )

                // Quads
                val isQuadsActive = isGreenTargetEnabled && (activeMuscle == BodyMuscle.QUADS && !isBackView)
                val legColor = if (isQuadsActive) FitNeonGreen.copy(alpha = pulseGlow) else Color(0xFF4B5563)

                drawRoundRect(
                    color = legColor,
                    topLeft = Offset(centerX - 28f, centerY + 70f),
                    size = Size(22f, 52f),
                    cornerRadius = CornerRadius(10f, 10f)
                )
                drawRoundRect(
                    color = legColor,
                    topLeft = Offset(centerX + 6f, centerY + 70f),
                    size = Size(22f, 52f),
                    cornerRadius = CornerRadius(10f, 10f)
                )
            }

            Text(
                text = "⚡ Drag to Orbit 360°",
                color = Color(0x66FFFFFF),
                fontSize = 9.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 6.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (showControls) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0x22FFFFFF))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Green Muscle Target 🟢",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = FitTextPrimary
                    )
                    Text(
                        text = "Highlight active kinetic anatomy",
                        fontSize = 10.sp,
                        color = FitTextSecondary
                    )
                }
                Switch(
                    checked = isGreenTargetEnabled,
                    onCheckedChange = onToggleGreenTarget,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = FitNeonGreen,
                        checkedTrackColor = Color(0xFF1B4D2E),
                        uncheckedThumbColor = Color(0xFF888888),
                        uncheckedTrackColor = Color(0xFF2A2A2A)
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(BodyMuscle.CHEST, BodyMuscle.TRICEPS, BodyMuscle.QUADS, BodyMuscle.JAWLINE).forEach { muscle ->
                    val isSelected = activeMuscle == muscle
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) FitNeonGreen.copy(alpha = 0.2f) else Color(0x1AFFFFFF),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onMuscleSelected(muscle) }
                            .border(
                                width = 1.dp,
                                color = if (isSelected) FitNeonGreen else Color.Transparent,
                                shape = RoundedCornerShape(10.dp)
                            )
                    ) {
                        Text(
                            text = muscle.displayName.split(" ")[0],
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) FitNeonGreen else FitTextSecondary,
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
