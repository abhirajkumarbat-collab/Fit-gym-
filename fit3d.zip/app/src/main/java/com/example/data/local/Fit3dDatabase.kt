package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        ExerciseEntity::class,
        WorkoutHistoryEntity::class,
        AdminPostEntity::class,
        CommunityChallengeEntity::class,
        WeightLogEntity::class,
        CustomWorkoutPlanEntity::class,
        WeightliftingSetLogEntity::class,
        HabitReminderEntity::class,
        ArticleEntity::class,
        FourWeekPlanDayEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class Fit3dDatabase : RoomDatabase() {
    abstract fun fit3dDao(): Fit3dDao

    companion object {
        @Volatile
        private var INSTANCE: Fit3dDatabase? = null

        fun getDatabase(context: Context): Fit3dDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    Fit3dDatabase::class.java,
                    "fit3d_database"
                )
                    .fallbackToDestructiveMigration(true)
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database.fit3dDao())
                    }
                }
            }

            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        val user = database.fit3dDao().getUser("primary_user")
                        if (user == null) {
                            populateInitialData(database.fit3dDao())
                        }
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: Fit3dDao) {
            val videoBundleDrive = "https://drive.google.com/drive/folders/1vBx4tzfMJGCUNlg-78YMbbq6qCqr6CQF"

            val defaultExercises = listOf(
                // HOME GYM / WEIGHTLIFTING / BODYWEIGHT
                ExerciseEntity(
                    id = "gym_row_1",
                    title = "Bent-Over Row • Barbell",
                    sector = "GYM",
                    subtitle = "Upper Back & Latissimus hypertrophy",
                    domesticProp = "Barbell / 2x Water Jugs",
                    targetMuscles = "Lats, Rhomboids, Rear Delts, Biceps",
                    primaryMuscleCode = "BACK",
                    difficulty = "Intermediate",
                    defaultSets = 4,
                    defaultReps = 12,
                    defaultDurationSec = 48,
                    restDurationSec = 45,
                    caloriesPerSet = 24,
                    instructions = "1. Hinge at hips 45 degrees with flat back.\n2. Pull barbell/jugs to lower ribcage.\n3. Squeeze shoulder blades together for 1s.\n4. Lower with controlled 3-second negative.",
                    commonMistakes = "Rounding thoracic spine, jerking neck upwards, using momentum.",
                    formTips = "Keep elbows tucked close to torso and maintain rigid core.",
                    iconEmoji = "🏋️",
                    videoUrl = videoBundleDrive,
                    videoFileName = "01_barbell_bent_over_row_4k.mp4",
                    videoCategory = "Back & Lats",
                    videoResolution = "4K 60FPS HDR",
                    videoAnglesAvailable = "Front (0°), Oblique (45°), Profile (90°)",
                    equipmentCategory = "Barbell",
                    focusAreaGroup = "Back",
                    coachVoiceTip = "Hinge hips back, brace your core, and pull towards your lower ribs!"
                ),
                ExerciseEntity(
                    id = "gym_pushup_1",
                    title = "Classic Chest Push-up",
                    sector = "GYM",
                    subtitle = "Pectoral & Tricep floor press",
                    domesticProp = "No equipment (Floor/Mat)",
                    targetMuscles = "Pectoralis Major, Anterior Delts, Triceps",
                    primaryMuscleCode = "CHEST",
                    difficulty = "Beginner",
                    defaultSets = 3,
                    defaultReps = 20,
                    defaultDurationSec = 45,
                    restDurationSec = 30,
                    caloriesPerSet = 18,
                    instructions = "1. Place hands slightly wider than shoulders.\n2. Maintain rigid plank from head to heels.\n3. Lower chest to floor with elbows at 45 degrees.\n4. Drive explosively back up.",
                    commonMistakes = "Flaring elbows 90 deg, sagging lower back, half-reps.",
                    formTips = "Engage glutes and pull belly button to spine throughout.",
                    iconEmoji = "💪",
                    videoUrl = videoBundleDrive,
                    videoFileName = "02_chest_pushup_form_guide.mp4",
                    videoCategory = "Chest & Pecs",
                    videoResolution = "4K 60FPS HDR",
                    videoAnglesAvailable = "Front (0°), Oblique (45°), Profile (90°)",
                    equipmentCategory = "Body Weight",
                    focusAreaGroup = "Chest",
                    coachVoiceTip = "Lock your plank line and push the floor away powerfully!"
                ),
                ExerciseEntity(
                    id = "gym_side_plank",
                    title = "Side Plank Left & Right",
                    sector = "GYM",
                    subtitle = "Oblique & Lateral abdominal wall",
                    domesticProp = "No equipment",
                    targetMuscles = "Internal & External Obliques, Quadratus Lumborum",
                    primaryMuscleCode = "ABS",
                    difficulty = "Intermediate",
                    defaultSets = 3,
                    defaultReps = 15,
                    defaultDurationSec = 40,
                    restDurationSec = 25,
                    caloriesPerSet = 16,
                    instructions = "1. Lie on side with elbow directly beneath shoulder.\n2. Stack feet and lift hips until body forms straight line.\n3. Hold peak contraction with raised top arm.",
                    commonMistakes = "Dropping hips downward, rolling chest forward.",
                    formTips = "Squeeze lateral glute and drive forearm firmly into ground.",
                    iconEmoji = "⚡",
                    videoUrl = videoBundleDrive,
                    videoFileName = "03_side_plank_lateral_obliques.mp4",
                    videoCategory = "Abs & Obliques",
                    videoResolution = "4K 60FPS HDR",
                    videoAnglesAvailable = "Front (0°), Profile (90°)",
                    equipmentCategory = "Body Weight",
                    focusAreaGroup = "Abs",
                    coachVoiceTip = "Elevate your hips high and feel the lateral obliques engage!"
                ),
                ExerciseEntity(
                    id = "gym_jumping_jacks",
                    title = "Jumping Jacks Cardio Burn",
                    sector = "GYM",
                    subtitle = "Full body metabolic calorie incinerator",
                    domesticProp = "No equipment",
                    targetMuscles = "Calves, Quads, Deltoids, Cardiovascular Heart",
                    primaryMuscleCode = "FULL BODY",
                    difficulty = "Beginner",
                    defaultSets = 3,
                    defaultReps = 30,
                    defaultDurationSec = 30,
                    restDurationSec = 20,
                    caloriesPerSet = 22,
                    instructions = "1. Stand upright with arms by sides.\n2. Jump feet outward while swinging arms overhead.\n3. Jump back to starting position in continuous rhythm.",
                    commonMistakes = "Landing heavily on heels, inconsistent tempo.",
                    formTips = "Land softly on balls of feet with light bend in knees.",
                    iconEmoji = "🔥",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "Body Weight",
                    focusAreaGroup = "Full Body",
                    coachVoiceTip = "Stay light on your feet and establish a steady aerobic rhythm!"
                ),
                ExerciseEntity(
                    id = "gym_mountain_climbers",
                    title = "Mountain Climber Sprint",
                    sector = "GYM",
                    subtitle = "Dynamic core stability & hip flexion",
                    domesticProp = "No equipment",
                    targetMuscles = "Rectus Abdominis, Hip Flexors, Shoulders",
                    primaryMuscleCode = "ABS",
                    difficulty = "Intermediate",
                    defaultSets = 3,
                    defaultReps = 20,
                    defaultDurationSec = 35,
                    restDurationSec = 25,
                    caloriesPerSet = 20,
                    instructions = "1. Start in high push-up plank position.\n2. Drive one knee toward chest without touching floor.\n3. Quickly switch legs in running motion.",
                    commonMistakes = "Bouncing hips up in air, hands creeping forward.",
                    formTips = "Keep shoulders directly stacked over wrists.",
                    iconEmoji = "🏃",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "Body Weight",
                    focusAreaGroup = "Abs",
                    coachVoiceTip = "Drive knees forward with explosive core drive!"
                ),
                ExerciseEntity(
                    id = "gym_donkey_kicks",
                    title = "Donkey Kicks Glute Lift",
                    sector = "GYM",
                    subtitle = "Gluteus maximus isolation & firming",
                    domesticProp = "No equipment / Ankle weights",
                    targetMuscles = "Gluteus Maximus, Hamstrings",
                    primaryMuscleCode = "BUTT",
                    difficulty = "Beginner",
                    defaultSets = 3,
                    defaultReps = 20,
                    defaultDurationSec = 35,
                    restDurationSec = 25,
                    caloriesPerSet = 15,
                    instructions = "1. Tabletop position on all fours on mat.\n2. Keep knee bent 90 degrees and kick sole of foot to ceiling.\n3. Squeeze glute at top for 1 count, lower slowly.",
                    commonMistakes = "Arching lower back, twisting hips to the side.",
                    formTips = "Isolate movement purely from glute-hip hinge.",
                    iconEmoji = "🍑",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "Body Weight",
                    focusAreaGroup = "Butt",
                    coachVoiceTip = "Push the sole of your shoe directly up to the ceiling!"
                ),
                ExerciseEntity(
                    id = "gym_ab_wheel",
                    title = "Ab Wheel Rollout",
                    sector = "GYM",
                    subtitle = "Anti-extension deep abdominal core overload",
                    domesticProp = "Ab Roller / Towel on Slick Floor",
                    targetMuscles = "Transverse Abdominis, Rectus Abdominis, Lats",
                    primaryMuscleCode = "ABS",
                    difficulty = "Advanced",
                    defaultSets = 3,
                    defaultReps = 10,
                    defaultDurationSec = 45,
                    restDurationSec = 40,
                    caloriesPerSet = 20,
                    instructions = "1. Kneel on mat holding ab wheel or towel.\n2. Roll slowly forward while bracing abs in posterior pelvic tilt.\n3. Contract core to pull back to starting position.",
                    commonMistakes = "Hyperextending lumbar spine, bending elbows.",
                    formTips = "Never let lower back sag; roll only as far as you can control.",
                    iconEmoji = "🎯",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "No equipment",
                    focusAreaGroup = "Abs",
                    coachVoiceTip = "Brace your core tight and pull back using pure abdominal strength!"
                ),
                ExerciseEntity(
                    id = "gym_back_extension",
                    title = "Back Extension on Floor (Superman)",
                    sector = "GYM",
                    subtitle = "Erector spinae & posterior chain strengthener",
                    domesticProp = "No equipment (Floor)",
                    targetMuscles = "Erector Spinae, Glutes, Upper Traps",
                    primaryMuscleCode = "BACK",
                    difficulty = "Beginner",
                    defaultSets = 3,
                    defaultReps = 15,
                    defaultDurationSec = 40,
                    restDurationSec = 25,
                    caloriesPerSet = 14,
                    instructions = "1. Lie face down on floor with arms extended forward.\n2. Simultaneously lift arms, chest, and legs off ground.\n3. Hold contraction for 2 seconds, then lower gently.",
                    commonMistakes = "Jerking neck up, holding breath.",
                    formTips = "Look down at floor to keep cervical spine neutral.",
                    iconEmoji = "🦸",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "Body Weight",
                    focusAreaGroup = "Back",
                    coachVoiceTip = "Lift chest and thighs smoothly, squeezing your lower back!"
                ),
                ExerciseEntity(
                    id = "gym_lunge_dumbbell",
                    title = "Backward Lunge • Dumbbell",
                    sector = "GYM",
                    subtitle = "Unilateral quad, hamstring, and glute balance",
                    domesticProp = "Dumbbells / 2x Heavy Backpacks",
                    targetMuscles = "Quadriceps, Gluteus Medius, Calves",
                    primaryMuscleCode = "QUADS",
                    difficulty = "Intermediate",
                    defaultSets = 3,
                    defaultReps = 12,
                    defaultDurationSec = 50,
                    restDurationSec = 30,
                    caloriesPerSet = 22,
                    instructions = "1. Hold dumbbells at sides with tall posture.\n2. Step backward with right foot and lower until both knees reach 90 deg.\n3. Drive through front left heel to return.",
                    commonMistakes = "Front knee caving inward, leaning torso forward.",
                    formTips = "Keep front shin vertical and weight centered on mid-foot.",
                    iconEmoji = "🦵",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "Dumbbell",
                    focusAreaGroup = "Leg",
                    coachVoiceTip = "Step back deep and press through your front heel!"
                ),
                ExerciseEntity(
                    id = "gym_reverse_plank",
                    title = "Reverse Plank Hold",
                    sector = "GYM",
                    subtitle = "Posterior shoulder, glute, and spinal erecter builder",
                    domesticProp = "No equipment",
                    targetMuscles = "Posterior Deltoids, Glutes, Hamstrings, Core",
                    primaryMuscleCode = "BACK",
                    difficulty = "Intermediate",
                    defaultSets = 3,
                    defaultReps = 1,
                    defaultDurationSec = 30,
                    restDurationSec = 30,
                    caloriesPerSet = 16,
                    instructions = "1. Sit on floor with legs extended, place hands behind hips fingers pointing forward.\n2. Press through palms and heels to lift hips.\n3. Form straight line from head to heels.",
                    commonMistakes = "Dropping hips, hunching shoulders toward ears.",
                    formTips = "Open chest wide and drive shoulder blades together.",
                    iconEmoji = "🔄",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "Body Weight",
                    focusAreaGroup = "Back",
                    coachVoiceTip = "Drive hips high and open up your chest!"
                ),
                // FACE SMART AESTHETIC / JAWLINE & MEWING
                ExerciseEntity(
                    id = "face_mewing_1",
                    title = "Mewing Orthotropic Tongue Suction",
                    sector = "FACE_SMART",
                    subtitle = "Maxillary palate expansion & jawline definition",
                    domesticProp = "Pure Anatomy (Palate & Tongue)",
                    targetMuscles = "Genioglossus, Masseters, Hyoid Muscle Complex",
                    primaryMuscleCode = "JAWLINE",
                    difficulty = "Beginner",
                    defaultSets = 3,
                    defaultReps = 15,
                    defaultDurationSec = 60,
                    restDurationSec = 20,
                    caloriesPerSet = 5,
                    instructions = "1. Say the 'N-G' sound to identify back of tongue.\n2. Flatten entire tongue against roof of mouth (including rear 1/3).\n3. Create negative vacuum suction; close lips and breathe purely nasal.",
                    commonMistakes = "Touching only the tongue tip, pushing against front teeth.",
                    formTips = "The power is in the back third of the tongue pushing upward.",
                    iconEmoji = "🥷",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "No equipment",
                    focusAreaGroup = "Face & Jawline",
                    coachVoiceTip = "Seal entire tongue to roof of mouth and breathe smoothly through your nose."
                ),
                ExerciseEntity(
                    id = "face_neck_lift",
                    title = "Neck Lift & Jaw Forward Stretch",
                    sector = "FACE_SMART",
                    subtitle = "Submental double-chin elimination & platysma tighten",
                    domesticProp = "No equipment",
                    targetMuscles = "Platysma, Sternocleidomastoid, Digastric",
                    primaryMuscleCode = "NECK",
                    difficulty = "Beginner",
                    defaultSets = 3,
                    defaultReps = 12,
                    defaultDurationSec = 30,
                    restDurationSec = 15,
                    caloriesPerSet = 6,
                    instructions = "1. Sit tall with shoulders relaxed.\n2. Raise head to look directly at ceiling.\n3. Stretch lower jaw forward until strong tension is felt along jawline and neck.\n4. Hold 5 seconds, relax, repeat.",
                    commonMistakes = "Straining back of neck, hunching shoulders.",
                    formTips = "Feel tension from collarbones right up to mandible edge.",
                    iconEmoji = "🦒",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "No equipment",
                    focusAreaGroup = "Face & Jawline",
                    coachVoiceTip = "Raise your head to look at the ceiling, stretch your lower jaw forward!"
                ),
                ExerciseEntity(
                    id = "face_mouthwash",
                    title = "Mouthwash Cheek Puff Exercise",
                    sector = "FACE_SMART",
                    subtitle = "Buccinator toning & cheek hollow sculpt",
                    domesticProp = "Air Pocket Resistance",
                    targetMuscles = "Buccinator, Orbicularis Oris, Zygomaticus",
                    primaryMuscleCode = "JAWLINE",
                    difficulty = "Beginner",
                    defaultSets = 3,
                    defaultReps = 20,
                    defaultDurationSec = 55,
                    restDurationSec = 15,
                    caloriesPerSet = 5,
                    instructions = "1. Fill mouth with air like holding mouthwash.\n2. Swish air ball forcefully from left cheek to right cheek.\n3. Shift air under upper lip, then lower lip in circular sweep.",
                    commonMistakes = "Letting air leak from lips, irregular speed.",
                    formTips = "Keep lips tightly sealed and cheeks engaged under pressure.",
                    iconEmoji = "🫧",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "No equipment",
                    focusAreaGroup = "Face & Jawline",
                    coachVoiceTip = "Swish the air pocket firmly from cheek to cheek with tight lip seal!"
                ),
                ExerciseEntity(
                    id = "face_massage",
                    title = "Lymphatic Face & Mandible Massage",
                    sector = "FACE_SMART",
                    subtitle = "Facial fluid drainage & skin tightening",
                    domesticProp = "Hands / Facial Oil",
                    targetMuscles = "Superficial Fascia, Lymphatic Nodes",
                    primaryMuscleCode = "JAWLINE",
                    difficulty = "Beginner",
                    defaultSets = 2,
                    defaultReps = 1,
                    defaultDurationSec = 55,
                    restDurationSec = 15,
                    caloriesPerSet = 4,
                    instructions = "1. Place knuckle joints of index and middle fingers on chin.\n2. Glide knuckles along jawline up to ears with firm upward pressure.\n3. Drain downward along sides of neck to clavicle.",
                    commonMistakes = "Pulling downward on facial skin, dry skin friction.",
                    formTips = "Always glide upward and outward to promote drainage.",
                    iconEmoji = "💆",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "No equipment",
                    focusAreaGroup = "Face & Jawline",
                    coachVoiceTip = "Glide upward along jawline toward ears with gentle lifting strokes."
                ),
                ExerciseEntity(
                    id = "face_head_tilt",
                    title = "Tilt Head Left & Right",
                    sector = "FACE_SMART",
                    subtitle = "Sternocleidomastoid alignment & lateral jaw release",
                    domesticProp = "No equipment",
                    targetMuscles = "Sternocleidomastoid, Scalenes, Upper Traps",
                    primaryMuscleCode = "NECK",
                    difficulty = "Beginner",
                    defaultSets = 3,
                    defaultReps = 10,
                    defaultDurationSec = 55,
                    restDurationSec = 15,
                    caloriesPerSet = 5,
                    instructions = "1. Sit tall with chest open.\n2. Gently tilt right ear toward right shoulder without hiking shoulder.\n3. Extend jaw slightly forward to stretch lateral neck muscles.\n4. Repeat on left side.",
                    commonMistakes = "Jerking fast, shrugging shoulders up.",
                    formTips = "Breathe deeply and hold each stretch for 3 full seconds.",
                    iconEmoji = "📐",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "No equipment",
                    focusAreaGroup = "Face & Jawline",
                    coachVoiceTip = "Tilt gently to the side, feeling the long stretch along your neck."
                ),
                ExerciseEntity(
                    id = "face_scalp_massage",
                    title = "Scalp Massage for Hair Growth",
                    sector = "FACE_SMART",
                    subtitle = "Subgaleal blood circulation & follicle youth promoter",
                    domesticProp = "Fingertips",
                    targetMuscles = "Epicranius, Temporoparietalis, Galea Aponeurotica",
                    primaryMuscleCode = "NECK",
                    difficulty = "Beginner",
                    defaultSets = 2,
                    defaultReps = 1,
                    defaultDurationSec = 90,
                    restDurationSec = 20,
                    caloriesPerSet = 6,
                    instructions = "1. Spread fingers wide on scalp from temples to crown.\n2. Apply circular micro-pressures shifting scalp skin over skull.\n3. Progress to sides and base of occiput.",
                    commonMistakes = "Rubbing hair strands rather than moving scalp skin.",
                    formTips = "Mobilize scalp tissues to flood follicles with oxygenated blood.",
                    iconEmoji = "💆‍♂️",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "No equipment",
                    focusAreaGroup = "Face & Jawline",
                    coachVoiceTip = "Use firm circular finger pads to mobilize the scalp and boost circulation."
                ),
                // HOME YOGA & MOBILITY
                ExerciseEntity(
                    id = "yoga_surya_1",
                    title = "Surya Namaskar 12-Asana Flow",
                    sector = "YOGA",
                    subtitle = "Complete solar kinetic alignment",
                    domesticProp = "Yoga Mat / Soft Towel",
                    targetMuscles = "Whole Spine, Hamstrings, Shoulders, Core",
                    primaryMuscleCode = "SPINE",
                    difficulty = "Intermediate",
                    defaultSets = 4,
                    defaultReps = 1,
                    defaultDurationSec = 90,
                    restDurationSec = 30,
                    caloriesPerSet = 25,
                    instructions = "1. Pranamasana (Prayer pose) -> Hastauttanasana (Raised arms).\n2. Hastapadasana (Forward fold) -> Ashwa Sanchalanasana (Lunge).\n3. Dandasana (Plank) -> Ashtanga Namaskara (8-limb salute).\n4. Bhujangasana (Cobra) -> Adho Mukha Svanasana (Downward dog).",
                    commonMistakes = "Rushing breath cycles, hyper-arching lumbar in cobra.",
                    formTips = "Synchronize each transition with nasal inhalations and exhalations.",
                    iconEmoji = "🧘",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "No equipment",
                    focusAreaGroup = "Full Body",
                    coachVoiceTip = "Sync breath with movement — inhale extension, exhale fold!"
                ),
                ExerciseEntity(
                    id = "yoga_warrior_2",
                    title = "Warrior Pose II (Virabhadrasana)",
                    sector = "YOGA",
                    subtitle = "Hip opener & grounding leg stamina",
                    domesticProp = "Yoga Mat",
                    targetMuscles = "Quadriceps, Adductors, Deltoids, Core",
                    primaryMuscleCode = "QUADS",
                    difficulty = "Beginner",
                    defaultSets = 3,
                    defaultReps = 2,
                    defaultDurationSec = 45,
                    restDurationSec = 20,
                    caloriesPerSet = 16,
                    instructions = "1. Step feet 4 feet apart, turn right foot out 90 degrees.\n2. Bend right knee to 90 degrees stacked over ankle.\n3. Extend arms parallel to floor, gaze over front middle finger.",
                    commonMistakes = "Front knee caving inward, leaning torso over front thigh.",
                    formTips = "Anchor outer edge of back foot firmly into mat.",
                    iconEmoji = "🥋",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "No equipment",
                    focusAreaGroup = "Leg",
                    coachVoiceTip = "Keep arms parallel, sink hips deep, and focus gaze forward."
                ),
                ExerciseEntity(
                    id = "yoga_pigeon_1",
                    title = "Pigeon Hip Opener (Eka Pada)",
                    sector = "YOGA",
                    subtitle = "Deep glute & piriformis sciatica release",
                    domesticProp = "Yoga Mat / Pillow cushion",
                    targetMuscles = "Piriformis, Gluteus Medius, Psoas Hip Flexors",
                    primaryMuscleCode = "GLUTES",
                    difficulty = "Intermediate",
                    defaultSets = 2,
                    defaultReps = 2,
                    defaultDurationSec = 60,
                    restDurationSec = 20,
                    caloriesPerSet = 12,
                    instructions = "1. From Downward Dog, bring right knee behind right wrist.\n2. Slide left leg straight back with hips square to floor.\n3. Walk hands forward and lower torso toward mat.",
                    commonMistakes = "Tilting hips to one side, forcing knee angle.",
                    formTips = "Place cushion under right hip if tight to keep pelvis balanced.",
                    iconEmoji = "🕊️",
                    videoUrl = videoBundleDrive,
                    equipmentCategory = "No equipment",
                    focusAreaGroup = "Butt",
                    coachVoiceTip = "Square your hips and breathe into the deep glute stretch."
                )
            )
            dao.insertExercises(defaultExercises)

            // Seed 4-Week Plan Days
            val default4WeekPlan = listOf(
                // Week 1
                FourWeekPlanDayEntity(id = "w1_d1", weekNumber = 1, dayNumber = 1, title = "Chest Burn", exerciseCount = 11, targetCalories = 280, durationMinutes = 14, isCompleted = true, focusMuscles = "Chest, Triceps"),
                FourWeekPlanDayEntity(id = "w1_d2", weekNumber = 1, dayNumber = 2, title = "Abs Shred", exerciseCount = 15, targetCalories = 310, durationMinutes = 16, isCompleted = true, focusMuscles = "Abs, Core"),
                FourWeekPlanDayEntity(id = "w1_d3", weekNumber = 1, dayNumber = 3, title = "Arm Sculpt", exerciseCount = 17, targetCalories = 320, durationMinutes = 15, isCompleted = true, focusMuscles = "Biceps, Triceps"),
                FourWeekPlanDayEntity(id = "w1_d4", weekNumber = 1, dayNumber = 4, title = "Rest & Stretch", exerciseCount = 5, targetCalories = 120, durationMinutes = 10, isCompleted = true, focusMuscles = "Mobility"),
                FourWeekPlanDayEntity(id = "w1_d5", weekNumber = 1, dayNumber = 5, title = "Chest Power", exerciseCount = 11, targetCalories = 290, durationMinutes = 15, isCompleted = true, focusMuscles = "Chest, Shoulders"),
                FourWeekPlanDayEntity(id = "w1_d6", weekNumber = 1, dayNumber = 6, title = "Abs Core", exerciseCount = 14, targetCalories = 300, durationMinutes = 15, isCompleted = false, focusMuscles = "Abs, Obliques"),
                FourWeekPlanDayEntity(id = "w1_d7", weekNumber = 1, dayNumber = 7, title = "Arm Burn", exerciseCount = 16, targetCalories = 310, durationMinutes = 16, isCompleted = false, focusMuscles = "Arms"),
                // Week 2
                FourWeekPlanDayEntity(id = "w2_d1", weekNumber = 2, dayNumber = 1, title = "Abs Blitz", exerciseCount = 18, targetCalories = 360, durationMinutes = 17, isCompleted = false, focusMuscles = "Abs"),
                FourWeekPlanDayEntity(id = "w2_d2", weekNumber = 2, dayNumber = 2, title = "Arm Overload", exerciseCount = 17, targetCalories = 350, durationMinutes = 16, isCompleted = false, focusMuscles = "Arms"),
                FourWeekPlanDayEntity(id = "w2_d3", weekNumber = 2, dayNumber = 3, title = "Chest Drop", exerciseCount = 13, targetCalories = 320, durationMinutes = 14, isCompleted = false, focusMuscles = "Chest"),
                FourWeekPlanDayEntity(id = "w2_d4", weekNumber = 2, dayNumber = 4, title = "Active Rest", exerciseCount = 6, targetCalories = 140, durationMinutes = 10, isCompleted = false, focusMuscles = "Yoga"),
                FourWeekPlanDayEntity(id = "w2_d5", weekNumber = 2, dayNumber = 5, title = "Full Body", exerciseCount = 19, targetCalories = 390, durationMinutes = 18, isCompleted = false, focusMuscles = "Full Body"),
                FourWeekPlanDayEntity(id = "w2_d6", weekNumber = 2, dayNumber = 6, title = "Legs & Glutes", exerciseCount = 16, targetCalories = 340, durationMinutes = 15, isCompleted = false, focusMuscles = "Quads, Butt"),
                FourWeekPlanDayEntity(id = "w2_d7", weekNumber = 2, dayNumber = 7, title = "Jawline & Face", exerciseCount = 12, targetCalories = 150, durationMinutes = 12, isCompleted = false, focusMuscles = "Masseter, Neck"),
                // Week 3
                FourWeekPlanDayEntity(id = "w3_d1", weekNumber = 3, dayNumber = 1, title = "Arm Titan", exerciseCount = 18, targetCalories = 400, durationMinutes = 18, isCompleted = false, focusMuscles = "Arms"),
                FourWeekPlanDayEntity(id = "w3_d2", weekNumber = 3, dayNumber = 2, title = "Chest Blast", exerciseCount = 14, targetCalories = 380, durationMinutes = 17, isCompleted = false, focusMuscles = "Chest"),
                FourWeekPlanDayEntity(id = "w3_d3", weekNumber = 3, dayNumber = 3, title = "Abs Shredder", exerciseCount = 20, targetCalories = 420, durationMinutes = 19, isCompleted = false, focusMuscles = "Abs"),
                FourWeekPlanDayEntity(id = "w3_d4", weekNumber = 3, dayNumber = 4, title = "Leg Power", exerciseCount = 19, targetCalories = 430, durationMinutes = 20, isCompleted = false, focusMuscles = "Legs"),
                // Week 4
                FourWeekPlanDayEntity(id = "w4_d1", weekNumber = 4, dayNumber = 1, title = "Arm Apex", exerciseCount = 20, targetCalories = 480, durationMinutes = 22, isCompleted = false, focusMuscles = "Arms"),
                FourWeekPlanDayEntity(id = "w4_d2", weekNumber = 4, dayNumber = 2, title = "Abs Final Cut", exerciseCount = 22, targetCalories = 510, durationMinutes = 24, isCompleted = false, focusMuscles = "Abs"),
                FourWeekPlanDayEntity(id = "w4_d3", weekNumber = 4, dayNumber = 3, title = "Chest Dominator", exerciseCount = 18, targetCalories = 490, durationMinutes = 22, isCompleted = false, focusMuscles = "Chest"),
                FourWeekPlanDayEntity(id = "w4_d4", weekNumber = 4, dayNumber = 4, title = "Metabolic Inferno", exerciseCount = 25, targetCalories = 560, durationMinutes = 26, isCompleted = false, focusMuscles = "Full Body")
            )
            dao.insertFourWeekPlans(default4WeekPlan)

            // Seed Weight Logs for Tracking Progress Graph
            val initialWeightLogs = listOf(
                WeightLogEntity(weightKg = 88.8f, weightLbs = 195.8f, dateStr = "Day 1", timestamp = System.currentTimeMillis() - 28L * 86400000L),
                WeightLogEntity(weightKg = 86.5f, weightLbs = 190.7f, dateStr = "Day 7", timestamp = System.currentTimeMillis() - 21L * 86400000L),
                WeightLogEntity(weightKg = 83.2f, weightLbs = 183.4f, dateStr = "Day 14", timestamp = System.currentTimeMillis() - 14L * 86400000L),
                WeightLogEntity(weightKg = 79.8f, weightLbs = 175.9f, dateStr = "Day 21", timestamp = System.currentTimeMillis() - 7L * 86400000L),
                WeightLogEntity(weightKg = 77.2f, weightLbs = 170.2f, dateStr = "Day 28", timestamp = System.currentTimeMillis(), note = "4 weeks later -11.6 kg! 🔥")
            )
            dao.insertWeightLogs(initialWeightLogs)

            // Seed Weightlifting Set Logs
            val initialSets = listOf(
                WeightliftingSetLogEntity(workoutTitle = "Bent-over Row • Barbell", exerciseName = "Bent-over Row • Barbell", setNumber = 1, weightKg = 20f, reps = 12, isCompleted = true),
                WeightliftingSetLogEntity(workoutTitle = "Bent-over Row • Barbell", exerciseName = "Bent-over Row • Barbell", setNumber = 2, weightKg = 25f, reps = 12, isCompleted = true),
                WeightliftingSetLogEntity(workoutTitle = "Bent-over Row • Barbell", exerciseName = "Bent-over Row • Barbell", setNumber = 3, weightKg = 30f, reps = 12, isCompleted = false),
                WeightliftingSetLogEntity(workoutTitle = "Bent-over Row • Barbell", exerciseName = "Bent-over Row • Barbell", setNumber = 4, weightKg = 30f, reps = 10, isCompleted = false)
            )
            dao.insertWeightliftingSets(initialSets)

            // Seed Habit Reminders
            val initialReminders = listOf(
                HabitReminderEntity(id = "rem_1", timeStr = "20:00 PM", daysLabel = "Everyday", isEnabled = true),
                HabitReminderEntity(id = "rem_2", timeStr = "17:00 PM", daysLabel = "Mon, Wed, Thu, Sat", isEnabled = false),
                HabitReminderEntity(id = "rem_3", timeStr = "08:00 AM", daysLabel = "Mon, Tue, Thu, Sat", isEnabled = false)
            )
            dao.insertHabitReminders(initialReminders)

            // Seed Health & Mewing Articles
            val initialArticles = listOf(
                ArticleEntity(
                    id = "art_1",
                    title = "What is Mewing?",
                    category = "MEWING",
                    readTime = "3-minute read",
                    summary = "The scientific principle of proper tongue posture on the palate to expand the dental arch and sharpen the mandibular jawline.",
                    content = "Mewing is the practice of resting the entire tongue against the roof of the mouth (palate) while keeping lips sealed and teeth gently touching. Originated by Dr. John Mew and Dr. Mike Mew, this orthotropic posture applies upward and forward remodeling force to the maxilla. Over time, it promotes higher cheekbones, opens airway passages, and develops a chiseled jawline.",
                    emoji = "🥷"
                ),
                ArticleEntity(
                    id = "art_2",
                    title = "How Facial Exercises Benefit You",
                    category = "FACIAL_EXERCISE",
                    readTime = "4-minute read",
                    summary = "Strengthening the 43 facial muscles boosts skin elasticity, blood flow, and accelerates facial fat loss.",
                    content = "Just like body muscles, facial muscles respond to progressive tension. Regular masseter clenches, platysma stretches, and cheek resistance increase collagen synthesis and tighten submental skin under the chin.",
                    emoji = "✨"
                ),
                ArticleEntity(
                    id = "art_3",
                    title = "Diet Tips & Tricks for Slimming Face",
                    category = "DIET",
                    readTime = "2-minute read",
                    summary = "Reducing sodium water retention and maintaining optimal hydration to bring out cheek hollows.",
                    content = "Water retention can mask facial bone structure. Drink at least 3-4 liters of water daily, consume potassium-rich foods (bananas, spinach) to balance sodium, and avoid processed sugars.",
                    emoji = "🥑"
                ),
                ArticleEntity(
                    id = "art_4",
                    title = "Why You Don't See Results from Facial Exercises",
                    category = "POSTURE",
                    readTime = "3-minute read",
                    summary = "Addressing forward head posture and inconsistent tongue placement.",
                    content = "If forward head posture ('tech neck') is present, the hyoid muscles cannot engage correctly. Always align your cervical spine before performing facial exercises for maximum leverage.",
                    emoji = "⚡"
                )
            )
            dao.insertArticles(initialArticles)

            // Seed Custom Workout Plans
            val initialPlans = listOf(
                CustomWorkoutPlanEntity(
                    id = "plan_1",
                    title = "Plan 1 - Full Body Burn",
                    durationMinutes = 24,
                    exerciseCount = 6,
                    exerciseNamesSummary = "Push-up, Bent-over Row, Side Plank, Donkey Kicks, Jumping Jacks, Mewing",
                    focusAreas = "Full Body, Core, Jawline"
                ),
                CustomWorkoutPlanEntity(
                    id = "plan_2",
                    title = "Plan 2 - Chiseled Jaw & Posture",
                    durationMinutes = 10,
                    exerciseCount = 5,
                    exerciseNamesSummary = "Mewing, Neck Lift, Face Massage, Mouthwash, Head Tilt",
                    focusAreas = "Face & Jawline, Neck"
                )
            )
            dao.insertCustomWorkoutPlans(initialPlans)

            // Seed Community Challenges
            val defaultChallenges = listOf(
                CommunityChallengeEntity(
                    id = "chal_30_jaw",
                    title = "30 Days Jawline Challenge",
                    subtitle = "A quick challenge, to get the quickest aesthetic result.",
                    participantsCount = "4,200+ Active",
                    progressPercentage = 16,
                    daysTotal = 30,
                    daysCompleted = 5,
                    isJoined = true,
                    rewardBadge = "👑 SHARP JAWLINE",
                    emoji = "🔥"
                ),
                CommunityChallengeEntity(
                    id = "chal_60_glow",
                    title = "60 Days Jawline & Posture Challenge",
                    subtitle = "The start of your total glow up journey.",
                    participantsCount = "8,450+ Active",
                    progressPercentage = 0,
                    daysTotal = 60,
                    daysCompleted = 0,
                    isJoined = false,
                    rewardBadge = "✨ GLOW UP KING",
                    emoji = "⚡"
                ),
                CommunityChallengeEntity(
                    id = "chal_120_beast",
                    title = "120 Days Jawline Transformation",
                    subtitle = "Made for beasts who can stay committed to peak aesthetics.",
                    participantsCount = "12,100+ Athletes",
                    progressPercentage = 0,
                    daysTotal = 120,
                    daysCompleted = 0,
                    isJoined = false,
                    rewardBadge = "🦾 GODLIKE AESTHETIC",
                    emoji = "🏆"
                )
            )
            dao.insertChallenges(defaultChallenges)

            // Seed default admin posts
            val defaultAdminPosts = listOf(
                AdminPostEntity(
                    id = "post_1",
                    title = "How to overload muscles with 5L water bottles",
                    category = "GYM",
                    description = "Key guide to tempo training: 4-second negatives and peak pauses multiply domestic water weight resistance by 3x.",
                    targetMuscle = "Chest & Biceps",
                    model3dAsset = "chest_mesh",
                    authorName = "ABHIRAJ KUMAR (Admin)"
                ),
                AdminPostEntity(
                    id = "post_2",
                    title = "Tech-Neck reduction protocol 2026",
                    category = "FACE_SMART",
                    description = "Perform 12 cervical retractions every 2 hours of screen time for instant posture restoration.",
                    targetMuscle = "Neck & Jawline",
                    model3dAsset = "jaw_mesh",
                    authorName = "ABHIRAJ KUMAR (Admin)"
                )
            )
            defaultAdminPosts.forEach { dao.insertAdminPost(it) }
        }
    }
}
