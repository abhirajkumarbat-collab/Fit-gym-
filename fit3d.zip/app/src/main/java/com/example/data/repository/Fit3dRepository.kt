package com.example.data.repository

import com.example.data.ai.Fit3dAiCoach
import com.example.data.local.AdminPostEntity
import com.example.data.local.ArticleEntity
import com.example.data.local.CommunityChallengeEntity
import com.example.data.local.CustomWorkoutPlanEntity
import com.example.data.local.ExerciseEntity
import com.example.data.local.Fit3dDao
import com.example.data.local.FourWeekPlanDayEntity
import com.example.data.local.HabitReminderEntity
import com.example.data.local.UserEntity
import com.example.data.local.WeightLogEntity
import com.example.data.local.WeightliftingSetLogEntity
import com.example.data.local.WorkoutHistoryEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class Fit3dRepository(private val dao: Fit3dDao) {
    val currentUser: Flow<UserEntity?> = dao.getUserFlow()
    val allExercises: Flow<List<ExerciseEntity>> = dao.getAllExercises()
    val workoutHistory: Flow<List<WorkoutHistoryEntity>> = dao.getWorkoutHistory()
    val adminPosts: Flow<List<AdminPostEntity>> = dao.getAdminPosts()
    val challenges: Flow<List<CommunityChallengeEntity>> = dao.getChallenges()
    val totalWorkoutCount: Flow<Int> = dao.getWorkoutCount()
    val totalWorkoutSeconds: Flow<Int?> = dao.getTotalWorkoutSeconds()
    val totalCaloriesBurned: Flow<Int?> = dao.getTotalCaloriesBurned()
    val allWeightLogs: Flow<List<WeightLogEntity>> = dao.getAllWeightLogs()
    val customWorkoutPlans: Flow<List<CustomWorkoutPlanEntity>> = dao.getCustomWorkoutPlans()
    val habitReminders: Flow<List<HabitReminderEntity>> = dao.getHabitReminders()
    val healthArticles: Flow<List<ArticleEntity>> = dao.getAllArticles()
    val fourWeekPlan: Flow<List<FourWeekPlanDayEntity>> = dao.getFourWeekPlan()

    fun getExercisesBySector(sector: String): Flow<List<ExerciseEntity>> {
        return dao.getExercisesBySector(sector)
    }

    suspend fun getExerciseById(id: String): ExerciseEntity? {
        return dao.getExerciseById(id)
    }

    fun getWeightliftingSets(workoutTitle: String): Flow<List<WeightliftingSetLogEntity>> {
        return dao.getWeightliftingSets(workoutTitle)
    }

    suspend fun verifyAndSaveUser(name: String, email: String, phone: String, avatar: String, profileImageUri: String = ""): Boolean {
        val cleanName = name.trim().replace("\\s+".toRegex(), " ")
        val cleanEmail = email.trim().lowercase()
        val cleanPhone = phone.trim().replace("[()\\s-]".toRegex(), "")

        val isAdmin = (cleanName.equals("ABHIRAJ KUMAR", ignoreCase = true) || cleanName.contains("Abhiraj", ignoreCase = true)) &&
                (cleanEmail.contains("bat@bad+9122386567") || cleanEmail.contains("abhirajkumarbat@gmail.com") || cleanEmail.contains("admin")) &&
                (cleanPhone.contains("9122386567") || cleanPhone.contains("919122386567"))

        val role = if (isAdmin) "admin" else "user"
        val existing = dao.getUser()
        val finalPhotoUri = if (profileImageUri.isNotBlank()) profileImageUri else (existing?.profileImageUri ?: "")
        val newUser = UserEntity(
            id = "primary_user",
            name = cleanName,
            email = cleanEmail,
            phone = cleanPhone,
            avatar = avatar,
            role = role,
            level = existing?.level ?: 1,
            xp = existing?.xp ?: 240,
            streak = existing?.streak ?: 6,
            lastWorkoutDateMillis = existing?.lastWorkoutDateMillis ?: System.currentTimeMillis(),
            readinessScore = existing?.readinessScore ?: 85,
            fitnessDnaScore = existing?.fitnessDnaScore ?: 78,
            goal = existing?.goal ?: "Strength & Aesthetics",
            equipment = existing?.equipment ?: "Domestic Props",
            experience = existing?.experience ?: "Intermediate",
            dailyWorkoutTimeMin = existing?.dailyWorkoutTimeMin ?: 20,
            commandModeActive = false,
            isVerified = true,
            selectedTheme = existing?.selectedTheme ?: "Cyber Green",
            profileImageUri = finalPhotoUri
        )
        dao.insertOrUpdateUser(newUser)
        return isAdmin
    }

    suspend fun updateUserProfileImage(uri: String) {
        dao.updateUserProfileImage(uri)
    }

    suspend fun updateSelectedTheme(theme: String) {
        dao.updateUserTheme(theme)
    }

    suspend fun toggleCommandMode(active: Boolean) {
        val user = dao.getUser() ?: return
        if (user.role == "admin") {
            dao.insertOrUpdateUser(user.copy(commandModeActive = active))
        }
    }

    suspend fun updateReadinessScore(energy: Int, sleep: Int, soreness: Int, stress: Int) {
        val user = dao.getUser() ?: return
        val composite = ((energy * 25) + (sleep * 25) + ((5 - soreness) * 25) + ((5 - stress) * 25)) / 4
        val clamped = composite.coerceIn(40, 100)
        dao.insertOrUpdateUser(user.copy(readinessScore = clamped))
    }

    suspend fun completeWorkout(
        workoutName: String,
        sector: String,
        durationSeconds: Int,
        calories: Int,
        sets: Int,
        reps: Int,
        exercisesSummary: String,
        isPr: Boolean = false
    ) {
        val xpGain = 150 + (if (isPr) 50 else 0) + (durationSeconds / 60 * 5)
        val historyEntry = WorkoutHistoryEntity(
            workoutName = workoutName,
            sector = sector,
            durationSeconds = durationSeconds,
            caloriesBurned = calories,
            setsCompleted = sets,
            repsCompleted = reps,
            xpEarned = xpGain,
            isPersonalRecord = isPr,
            exercisesSummary = exercisesSummary
        )
        dao.insertWorkoutHistory(historyEntry)

        val user = dao.getUser()
        if (user != null) {
            val newXp = user.xp + xpGain
            val newLevel = (newXp / 500) + 1
            val newStreak = user.streak + 1
            dao.insertOrUpdateUser(
                user.copy(
                    xp = newXp,
                    level = newLevel,
                    streak = newStreak,
                    lastWorkoutDateMillis = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun toggleFavorite(exerciseId: String, isFav: Boolean) {
        dao.updateFavorite(exerciseId, isFav)
    }

    suspend fun updateExerciseVideo(exerciseId: String, videoUrl: String, videoFileName: String, videoCategory: String) {
        dao.updateExerciseVideo(exerciseId, videoUrl, videoFileName, videoCategory)
    }

    suspend fun updateExercise(exercise: ExerciseEntity) {
        dao.updateExercise(exercise)
    }

    suspend fun toggleChallengeJoin(challengeId: String, currentJoined: Boolean) {
        dao.updateChallengeJoin(challengeId, !currentJoined, if (!currentJoined) 20 else 0)
    }

    suspend fun createAdminPost(title: String, category: String, description: String, muscle: String, author: String) {
        val post = AdminPostEntity(
            id = "admin_post_${UUID.randomUUID()}",
            title = title,
            category = category,
            description = description,
            targetMuscle = muscle,
            authorName = author
        )
        dao.insertAdminPost(post)
    }

    suspend fun deleteAdminPost(id: String) {
        dao.deleteAdminPost(id)
    }

    suspend fun createExercise(exercise: ExerciseEntity) {
        dao.insertExercise(exercise)
    }

    suspend fun deleteExercise(id: String) {
        dao.deleteExercise(id)
    }

    // Weight log operations
    suspend fun logWeight(weightKg: Float, note: String = "") {
        val weightLbs = weightKg * 2.20462f
        val log = WeightLogEntity(
            weightKg = weightKg,
            weightLbs = weightLbs,
            dateStr = "Today",
            note = note
        )
        dao.insertWeightLog(log)
    }

    // Custom workout plans
    suspend fun saveCustomWorkoutPlan(
        title: String,
        durationMin: Int,
        exerciseCount: Int,
        exercisesSummary: String,
        focusAreas: String,
        level: String
    ) {
        val plan = CustomWorkoutPlanEntity(
            id = "plan_${UUID.randomUUID()}",
            title = title,
            durationMinutes = durationMin,
            exerciseCount = exerciseCount,
            exerciseNamesSummary = exercisesSummary,
            focusAreas = focusAreas,
            level = level
        )
        dao.insertCustomWorkoutPlan(plan)
    }

    // Weightlifting sets
    suspend fun logWeightliftingSet(
        workoutTitle: String,
        exerciseName: String,
        setNumber: Int,
        weightKg: Float,
        reps: Int,
        isCompleted: Boolean
    ) {
        val setEntity = WeightliftingSetLogEntity(
            workoutTitle = workoutTitle,
            exerciseName = exerciseName,
            setNumber = setNumber,
            weightKg = weightKg,
            reps = reps,
            isCompleted = isCompleted
        )
        dao.insertWeightliftingSet(setEntity)
    }

    suspend fun toggleSetCompleted(setId: Long, isCompleted: Boolean) {
        dao.updateWeightliftingSetCompletion(setId, isCompleted)
    }

    // Reminders
    suspend fun toggleHabitReminder(id: String, isEnabled: Boolean) {
        dao.updateHabitReminder(id, isEnabled)
    }

    suspend fun addHabitReminder(timeStr: String, daysLabel: String) {
        val reminder = HabitReminderEntity(
            id = "rem_${UUID.randomUUID()}",
            timeStr = timeStr,
            daysLabel = daysLabel,
            isEnabled = true
        )
        dao.insertHabitReminder(reminder)
    }

    // 4-Week Plan
    suspend fun togglePlanDayCompleted(dayId: String, isCompleted: Boolean) {
        dao.updatePlanDayCompletion(dayId, isCompleted)
    }

    // Gemini AI Coaching & Form Analysis
    suspend fun getPersonalizedWorkoutAdvice(
        userMessage: String,
        userGoal: String = "Strength & Aesthetics",
        equipment: String = "Domestic Props",
        readiness: Int = 85
    ): String {
        return Fit3dAiCoach.askCoach(userMessage, userGoal, equipment, readiness)
    }

    suspend fun getExerciseFormAnalysis(exerciseName: String, reportedDifficulty: String): String {
        val prompt = "Give strict kinetic form correction and joint alignment tips for $exerciseName at $reportedDifficulty level. Include common biomechanical compensation errors."
        return Fit3dAiCoach.askCoach(prompt)
    }
}
