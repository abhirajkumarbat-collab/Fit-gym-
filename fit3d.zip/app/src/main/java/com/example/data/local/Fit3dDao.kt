package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface Fit3dDao {
    // User profile
    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserFlow(id: String = "primary_user"): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUser(id: String = "primary_user"): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateUser(user: UserEntity)

    @Query("UPDATE users SET selectedTheme = :theme WHERE id = :id")
    suspend fun updateUserTheme(theme: String, id: String = "primary_user")

    @Query("UPDATE users SET profileImageUri = :uri WHERE id = :id")
    suspend fun updateUserProfileImage(uri: String, id: String = "primary_user")

    // Exercises
    @Query("SELECT * FROM exercises ORDER BY id ASC")
    fun getAllExercises(): Flow<List<ExerciseEntity>>

    @Query("SELECT * FROM exercises WHERE sector = :sector ORDER BY id ASC")
    fun getExercisesBySector(sector: String): Flow<List<ExerciseEntity>>

    @Query("SELECT * FROM exercises WHERE id = :id LIMIT 1")
    suspend fun getExerciseById(id: String): ExerciseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercises(exercises: List<ExerciseEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercise(exercise: ExerciseEntity)

    @Query("UPDATE exercises SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: String, isFavorite: Boolean)

    @Query("UPDATE exercises SET videoUrl = :videoUrl, videoFileName = :videoFileName, videoCategory = :videoCategory WHERE id = :id")
    suspend fun updateExerciseVideo(id: String, videoUrl: String, videoFileName: String, videoCategory: String)

    @Update
    suspend fun updateExercise(exercise: ExerciseEntity)

    @Query("DELETE FROM exercises WHERE id = :id")
    suspend fun deleteExercise(id: String)

    // Workout History
    @Query("SELECT * FROM workout_history ORDER BY timestamp DESC")
    fun getWorkoutHistory(): Flow<List<WorkoutHistoryEntity>>

    @Query("SELECT COUNT(*) FROM workout_history")
    fun getWorkoutCount(): Flow<Int>

    @Query("SELECT SUM(durationSeconds) FROM workout_history")
    fun getTotalWorkoutSeconds(): Flow<Int?>

    @Query("SELECT SUM(caloriesBurned) FROM workout_history")
    fun getTotalCaloriesBurned(): Flow<Int?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkoutHistory(history: WorkoutHistoryEntity)

    // Admin Posts
    @Query("SELECT * FROM admin_posts ORDER BY timestamp DESC")
    fun getAdminPosts(): Flow<List<AdminPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdminPost(post: AdminPostEntity)

    @Query("DELETE FROM admin_posts WHERE id = :id")
    suspend fun deleteAdminPost(id: String)

    // Community Challenges
    @Query("SELECT * FROM community_challenges ORDER BY id ASC")
    fun getChallenges(): Flow<List<CommunityChallengeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChallenges(challenges: List<CommunityChallengeEntity>)

    @Query("UPDATE community_challenges SET isJoined = :isJoined, progressPercentage = :progress WHERE id = :id")
    suspend fun updateChallengeJoin(id: String, isJoined: Boolean, progress: Int)

    // Weight Logs
    @Query("SELECT * FROM weight_logs ORDER BY timestamp ASC")
    fun getAllWeightLogs(): Flow<List<WeightLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeightLog(log: WeightLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeightLogs(logs: List<WeightLogEntity>)

    // Custom Workout Plans
    @Query("SELECT * FROM custom_workout_plans ORDER BY createdAt DESC")
    fun getCustomWorkoutPlans(): Flow<List<CustomWorkoutPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomWorkoutPlan(plan: CustomWorkoutPlanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomWorkoutPlans(plans: List<CustomWorkoutPlanEntity>)

    // Weightlifting Sets
    @Query("SELECT * FROM weightlifting_set_logs WHERE workoutTitle = :workoutTitle ORDER BY setNumber ASC")
    fun getWeightliftingSets(workoutTitle: String): Flow<List<WeightliftingSetLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeightliftingSets(sets: List<WeightliftingSetLogEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeightliftingSet(set: WeightliftingSetLogEntity)

    @Query("UPDATE weightlifting_set_logs SET isCompleted = :completed WHERE id = :id")
    suspend fun updateWeightliftingSetCompletion(id: Long, completed: Boolean)

    // Habit Reminders
    @Query("SELECT * FROM habit_reminders ORDER BY id ASC")
    fun getHabitReminders(): Flow<List<HabitReminderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabitReminders(reminders: List<HabitReminderEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabitReminder(reminder: HabitReminderEntity)

    @Query("UPDATE habit_reminders SET isEnabled = :isEnabled WHERE id = :id")
    suspend fun updateHabitReminder(id: String, isEnabled: Boolean)

    // Health Articles
    @Query("SELECT * FROM health_articles ORDER BY id ASC")
    fun getAllArticles(): Flow<List<ArticleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArticles(articles: List<ArticleEntity>)

    // 4-Week Plan Days
    @Query("SELECT * FROM four_week_plans ORDER BY weekNumber ASC, dayNumber ASC")
    fun getFourWeekPlan(): Flow<List<FourWeekPlanDayEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFourWeekPlans(plans: List<FourWeekPlanDayEntity>)

    @Query("UPDATE four_week_plans SET isCompleted = :completed WHERE id = :id")
    suspend fun updatePlanDayCompletion(id: String, completed: Boolean)
}
