package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String = "primary_user",
    val name: String,
    val email: String,
    val phone: String,
    val avatar: String = "🥷",
    val role: String = "user", // "admin" or "user"
    val level: Int = 1,
    val xp: Int = 240,
    val streak: Int = 6,
    val lastWorkoutDateMillis: Long = System.currentTimeMillis(),
    val readinessScore: Int = 85,
    val fitnessDnaScore: Int = 78,
    val goal: String = "Strength & Aesthetics",
    val equipment: String = "Domestic Props",
    val experience: String = "Intermediate",
    val dailyWorkoutTimeMin: Int = 20,
    val commandModeActive: Boolean = false,
    val isVerified: Boolean = true,
    val selectedTheme: String = "Cyber Green",
    val profileImageUri: String = ""
)
