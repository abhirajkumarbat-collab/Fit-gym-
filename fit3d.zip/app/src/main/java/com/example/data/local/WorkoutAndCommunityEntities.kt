package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workout_history")
data class WorkoutHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workoutName: String,
    val sector: String,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int,
    val caloriesBurned: Int,
    val setsCompleted: Int,
    val repsCompleted: Int,
    val xpEarned: Int = 150,
    val isPersonalRecord: Boolean = false,
    val exercisesSummary: String
)

@Entity(tableName = "admin_posts")
data class AdminPostEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String, // "GYM", "YOGA", "FACE_SMART", "ANNOUNCEMENT"
    val description: String,
    val timestamp: Long = System.currentTimeMillis(),
    val targetMuscle: String,
    val model3dAsset: String = "",
    val mediaUri: String = "",
    val isPublished: Boolean = true,
    val authorName: String = "ABHIRAJ KUMAR (Admin)"
)

@Entity(tableName = "community_challenges")
data class CommunityChallengeEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subtitle: String,
    val participantsCount: String,
    val progressPercentage: Int,
    val daysTotal: Int,
    val daysCompleted: Int,
    val isJoined: Boolean = false,
    val rewardBadge: String,
    val emoji: String = "🔥"
) {
    val iconEmoji: String get() = emoji
    val xpReward: Int get() = 300
    val description: String get() = subtitle
}

@Entity(tableName = "weight_logs")
data class WeightLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val weightKg: Float,
    val weightLbs: Float,
    val dateStr: String,
    val timestamp: Long = System.currentTimeMillis(),
    val note: String = ""
)

@Entity(tableName = "custom_workout_plans")
data class CustomWorkoutPlanEntity(
    @PrimaryKey val id: String,
    val title: String,
    val durationMinutes: Int,
    val exerciseCount: Int,
    val exerciseNamesSummary: String,
    val focusAreas: String,
    val level: String = "All Levels",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "weightlifting_set_logs")
data class WeightliftingSetLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workoutTitle: String,
    val exerciseName: String,
    val setNumber: Int,
    val weightKg: Float,
    val reps: Int,
    val isCompleted: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "habit_reminders")
data class HabitReminderEntity(
    @PrimaryKey val id: String,
    val timeStr: String,
    val daysLabel: String,
    val isEnabled: Boolean
)

@Entity(tableName = "health_articles")
data class ArticleEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String, // "MEWING", "DIET", "POSTURE", "FACIAL_EXERCISE"
    val readTime: String,
    val summary: String,
    val content: String,
    val emoji: String = "📚",
    val author: String = "Dr. Mike Mew & Fitness Team"
) {
    val readTimeMinutes: Int get() = 4
}

@Entity(tableName = "four_week_plans")
data class FourWeekPlanDayEntity(
    @PrimaryKey val id: String,
    val weekNumber: Int,
    val dayNumber: Int,
    val title: String,
    val exerciseCount: Int,
    val targetCalories: Int,
    val durationMinutes: Int,
    val isCompleted: Boolean = false,
    val focusMuscles: String = "Chest, Core"
)

typealias FourWeekPlanEntity = FourWeekPlanDayEntity
