package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "exercises")
data class ExerciseEntity(
    @PrimaryKey val id: String,
    val title: String,
    val sector: String, // "GYM", "YOGA", "FACE_SMART"
    val subtitle: String,
    val domesticProp: String, // "Water Bottles (2L)", "Sturdy Chair", "Backpack Weights", "Bath Towel", "Bodyweight", "Barbell", "Dumbbell"
    val targetMuscles: String, // Comma-separated: "Chest, Triceps, Shoulders" or "Masseter, Jawline, Neck"
    val primaryMuscleCode: String, // "CHEST", "BICEPS", "TRICEPS", "ABS", "QUADS", "GLUTES", "JAWLINE", "NECK", "SPINE", "BACK", "SHOULDERS", "BUTT"
    val difficulty: String, // "Beginner", "Intermediate", "Advanced", "Elite"
    val defaultSets: Int = 3,
    val defaultReps: Int = 12,
    val defaultDurationSec: Int = 45,
    val restDurationSec: Int = 30,
    val caloriesPerSet: Int = 18,
    val instructions: String,
    val commonMistakes: String,
    val formTips: String,
    val iconEmoji: String = "🏋️",
    val isFavorite: Boolean = false,
    val videoUrl: String = "https://drive.google.com/drive/folders/1vBx4tzfMJGCUNlg-78YMbbq6qCqr6CQF",
    val videoFileName: String = "01_motion_guide.mp4",
    val videoCategory: String = "Chest & Pecs",
    val videoResolution: String = "4K 60FPS ULTRA",
    val videoAnglesAvailable: String = "Front (0°), Oblique (45°), Profile (90°)",
    val isCustomAdminPost: Boolean = false,
    val equipmentCategory: String = "No equipment", // "No equipment", "Body Weight", "Dumbbell", "Barbell", "Cable Machine", "Domestic Prop"
    val focusAreaGroup: String = "Chest", // "Full Body", "Chest", "Abs", "Arms", "Leg", "Back", "Butt", "Face & Jawline"
    val coachVoiceTip: String = "Maintain core tension, align spine, and breathe rhythmically."
) {
    val durationSec: Int get() = defaultDurationSec
}
