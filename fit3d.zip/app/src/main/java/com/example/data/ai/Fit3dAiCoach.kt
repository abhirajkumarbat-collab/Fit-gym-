package com.example.data.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object Fit3dAiCoach {
    private const val MODEL_NAME = "gemini-2.5-flash"
    private const val API_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun askCoach(
        userMessage: String,
        userGoal: String = "Strength & Aesthetics",
        availableEquipment: String = "Domestic Props",
        currentReadiness: Int = 85
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext getOfflineSmartCoachAdvice(userMessage, userGoal, availableEquipment, currentReadiness)
        }

        try {
            val systemInstruction = """
                You are the FIT3D Cyber Fitness & Aesthetics Coach (🦾⚡).
                Your tone is high-energy, authoritative, motivating, scientifically grounded, and concise.
                User profile context:
                - Goal: $userGoal
                - Available Equipment: $availableEquipment (water bottles, chairs, backpack, towels, bodyweight)
                - Current Daily Readiness: $currentReadiness/100
                Provide actionable, punchy bulleted advice for domestic prop workouts, Mewing/jawline posture, yoga flows, or recovery. Always add attitude emojis (⚡🦾🔥). Keep responses within 3-5 concise bullet points.
            """.trimIndent()

            val requestJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", userMessage) })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", systemInstruction) })
                    })
                })
            }

            val body = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$API_URL?key=$apiKey")
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val json = JSONObject(responseBody)
                val candidates = json.optJSONArray("candidates")
                val text = candidates?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")

                if (!text.isNullOrBlank()) {
                    return@withContext text
                }
            }

            getOfflineSmartCoachAdvice(userMessage, userGoal, availableEquipment, currentReadiness)
        } catch (e: Exception) {
            getOfflineSmartCoachAdvice(userMessage, userGoal, availableEquipment, currentReadiness)
        }
    }

    private fun getOfflineSmartCoachAdvice(
        query: String,
        goal: String,
        equipment: String,
        readiness: Int
    ): String {
        val q = query.lowercase()
        return when {
            q.contains("chest") || q.contains("push") -> """
                🦾 FIT3D CHEST DOMINATION PROTOCOL:
                • Load two 5L water bottles into a backpack or hold individually for Domestic Floor Presses (4 sets × 12 reps).
                • Emphasize a 3-second negative eccentric tempo to multiply muscle tension 3x!
                • Finisher: 3 sets of Diamond Floor Push-Ups to complete failure 🔥
                • Target Muscle: Pectoral Core glowing neon green 🟢
            """.trimIndent()

            q.contains("jaw") || q.contains("mewing") || q.contains("face") || q.contains("posture") -> """
                🥷 FIT3D FACIAL AESTHETIC PROTOCOL:
                • Posterior Third Tongue Suction: Lock the entire rear tongue flat to the hard/soft palate.
                • Masseter Isometric Holds: 4 sets of 15 reps with 3-second peak clenches.
                • Cervical Retraction (Tech-Neck Eraser): 12 chin tucks holding for 5 seconds against a wall.
                • Posture Rule: Shoulders pinned down, crown elevated straight up ⚡
            """.trimIndent()

            q.contains("arms") || q.contains("bicep") || q.contains("tricep") -> """
                ⚡ HIGH TENSION DOMESTIC ARMS:
                • Chair Elevation Dips: 3 sets × 15 reps keeping torso vertical for tricep peak isolation.
                • Backpack Hammer Curls: Grip backpack top handle loaded with heavy books (4 × 12 reps).
                • Doorframe Isometric Towel Rows: 2-second static squeeze for peak bicep recruitment 🔥
            """.trimIndent()

            q.contains("legs") || q.contains("squat") -> """
                🦵 LOWER BODY KINETIC OVERLOAD:
                • Book-Loaded Backpack Goblet Squats: 4 sets × 15 reps down below parallel.
                • Single-Leg Bulgarian Split Squats using a dining chair as rear foot elevation.
                • High-tension Glute Bridges with domestic water weight resting on pelvis ⚡
            """.trimIndent()

            q.contains("yoga") || q.contains("flexibility") || q.contains("recover") -> """
                🧘 ZEN KINETIC RECOVERY FLOW:
                • 5 rounds of Surya Namaskar synchronizing breath with each kinetic phase.
                • 60-second Deep Pigeon Pose release on each hip with cushion support.
                • Warrior II stability hold with calm rhythmic nasal breathing ✨
            """.trimIndent()

            else -> """
                🦾 FIT3D INTELLIGENCE ENGINE (Readiness: $readiness/100):
                • Goal Alignment: Optimizing for $goal using $equipment.
                • Progressive Overload: Increase set volume by 10% or slow down tempo by 1 extra second.
                • Domestic Props: Water jugs, backpacks, and dining chairs give elite mechanical tension.
                • Stay consistent, track every rep, and dominate your daily goal 💯
            """.trimIndent()
        }
    }
}
