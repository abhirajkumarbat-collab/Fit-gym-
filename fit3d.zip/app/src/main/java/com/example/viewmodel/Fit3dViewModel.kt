package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.Fit3dAiCoach
import com.example.data.local.AdminPostEntity
import com.example.data.local.ArticleEntity
import com.example.data.local.CommunityChallengeEntity
import com.example.data.local.CustomWorkoutPlanEntity
import com.example.data.local.ExerciseEntity
import com.example.data.local.Fit3dDatabase
import com.example.data.local.FourWeekPlanDayEntity
import com.example.data.local.HabitReminderEntity
import com.example.data.local.UserEntity
import com.example.data.local.WeightLogEntity
import com.example.data.local.WeightliftingSetLogEntity
import com.example.data.local.WorkoutHistoryEntity
import com.example.data.repository.Fit3dRepository
import com.example.ui.components.BodyMuscle
import com.example.ui.components.WebSocketLiveAlert
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppScreen {
    SPLASH,
    VERIFICATION,
    USER_HOME,
    ADMIN_DASHBOARD,
    EXERCISE_LIST,
    EXERCISE_DETAIL,
    WORKOUT_PLAYER,
    WEIGHTLIFTING_TRACKER,
    WORKOUT_COMPLETE,
    PROGRESS_ANALYTICS,
    FACE_SMART_HUB,
    PERSONAL_PLAN_BUILDER,
    COMMUNITY_TRIBES,
    AI_COACH,
    CAMERA_MIRROR,
    IRONFORGE_PRO_GYM
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

data class WorkoutSessionState(
    val exercise: ExerciseEntity? = null,
    val isPreparing: Boolean = true,
    val prepSecondsLeft: Int = 10,
    val isResting: Boolean = false,
    val restSecondsLeft: Int = 30,
    val currentSet: Int = 1,
    val totalSets: Int = 3,
    val currentReps: Int = 12,
    val totalRepsLogged: Int = 0,
    val elapsedSeconds: Int = 0,
    val isPaused: Boolean = false,
    val caloriesBurned: Int = 0,
    val weightUsed: String = "Domestic Water Jugs (5L)",
    val voiceCoachActive: Boolean = true
)

data class IronForgeChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: String,
    val text: String,
    val timeAgo: String,
    val badge: String
)

data class IronForgeGymStation(
    val id: String,
    val name: String,
    val zone: String,
    val isOccupied: Boolean,
    val currentUser: String?,
    val setsRemaining: Int,
    val status: String
)

class Fit3dViewModel(application: Application) : AndroidViewModel(application) {
    private val database = Fit3dDatabase.getDatabase(application)
    private val repository = Fit3dRepository(database.fit3dDao())

    // App Navigation State
    private val _currentScreen = MutableStateFlow(AppScreen.SPLASH)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _selectedSector = MutableStateFlow("GYM")
    val selectedSector: StateFlow<String> = _selectedSector.asStateFlow()

    private val _selectedExerciseId = MutableStateFlow<String?>(null)
    val selectedExerciseId: StateFlow<String?> = _selectedExerciseId.asStateFlow()

    private val _selectedArticle = MutableStateFlow<ArticleEntity?>(null)
    val selectedArticle: StateFlow<ArticleEntity?> = _selectedArticle.asStateFlow()

    private val _isSearchOpen = MutableStateFlow(false)
    val isSearchOpen: StateFlow<Boolean> = _isSearchOpen.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFocusArea = MutableStateFlow("All")
    val selectedFocusArea: StateFlow<String> = _selectedFocusArea.asStateFlow()

    private val _selectedEquipment = MutableStateFlow("All")
    val selectedEquipment: StateFlow<String> = _selectedEquipment.asStateFlow()

    private val _selectedFitnessLevel = MutableStateFlow("Intermediate")
    val selectedFitnessLevel: StateFlow<String> = _selectedFitnessLevel.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    // 3D Visualizer State
    private val _active3dMuscle = MutableStateFlow(BodyMuscle.CHEST)
    val active3dMuscle: StateFlow<BodyMuscle> = _active3dMuscle.asStateFlow()

    private val _isGreenTargetEnabled = MutableStateFlow(true)
    val isGreenTargetEnabled: StateFlow<Boolean> = _isGreenTargetEnabled.asStateFlow()

    // User & Data Flows
    val currentUser: StateFlow<UserEntity?> = repository.currentUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allExercises: StateFlow<List<ExerciseEntity>> = repository.allExercises
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val workoutHistory: StateFlow<List<WorkoutHistoryEntity>> = repository.workoutHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminPosts: StateFlow<List<AdminPostEntity>> = repository.adminPosts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val challenges: StateFlow<List<CommunityChallengeEntity>> = repository.challenges
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalWorkoutCount: StateFlow<Int> = repository.totalWorkoutCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalWorkoutSeconds: StateFlow<Int?> = repository.totalWorkoutSeconds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalCaloriesBurned: StateFlow<Int?> = repository.totalCaloriesBurned
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val allWeightLogs: StateFlow<List<WeightLogEntity>> = repository.allWeightLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customWorkoutPlans: StateFlow<List<CustomWorkoutPlanEntity>> = repository.customWorkoutPlans
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val habitReminders: StateFlow<List<HabitReminderEntity>> = repository.habitReminders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val healthArticles: StateFlow<List<ArticleEntity>> = repository.healthArticles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val fourWeekPlan: StateFlow<List<FourWeekPlanDayEntity>> = repository.fourWeekPlan
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val fourWeekPlans: StateFlow<List<FourWeekPlanDayEntity>> get() = fourWeekPlan

    val weightliftingSets: StateFlow<List<WeightliftingSetLogEntity>> = repository.getWeightliftingSets("Bent-over Row • Barbell")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredExercises: StateFlow<List<ExerciseEntity>> = combine(
        allExercises,
        searchQuery,
        _selectedFocusArea,
        _selectedEquipment
    ) { exercises, query, focus, equip ->
        var list = exercises
        if (focus != "All") {
            list = list.filter { it.focusAreaGroup.equals(focus, ignoreCase = true) || it.targetMuscles.contains(focus, ignoreCase = true) }
        }
        if (equip != "All") {
            list = list.filter { it.equipmentCategory.equals(equip, ignoreCase = true) || it.domesticProp.contains(equip, ignoreCase = true) }
        }
        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                        it.targetMuscles.lowercase().contains(q) ||
                        it.domesticProp.lowercase().contains(q) ||
                        it.sector.lowercase().contains(q)
            }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchResults: StateFlow<List<ExerciseEntity>> get() = filteredExercises

    // Active Workout Player State
    private val _workoutSession = MutableStateFlow(WorkoutSessionState())
    val workoutSession: StateFlow<WorkoutSessionState> = _workoutSession.asStateFlow()

    private var timerJob: Job? = null

    // AI Coach Chat
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                text = "🦾 FIT3D GEMINI CYBER COACH ONLINE ⚡\nI analyze form, calculate training volume, design progressive domestic prop routines, and guide Mewing/jawline aesthetics! What are we working on today?",
                isUser = false
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isCoachThinking = MutableStateFlow(false)
    val isCoachThinking: StateFlow<Boolean> = _isCoachThinking.asStateFlow()

    // Active Theme & Cyber Lighting Engine
    private val _activeTheme = MutableStateFlow("Cyber Green")
    val activeTheme: StateFlow<String> = _activeTheme.asStateFlow()

    private val _ambientLighting = MutableStateFlow("HIGH")
    val ambientLighting: StateFlow<String> = _ambientLighting.asStateFlow()

    // Real-Time WebSocket Alerts
    private val _webSocketAlert = MutableStateFlow<WebSocketLiveAlert?>(null)
    val webSocketAlert: StateFlow<WebSocketLiveAlert?> = _webSocketAlert.asStateFlow()

    // Biometric Security Gate State for Super Admin Command Core
    private val _isBiometricGateOpen = MutableStateFlow(false)
    val isBiometricGateOpen: StateFlow<Boolean> = _isBiometricGateOpen.asStateFlow()

    private val _serverDiagnosticLogs = MutableStateFlow<List<String>>(
        listOf(
            "[HTTP 200] GET https://api.fit3d.cloud/v1/health - 22ms - TLS 1.3 OK",
            "[CDN READY] GET https://cdn.fit3d-videos.internal/manifest.m3u8 - 200 OK",
            "[AI HOST] POST https://generativelanguage.googleapis.com/v1beta/models - 184ms",
            "[WS CONNECT] wss://ws.fit3d.network:8443 - Handshake Established (524 peers)"
        )
    )
    val serverDiagnosticLogs: StateFlow<List<String>> = _serverDiagnosticLogs.asStateFlow()

    // IronForge Pro Gym Live Telemetry
    private val _liveEnvironment = MutableStateFlow("PRODUCTION")
    val liveEnvironment: StateFlow<String> = _liveEnvironment.asStateFlow()

    private val _liveIpAddress = MutableStateFlow("198.51.100.42 (IPv6: 2400:cb00:2048:1::c629)")
    val liveIpAddress: StateFlow<String> = _liveIpAddress.asStateFlow()

    private val _liveConcurrentLifters = MutableStateFlow(1482)
    val liveConcurrentLifters: StateFlow<Int> = _liveConcurrentLifters.asStateFlow()

    private val _liveGymChatFeed = MutableStateFlow<List<IronForgeChatMessage>>(
        listOf(
            IronForgeChatMessage(sender = "Vikram_Iron", text = "Barbell Incline 95kg 4x8 crushed! The 3D form visualizer is insane 🦾", timeAgo = "1m ago", badge = "PRO LIFTER"),
            IronForgeChatMessage(sender = "Arjun_Heavy", text = "Deadlift PR unlocked: 180kg! Live latency is crisp 20ms", timeAgo = "3m ago", badge = "ELITE"),
            IronForgeChatMessage(sender = "Fit3d_AI_Coach", text = "Reminder: Keep scapular retraction tight during heavy bench pressing ⚡", timeAgo = "5m ago", badge = "AI BOT"),
            IronForgeChatMessage(sender = "Priya_Athlete", text = "Squat Rack 3 is free now in the main zone!", timeAgo = "8m ago", badge = "ATHLETE")
        )
    )
    val liveGymChatFeed: StateFlow<List<IronForgeChatMessage>> = _liveGymChatFeed.asStateFlow()

    private val _liveGymStations = MutableStateFlow<List<IronForgeGymStation>>(
        listOf(
            IronForgeGymStation(id = "st_1", name = "Olympic Bench Press #1", zone = "Zone A - Heavy Pecs", isOccupied = true, currentUser = "Vikram_Iron", setsRemaining = 2, status = "IN USE"),
            IronForgeGymStation(id = "st_2", name = "Power Squat Cage #3", zone = "Zone B - Leg Core", isOccupied = false, currentUser = null, setsRemaining = 0, status = "AVAILABLE"),
            IronForgeGymStation(id = "st_3", name = "Dual Cable Crossover #2", zone = "Zone C - Sculpt", isOccupied = true, currentUser = "Rohan_K", setsRemaining = 1, status = "IN USE"),
            IronForgeGymStation(id = "st_4", name = "Deadlift Hex Platform #1", zone = "Zone D - Posterior", isOccupied = false, currentUser = null, setsRemaining = 0, status = "AVAILABLE"),
            IronForgeGymStation(id = "st_5", name = "Incline Dumbbell Station #4", zone = "Zone A - Heavy Pecs", isOccupied = false, currentUser = null, setsRemaining = 0, status = "AVAILABLE")
        )
    )
    val liveGymStations: StateFlow<List<IronForgeGymStation>> = _liveGymStations.asStateFlow()

    private val _liveTelemetryFeed = MutableStateFlow<List<String>>(
        listOf(
            "[LIVE DATA] 24,890 Reps completed across network in last 60m",
            "[LIVE API] GET /v3/ironforge/telemetry - 200 OK (19ms) • Edge: Mumbai-1",
            "[LIVE SERVER] Production Node Alpha (US-East) Healthy • 99.98% Uptime",
            "[LIVE CODE] Shader Cache Synced • Active Build: v3.8.4-RELEASE",
            "[LIVE MIGRATION] Zero-Downtime Room DB Cache Sync • 100% In-Memory Buffer"
        )
    )
    val liveTelemetryFeed: StateFlow<List<String>> = _liveTelemetryFeed.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            delay(1200)
            launch(Dispatchers.Main) {
                _currentScreen.value = AppScreen.VERIFICATION
            }
        }

        viewModelScope.launch(Dispatchers.IO) {
            repository.currentUser.collectLatest { user ->
                user?.selectedTheme?.let { savedTheme ->
                    if (savedTheme.isNotBlank() && _activeTheme.value != savedTheme) {
                        _activeTheme.value = savedTheme
                    }
                }
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun selectSector(sector: String) {
        _selectedSector.value = sector
        _currentScreen.value = AppScreen.EXERCISE_LIST
    }

    fun setFocusArea(area: String) {
        _selectedFocusArea.value = area
    }

    fun setEquipmentFilter(equip: String) {
        _selectedEquipment.value = equip
    }

    fun setFitnessLevel(level: String) {
        _selectedFitnessLevel.value = level
    }

    fun openExerciseDetail(exerciseId: String) {
        _selectedExerciseId.value = exerciseId
        val ex = allExercises.value.find { it.id == exerciseId }
        ex?.let {
            val muscle = when (it.primaryMuscleCode.uppercase()) {
                "CHEST" -> BodyMuscle.CHEST
                "BICEPS" -> BodyMuscle.BICEPS
                "TRICEPS" -> BodyMuscle.TRICEPS
                "ABS" -> BodyMuscle.ABS
                "QUADS" -> BodyMuscle.QUADS
                "GLUTES", "BUTT" -> BodyMuscle.GLUTES
                "BACK" -> BodyMuscle.BACK
                "SHOULDERS" -> BodyMuscle.SHOULDERS
                "NECK" -> BodyMuscle.NECK
                "JAWLINE" -> BodyMuscle.JAWLINE
                "SPINE" -> BodyMuscle.SPINE
                else -> BodyMuscle.CHEST
            }
            _active3dMuscle.value = muscle
        }
        _currentScreen.value = AppScreen.EXERCISE_DETAIL
    }

    fun openArticle(article: ArticleEntity) {
        _selectedArticle.value = article
    }

    fun closeArticle() {
        _selectedArticle.value = null
    }

    fun setActiveMuscle(muscle: BodyMuscle) {
        _active3dMuscle.value = muscle
    }

    fun toggle3dMuscle(muscle: BodyMuscle) {
        _active3dMuscle.value = muscle
    }

    fun toggleGreenTarget(enabled: Boolean = !_isGreenTargetEnabled.value) {
        _isGreenTargetEnabled.value = enabled
    }

    fun setSearchOpen(open: Boolean) {
        _isSearchOpen.value = open
        if (!open) _searchQuery.value = ""
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun verifyUser(name: String, email: String, phone: String, avatar: String, profileImageUri: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            val isAdmin = repository.verifyAndSaveUser(name, email, phone, avatar, profileImageUri)
            launch(Dispatchers.Main) {
                if (isAdmin) {
                    _toastEvent.emit("⚡ ADMIN ACCESS GRANTED: Welcome Abhiraj Kumar!")
                    // Protect Super Admin Command Core behind Biometric Authentication Gate
                    openBiometricGate()
                } else {
                    _toastEvent.emit("🦾 ATHLETE PROFILE VERIFIED: Welcome $name!")
                    _currentScreen.value = AppScreen.USER_HOME
                }
            }
        }
    }

    fun setTheme(theme: String) {
        _activeTheme.value = theme
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateSelectedTheme(theme)
            launch(Dispatchers.Main) {
                _toastEvent.emit("⚡ Theme switched to $theme (Persisted in Room DB)")
            }
        }
    }

    fun updateProfileImage(uri: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateUserProfileImage(uri)
            launch(Dispatchers.Main) {
                _toastEvent.emit("✓ Profile photo updated successfully!")
            }
        }
    }

    fun openBiometricGate() {
        _isBiometricGateOpen.value = true
    }

    fun toggleCommandMode() {
        if (_currentScreen.value == AppScreen.ADMIN_DASHBOARD) {
            _currentScreen.value = AppScreen.USER_HOME
        } else {
            // Protect Super Admin Command Core behind Biometric Authentication Gate
            openBiometricGate()
        }
    }

    fun closeBiometricGate() {
        _isBiometricGateOpen.value = false
    }

    fun onBiometricAuthSuccess() {
        _isBiometricGateOpen.value = false
        _currentScreen.value = AppScreen.ADMIN_DASHBOARD
        viewModelScope.launch(Dispatchers.Main) {
            _toastEvent.emit("✓ Biometric Identity Verified: Super Admin Core Unlocked!")
        }
    }

    fun broadcastWebSocketAlert(
        title: String,
        message: String,
        type: String = "SYSTEM_UPDATE",
        actionText: String = "VIEW NOW",
        actionPayload: String? = null
    ) {
        val alert = WebSocketLiveAlert(
            id = UUID.randomUUID().toString(),
            title = title,
            message = message,
            type = type,
            actionText = actionText,
            actionPayload = actionPayload
        )
        _webSocketAlert.value = alert
        val timestamp = System.currentTimeMillis() % 10000
        val log = "[WS BROADCAST $timestamp] Pushed to active peers: '$title'"
        _serverDiagnosticLogs.value = listOf(log) + _serverDiagnosticLogs.value.take(15)
    }

    fun dismissWebSocketAlert() {
        _webSocketAlert.value = null
    }

    fun onWebSocketAlertAction(alert: WebSocketLiveAlert) {
        _webSocketAlert.value = null
        when (alert.type) {
            "CUSTOM_WORKOUT" -> _currentScreen.value = AppScreen.USER_HOME
            "BROADCAST" -> _currentScreen.value = AppScreen.COMMUNITY_TRIBES
            else -> _currentScreen.value = AppScreen.USER_HOME
        }
    }

    fun submitDailyReadiness(energy: Int, sleep: Int, soreness: Int, stress: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateReadinessScore(energy, sleep, soreness, stress)
            launch(Dispatchers.Main) {
                _toastEvent.emit("🧬 Daily Readiness Matrix Synchronized!")
            }
        }
    }

    fun updateDailyReadiness(energy: Int, sleep: Int, soreness: Int, stress: Int) {
        submitDailyReadiness(energy, sleep, soreness, stress)
    }

    // Workout Player Engine with countdown & interval logic
    fun startWorkoutSession(exercise: ExerciseEntity) {
        _workoutSession.value = WorkoutSessionState(
            exercise = exercise,
            isPreparing = true,
            prepSecondsLeft = 10,
            isResting = false,
            restSecondsLeft = exercise.restDurationSec,
            currentSet = 1,
            totalSets = exercise.defaultSets,
            currentReps = exercise.defaultReps,
            totalRepsLogged = 0,
            elapsedSeconds = 0,
            isPaused = false,
            caloriesBurned = 0
        )
        _currentScreen.value = AppScreen.WORKOUT_PLAYER
        startIntervalTimer()
    }

    fun startWorkout(exerciseId: String) {
        val ex = allExercises.value.find { it.id == exerciseId } ?: allExercises.value.firstOrNull()
        ex?.let { startWorkoutSession(it) }
    }

    private fun startIntervalTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                delay(1000)
                val current = _workoutSession.value
                if (current.isPaused) continue
                if (current.isPreparing) {
                    if (current.prepSecondsLeft > 1) {
                        _workoutSession.value = current.copy(
                            prepSecondsLeft = current.prepSecondsLeft - 1
                        )
                    } else {
                        _workoutSession.value = current.copy(
                            isPreparing = false,
                            prepSecondsLeft = 0
                        )
                    }
                } else if (current.isResting) {
                    if (current.restSecondsLeft > 1) {
                        _workoutSession.value = current.copy(
                            restSecondsLeft = current.restSecondsLeft - 1,
                            elapsedSeconds = current.elapsedSeconds + 1
                        )
                    } else {
                        val nextSet = current.currentSet + 1
                        _workoutSession.value = current.copy(
                            isResting = false,
                            currentSet = nextSet,
                            restSecondsLeft = current.exercise?.restDurationSec ?: 30,
                            elapsedSeconds = current.elapsedSeconds + 1
                        )
                    }
                } else {
                    _workoutSession.value = current.copy(
                        elapsedSeconds = current.elapsedSeconds + 1,
                        caloriesBurned = current.caloriesBurned + (if (current.elapsedSeconds % 3 == 0) 1 else 0)
                    )
                }
            }
        }
    }

    fun completeCurrentSet() {
        val current = _workoutSession.value
        val ex = current.exercise ?: return
        val newRepsLogged = current.totalRepsLogged + current.currentReps
        val addedCalories = current.caloriesBurned + ex.caloriesPerSet
        if (current.currentSet >= current.totalSets) {
            finishWorkout()
        } else {
            _workoutSession.value = current.copy(
                isResting = true,
                restSecondsLeft = ex.restDurationSec,
                totalRepsLogged = newRepsLogged,
                caloriesBurned = addedCalories
            )
        }
    }

    fun addRestTime(seconds: Int = 30) {
        val current = _workoutSession.value
        _workoutSession.value = current.copy(
            restSecondsLeft = current.restSecondsLeft + seconds
        )
    }

    fun addRestSeconds(seconds: Int = 30) {
        addRestTime(seconds)
    }

    fun skipRest() {
        val current = _workoutSession.value
        val nextSet = current.currentSet + 1
        _workoutSession.value = current.copy(
            isResting = false,
            currentSet = nextSet,
            restSecondsLeft = current.exercise?.restDurationSec ?: 30
        )
    }

    fun skipRestTimer() {
        skipRest()
    }

    fun toggleWorkoutPause() {
        val current = _workoutSession.value
        _workoutSession.value = current.copy(isPaused = !current.isPaused)
    }

    fun toggleVoiceCoach() {
        val current = _workoutSession.value
        _workoutSession.value = current.copy(voiceCoachActive = !current.voiceCoachActive)
    }

    fun finishWorkout() {
        timerJob?.cancel()
        val current = _workoutSession.value
        val ex = current.exercise
        val title = ex?.title ?: "Full Body Blast"
        val sector = ex?.sector ?: "GYM"
        val duration = current.elapsedSeconds.coerceAtLeast(60)
        val calories = current.caloriesBurned.coerceAtLeast(45)
        val sets = current.currentSet
        val reps = current.totalRepsLogged.coerceAtLeast(sets * 10)

        viewModelScope.launch(Dispatchers.IO) {
            repository.completeWorkout(
                workoutName = title,
                sector = sector,
                durationSeconds = duration,
                calories = calories,
                sets = sets,
                reps = reps,
                exercisesSummary = "${ex?.title} (${sets} sets, ${reps} reps)"
            )
            launch(Dispatchers.Main) {
                _currentScreen.value = AppScreen.WORKOUT_COMPLETE
            }
        }
    }

    fun toggleFavorite(exerciseId: String, isFav: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleFavorite(exerciseId, isFav)
        }
    }

    fun toggleChallenge(challengeId: String, currentJoined: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleChallengeJoin(challengeId, currentJoined)
            launch(Dispatchers.Main) {
                _toastEvent.emit(if (!currentJoined) "🔥 Challenge Activated!" else "Challenge Left")
            }
        }
    }

    fun logWeight(weightKg: Float, note: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            repository.logWeight(weightKg, note)
            launch(Dispatchers.Main) {
                _toastEvent.emit("⚖️ Logged ${weightKg}kg successfully!")
            }
        }
    }

    fun togglePlanDay(dayId: String, isCompleted: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.togglePlanDayCompleted(dayId, isCompleted)
        }
    }

    fun toggleReminder(id: String, isEnabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleHabitReminder(id, isEnabled)
        }
    }

    fun addReminder(timeStr: String, daysLabel: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addHabitReminder(timeStr, daysLabel)
            launch(Dispatchers.Main) {
                _toastEvent.emit("⏰ Reminder scheduled for $timeStr ($daysLabel)")
            }
        }
    }

    fun toggleWeightliftingSet(setId: Long, isCompleted: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleSetCompleted(setId, isCompleted)
        }
    }

    fun logNewWeightliftingSet(workoutTitle: String, exerciseName: String, setNumber: Int, weightKg: Float, reps: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.logWeightliftingSet(workoutTitle, exerciseName, setNumber, weightKg, reps, isCompleted = true)
            launch(Dispatchers.Main) {
                _toastEvent.emit("✓ Set $setNumber Logged: ${weightKg}kg × $reps reps")
            }
        }
    }

    fun createCustomWorkoutPlan(title: String, durationMin: Int, exercises: List<ExerciseEntity>, focusAreas: String, level: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val names = exercises.joinToString(", ") { it.title }
            repository.saveCustomWorkoutPlan(
                title = title,
                durationMin = durationMin,
                exerciseCount = exercises.size,
                exercisesSummary = names,
                focusAreas = focusAreas,
                level = level
            )
            launch(Dispatchers.Main) {
                _toastEvent.emit("✨ Custom Plan '$title' Created!")
                broadcastWebSocketAlert(
                    title = "⚡ NEW CUSTOM WORKOUT: $title",
                    message = "Tailored $durationMin-min routine with ${exercises.size} exercises ($focusAreas) pushed live.",
                    type = "CUSTOM_WORKOUT",
                    actionText = "START PLAN"
                )
                _currentScreen.value = AppScreen.USER_HOME
            }
        }
    }

    fun createAdminPost(title: String, category: String, desc: String, muscle: String) {
        val user = currentUser.value
        val author = user?.name ?: "ABHIRAJ KUMAR (Admin)"
        viewModelScope.launch(Dispatchers.IO) {
            repository.createAdminPost(title, category, desc, muscle, author)
            launch(Dispatchers.Main) {
                _toastEvent.emit("📢 Admin Post Published to Community Feed!")
                broadcastWebSocketAlert(
                    title = "📢 ADMIN BROADCAST: $title",
                    message = desc.take(90) + (if (desc.length > 90) "..." else ""),
                    type = "BROADCAST",
                    actionText = "VIEW COMMUNITY"
                )
            }
        }
    }

    fun deleteAdminPost(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAdminPost(id)
            launch(Dispatchers.Main) {
                _toastEvent.emit("Post removed.")
            }
        }
    }

    fun askVoiceCoachFormFeedback(query: String) {
        sendChatMessage(query)
    }

    fun setAmbientLighting(level: String) {
        _ambientLighting.value = level
    }

    fun pingAllServers() {
        viewModelScope.launch(Dispatchers.IO) {
            val timestamp = System.currentTimeMillis() % 10000
            val newLogs = listOf(
                "[PING $timestamp] GET https://api.fit3d.cloud/v1/ping - 200 OK (18ms)",
                "[PING $timestamp] GET https://cdn.fit3d-videos.internal/health - 200 OK (26ms)",
                "[PING $timestamp] GET https://generativelanguage.googleapis.com - 200 OK (112ms)",
                "[SOCKET $timestamp] WebSocket Heartbeat ACK (0.01% packet loss)"
            )
            _serverDiagnosticLogs.value = newLogs + _serverDiagnosticLogs.value.take(15)
            launch(Dispatchers.Main) {
                _toastEvent.emit("⚡ All Host Endpoints & CDN Servers Verified Online!")
            }
        }
    }

    fun executeHttpTest(endpoint: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val latency = (15..85).random()
            val log = "[HTTP 200 TEST] GET https://api.fit3d.cloud$endpoint - Status 200 OK (${latency}ms)"
            _serverDiagnosticLogs.value = listOf(log) + _serverDiagnosticLogs.value.take(15)
            launch(Dispatchers.Main) {
                _toastEvent.emit("✓ HTTP Endpoint Test Passed: 200 OK (${latency}ms)")
            }
        }
    }

    fun updateExerciseVideo(exerciseId: String, videoUrl: String, videoFileName: String, videoCategory: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateExerciseVideo(exerciseId, videoUrl, videoFileName, videoCategory)
            launch(Dispatchers.Main) {
                _toastEvent.emit("📹 Video mapped to '$videoCategory' category!")
            }
        }
    }

    fun updateExistingExercise(exercise: ExerciseEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateExercise(exercise)
            launch(Dispatchers.Main) {
                _toastEvent.emit("✓ Exercise updated successfully!")
            }
        }
    }

    fun addNewExercise(
        title: String,
        sector: String,
        subtitle: String,
        prop: String,
        muscles: String,
        diff: String,
        sets: Int,
        reps: Int,
        instructions: String
    ) {
        createCustomExercise(title, sector, subtitle, prop, muscles, "CHEST", diff, instructions)
    }

    fun createCustomExercise(
        title: String,
        sector: String,
        subtitle: String,
        domesticProp: String,
        targetMuscles: String,
        muscleCode: String,
        difficulty: String,
        instructions: String
    ) {
        val ex = ExerciseEntity(
            id = "custom_${UUID.randomUUID()}",
            title = title,
            sector = sector,
            subtitle = subtitle,
            domesticProp = domesticProp,
            targetMuscles = targetMuscles,
            primaryMuscleCode = muscleCode,
            difficulty = difficulty,
            instructions = instructions,
            commonMistakes = "Incorrect joint alignment or rushing the tempo.",
            formTips = "Control the eccentric phase and feel the burn.",
            isCustomAdminPost = true,
            equipmentCategory = if (domesticProp.contains("Barbell", ignoreCase = true)) "Barbell" else if (domesticProp.contains("Dumbbell", ignoreCase = true)) "Dumbbell" else "No equipment",
            focusAreaGroup = when (muscleCode.uppercase()) {
                "CHEST" -> "Chest"
                "ABS" -> "Abs"
                "BACK" -> "Back"
                "QUADS", "LEG" -> "Leg"
                "GLUTES", "BUTT" -> "Butt"
                "JAWLINE", "NECK" -> "Face & Jawline"
                else -> "Arms"
            },
            coachVoiceTip = "Maintain strong posture and full range of motion."
        )
        viewModelScope.launch(Dispatchers.IO) {
            repository.createExercise(ex)
            launch(Dispatchers.Main) {
                _toastEvent.emit("✨ New Exercise '$title' added to ecosystem!")
            }
        }
    }

    fun deleteExercise(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteExercise(id)
            launch(Dispatchers.Main) {
                _toastEvent.emit("Exercise removed.")
            }
        }
    }

    fun sendChatMessage(message: String) {
        if (message.isBlank()) return
        val userMsg = ChatMessage(text = message, isUser = true)
        _chatMessages.value = _chatMessages.value + userMsg
        _isCoachThinking.value = true

        val user = currentUser.value
        val goal = user?.goal ?: "Strength & Aesthetics"
        val equip = user?.equipment ?: "Domestic Props"
        val readiness = user?.readinessScore ?: 85

        viewModelScope.launch(Dispatchers.IO) {
            val responseText = repository.getPersonalizedWorkoutAdvice(message, goal, equip, readiness)
            launch(Dispatchers.Main) {
                _chatMessages.value = _chatMessages.value + ChatMessage(text = responseText, isUser = false)
                _isCoachThinking.value = false
            }
        }
    }

    fun sendCoachMessage(text: String) {
        sendChatMessage(text)
    }

    fun setLiveEnvironment(env: String) {
        _liveEnvironment.value = env
        viewModelScope.launch(Dispatchers.Main) {
            _toastEvent.emit("⚡ Environment switched to $env (Zero Downtime)")
        }
    }

    fun sendLiveGymChat(message: String) {
        if (message.isBlank()) return
        val user = currentUser.value?.name ?: "Athlete"
        val newMsg = IronForgeChatMessage(
            sender = user,
            text = message,
            timeAgo = "Just now",
            badge = "LIVE LIFTER"
        )
        _liveGymChatFeed.value = listOf(newMsg) + _liveGymChatFeed.value
    }

    fun toggleGymStationOccupancy(stationId: String) {
        _liveGymStations.value = _liveGymStations.value.map { station ->
            if (station.id == stationId) {
                val newOccupied = !station.isOccupied
                station.copy(
                    isOccupied = newOccupied,
                    status = if (newOccupied) "IN USE" else "AVAILABLE",
                    currentUser = if (newOccupied) (currentUser.value?.name ?: "Athlete") else null,
                    setsRemaining = if (newOccupied) 3 else 0
                )
            } else station
        }
        viewModelScope.launch(Dispatchers.Main) {
            _toastEvent.emit("🏋️ Station status updated in Live Tracking!")
        }
    }

    fun triggerLiveMigrationSync() {
        viewModelScope.launch(Dispatchers.IO) {
            val timestamp = System.currentTimeMillis() % 10000
            val log = "[LIVE MIGRATION $timestamp] Zero-Downtime DB Sync Completed: Local entries mirrored to Cloud Production."
            _liveTelemetryFeed.value = listOf(log) + _liveTelemetryFeed.value.take(15)
            launch(Dispatchers.Main) {
                _toastEvent.emit("⚡ Live Zero-Downtime Sync Complete: All Room Data Synced!")
            }
        }
    }

    fun testLiveApi(endpoint: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val latency = (12..45).random()
            val log = "[LIVE API TEST] POST https://ironforge.fit3d.cloud$endpoint - 200 OK (${latency}ms) [SSL 1.3]"
            _liveTelemetryFeed.value = listOf(log) + _liveTelemetryFeed.value.take(15)
            launch(Dispatchers.Main) {
                _toastEvent.emit("✓ Live API Endpoint $endpoint Verified (${latency}ms)!")
            }
        }
    }
}
