package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BiometricAuthGateDialog
import com.example.ui.components.SearchOverlay
import com.example.ui.components.WebSocketNotificationOverlay
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AiCoachScreen
import com.example.ui.screens.CameraMirrorScreen
import com.example.ui.screens.CommunityTribesScreen
import com.example.ui.screens.ExerciseDetailScreen
import com.example.ui.screens.ExerciseListScreen
import com.example.ui.screens.FaceSmartHubScreen
import com.example.ui.screens.IronForgeProGymScreen
import com.example.ui.screens.PersonalPlanBuilderScreen
import com.example.ui.screens.ProgressAnalyticsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.UserHomeScreen
import com.example.ui.screens.VerificationScreen
import com.example.ui.screens.WeightliftingTrackerScreen
import com.example.ui.screens.WorkoutCompleteScreen
import com.example.ui.screens.WorkoutPlayerScreen
import com.example.ui.theme.BackgroundBlack
import com.example.ui.theme.Fit3dTheme
import com.example.viewmodel.AppScreen
import com.example.viewmodel.Fit3dViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val fit3dViewModel: Fit3dViewModel = viewModel()
            val activeTheme by fit3dViewModel.activeTheme.collectAsState()

            Fit3dTheme(themeName = activeTheme) {
                Fit3dAppContent(viewModel = fit3dViewModel)
            }
        }
    }
}

@Composable
fun Fit3dAppContent(viewModel: Fit3dViewModel) {
    val context = LocalContext.current

    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val allExercises by viewModel.allExercises.collectAsState()
    val workoutHistory by viewModel.workoutHistory.collectAsState()
    val adminPosts by viewModel.adminPosts.collectAsState()
    val challenges by viewModel.challenges.collectAsState()
    val totalWorkouts by viewModel.totalWorkoutCount.collectAsState()
    val totalWorkoutSeconds by viewModel.totalWorkoutSeconds.collectAsState()
    val totalCaloriesBurned by viewModel.totalCaloriesBurned.collectAsState()
    val allWeightLogs by viewModel.allWeightLogs.collectAsState()
    val customPlans by viewModel.customWorkoutPlans.collectAsState()
    val articles by viewModel.healthArticles.collectAsState()
    val fourWeekPlans by viewModel.fourWeekPlans.collectAsState()
    val weightliftingSets by viewModel.weightliftingSets.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val isSearchOpen by viewModel.isSearchOpen.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedSector by viewModel.selectedSector.collectAsState()
    val selectedExerciseId by viewModel.selectedExerciseId.collectAsState()
    val activeMuscle by viewModel.active3dMuscle.collectAsState()
    val isGreenTargetEnabled by viewModel.isGreenTargetEnabled.collectAsState()
    val activeTheme by viewModel.activeTheme.collectAsState()
    val webSocketAlert by viewModel.webSocketAlert.collectAsState()
    val isBiometricGateOpen by viewModel.isBiometricGateOpen.collectAsState()
    val sessionState by viewModel.workoutSession.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isCoachThinking by viewModel.isCoachThinking.collectAsState()
    val liveEnvironment by viewModel.liveEnvironment.collectAsState()
    val liveIpAddress by viewModel.liveIpAddress.collectAsState()
    val liveConcurrentLifters by viewModel.liveConcurrentLifters.collectAsState()
    val liveGymChatFeed by viewModel.liveGymChatFeed.collectAsState()
    val liveGymStations by viewModel.liveGymStations.collectAsState()
    val serverDiagnosticLogs by viewModel.serverDiagnosticLogs.collectAsState()
    val liveTelemetryFeed by viewModel.liveTelemetryFeed.collectAsState()

    val selectedExercise = allExercises.find { it.id == selectedExerciseId } ?: allExercises.firstOrNull()

    LaunchedEffect(Unit) {
        viewModel.toastEvent.collectLatest { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundBlack),
        containerColor = BackgroundBlack
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Screen Routing
            when (currentScreen) {
                AppScreen.SPLASH -> {
                    SplashScreen(
                        onContinue = {
                            viewModel.navigateTo(AppScreen.VERIFICATION)
                        }
                    )
                }

                AppScreen.VERIFICATION -> {
                    VerificationScreen(
                        onVerifySuccess = { name, email, phone, avatar, photoUri ->
                            viewModel.verifyUser(name, email, phone, avatar, photoUri)
                        }
                    )
                }

                AppScreen.USER_HOME -> {
                    UserHomeScreen(
                        user = currentUser,
                        exercises = allExercises,
                        fourWeekPlans = fourWeekPlans,
                        activeMuscle = activeMuscle,
                        isGreenTargetEnabled = isGreenTargetEnabled,
                        activeTheme = activeTheme,
                        onThemeChange = { theme -> viewModel.setTheme(theme) },
                        onSectorClick = { sector -> viewModel.selectSector(sector) },
                        onExerciseClick = { exId -> viewModel.openExerciseDetail(exId) },
                        onMuscleSelected = { muscle -> viewModel.setActiveMuscle(muscle) },
                        onToggleGreenTarget = { enabled -> viewModel.toggleGreenTarget(enabled) },
                        onToggleCommandMode = { viewModel.toggleCommandMode() },
                        onSearchClick = { viewModel.setSearchOpen(true) },
                        onNavigate = { screen -> viewModel.navigateTo(screen) },
                        onUpdateReadiness = { energy, sleep, soreness, stress ->
                            viewModel.submitDailyReadiness(energy, sleep, soreness, stress)
                        },
                        onUpdateProfileImage = { uri ->
                            viewModel.updateProfileImage(uri)
                        }
                    )
                }

                AppScreen.EXERCISE_LIST -> {
                    ExerciseListScreen(
                        sector = selectedSector,
                        exercises = allExercises,
                        onBack = { viewModel.navigateTo(AppScreen.USER_HOME) },
                        onExerciseClick = { exerciseId ->
                            viewModel.openExerciseDetail(exerciseId)
                        },
                        onToggleFavorite = { exId, isFav ->
                            viewModel.toggleFavorite(exId, isFav)
                        }
                    )
                }

                AppScreen.EXERCISE_DETAIL -> {
                    ExerciseDetailScreen(
                        exercise = selectedExercise,
                        activeMuscle = activeMuscle,
                        isGreenTargetEnabled = isGreenTargetEnabled,
                        onBack = { viewModel.navigateTo(AppScreen.EXERCISE_LIST) },
                        onStartWorkout = { exercise ->
                            viewModel.startWorkoutSession(exercise)
                        },
                        onToggleFavorite = { exId, isFav ->
                            viewModel.toggleFavorite(exId, isFav)
                        },
                        onOpenCameraMirror = {
                            viewModel.navigateTo(AppScreen.CAMERA_MIRROR)
                        },
                        onToggleMuscle = { muscle ->
                            viewModel.setActiveMuscle(muscle)
                        },
                        onToggleGreenTarget = { enabled ->
                            viewModel.toggleGreenTarget(enabled)
                        }
                    )
                }

                AppScreen.WORKOUT_PLAYER -> {
                    WorkoutPlayerScreen(
                        session = sessionState,
                        onCompleteSet = { viewModel.completeCurrentSet() },
                        onAddRestSeconds = { secs -> viewModel.addRestSeconds(secs) },
                        onSkipRest = { viewModel.skipRest() },
                        onTogglePause = { viewModel.toggleWorkoutPause() },
                        onFinishEarly = { viewModel.finishWorkout() },
                        onOpenCameraMirror = { viewModel.navigateTo(AppScreen.CAMERA_MIRROR) },
                        onAskVoiceAi = { query -> viewModel.sendChatMessage(query) }
                    )
                }

                AppScreen.WORKOUT_COMPLETE -> {
                    WorkoutCompleteScreen(
                        user = currentUser,
                        session = sessionState,
                        onReturnHome = { viewModel.navigateTo(AppScreen.USER_HOME) },
                        onViewAnalytics = { viewModel.navigateTo(AppScreen.PROGRESS_ANALYTICS) }
                    )
                }

                AppScreen.WEIGHTLIFTING_TRACKER -> {
                    WeightliftingTrackerScreen(
                        weightLogs = allWeightLogs,
                        sets = weightliftingSets,
                        onBack = { viewModel.navigateTo(AppScreen.USER_HOME) },
                        onLogWeight = { weight, note ->
                            viewModel.logWeight(weight, note)
                        },
                        onLogSet = { title, exName, setNum, weight, reps ->
                            viewModel.logNewWeightliftingSet(title, exName, setNum, weight, reps)
                        },
                        onToggleSetCompleted = { id, isDone ->
                            viewModel.toggleWeightliftingSet(id, isDone)
                        },
                        onAskVoiceAi = { query ->
                            viewModel.sendChatMessage(query)
                        }
                    )
                }

                AppScreen.PROGRESS_ANALYTICS -> {
                    ProgressAnalyticsScreen(
                        user = currentUser,
                        history = workoutHistory,
                        totalWorkouts = totalWorkouts,
                        totalSeconds = totalWorkoutSeconds ?: 0,
                        totalCalories = totalCaloriesBurned ?: 0,
                        onBack = { viewModel.navigateTo(AppScreen.USER_HOME) }
                    )
                }

                AppScreen.FACE_SMART_HUB -> {
                    FaceSmartHubScreen(
                        articles = articles,
                        faceExercises = allExercises,
                        onBack = { viewModel.navigateTo(AppScreen.USER_HOME) },
                        onArticleClick = { article -> viewModel.openArticle(article) },
                        onStartExercise = { exId ->
                            viewModel.openExerciseDetail(exId)
                        },
                        onOpenCameraMirror = {
                            viewModel.navigateTo(AppScreen.CAMERA_MIRROR)
                        }
                    )
                }

                AppScreen.PERSONAL_PLAN_BUILDER -> {
                    PersonalPlanBuilderScreen(
                        exercises = allExercises,
                        customPlans = customPlans,
                        onBack = { viewModel.navigateTo(AppScreen.USER_HOME) },
                        onSavePlan = { title, duration, selectedEx, focus, level ->
                            viewModel.createCustomWorkoutPlan(title, duration, selectedEx, focus, level)
                        }
                    )
                }

                AppScreen.COMMUNITY_TRIBES -> {
                    CommunityTribesScreen(
                        challenges = challenges,
                        adminPosts = adminPosts,
                        onBack = { viewModel.navigateTo(AppScreen.USER_HOME) },
                        onToggleChallenge = { id, isJoined ->
                            viewModel.toggleChallenge(id, isJoined)
                        }
                    )
                }

                AppScreen.AI_COACH -> {
                    AiCoachScreen(
                        messages = chatMessages,
                        isThinking = isCoachThinking,
                        onBack = { viewModel.navigateTo(AppScreen.USER_HOME) },
                        onSendMessage = { query ->
                            viewModel.sendChatMessage(query)
                        }
                    )
                }

                AppScreen.CAMERA_MIRROR -> {
                    CameraMirrorScreen(
                        onBack = { viewModel.navigateTo(AppScreen.USER_HOME) }
                    )
                }

                AppScreen.IRONFORGE_PRO_GYM -> {
                    IronForgeProGymScreen(
                        liveEnvironment = liveEnvironment,
                        liveIpAddress = liveIpAddress,
                        liveConcurrentLifters = liveConcurrentLifters,
                        chatMessages = liveGymChatFeed,
                        stations = liveGymStations,
                        telemetryLogs = serverDiagnosticLogs + liveTelemetryFeed,
                        onBack = { viewModel.navigateTo(AppScreen.USER_HOME) },
                        onSetEnvironment = { env -> viewModel.setLiveEnvironment(env) },
                        onSendChat = { text -> viewModel.sendLiveGymChat(text) },
                        onToggleStation = { id -> viewModel.toggleGymStationOccupancy(id) },
                        onTriggerMigrationSync = { viewModel.triggerLiveMigrationSync() },
                        onTestApi = { endpoint -> viewModel.testLiveApi(endpoint) }
                    )
                }

                AppScreen.ADMIN_DASHBOARD -> {
                    AdminDashboardScreen(
                        user = currentUser,
                        exercises = allExercises,
                        adminPosts = adminPosts,
                        serverDiagnosticLogs = serverDiagnosticLogs,
                        onExitAdmin = { viewModel.navigateTo(AppScreen.USER_HOME) },
                        onCreatePost = { title, category, desc, muscle ->
                            viewModel.createAdminPost(title, category, desc, muscle)
                        },
                        onDeletePost = { id ->
                            viewModel.deleteAdminPost(id)
                        },
                        onCreateExercise = { title, sector, subtitle, prop, muscles, diff, sets, reps, inst ->
                            viewModel.addNewExercise(title, sector, subtitle, prop, muscles, diff, sets, reps, inst)
                        },
                        onDeleteExercise = { id ->
                            viewModel.deleteExercise(id)
                        },
                        onPingServers = {
                            viewModel.pingAllServers()
                        },
                        onExecuteHttpTest = { endpoint ->
                            viewModel.executeHttpTest(endpoint)
                        },
                        onMapVideoToExercise = { exerciseId, videoUrl, videoFileName, videoCategory ->
                            viewModel.updateExerciseVideo(exerciseId, videoUrl, videoFileName, videoCategory)
                        }
                    )
                }
            }

            // Global Real-Time Push Notification Banner
            WebSocketNotificationOverlay(
                activeAlert = webSocketAlert,
                onDismiss = { viewModel.dismissWebSocketAlert() },
                onActionClick = { alert -> viewModel.onWebSocketAlertAction(alert) }
            )

            // Global Search Modal
            if (isSearchOpen) {
                SearchOverlay(
                    searchQuery = searchQuery,
                    onQueryChange = { q -> viewModel.updateSearchQuery(q) },
                    results = searchResults,
                    onClose = { viewModel.setSearchOpen(false) },
                    onExerciseClick = { exId ->
                        viewModel.setSearchOpen(false)
                        viewModel.openExerciseDetail(exId)
                    }
                )
            }

            // Super Admin Biometric Gate Dialog (BiometricPrompt / Fingerprint / Face Unlock)
            if (isBiometricGateOpen) {
                BiometricAuthGateDialog(
                    onDismiss = { viewModel.closeBiometricGate() },
                    onAuthenticated = {
                        viewModel.onBiometricAuthSuccess()
                    }
                )
            }
        }
    }
}
